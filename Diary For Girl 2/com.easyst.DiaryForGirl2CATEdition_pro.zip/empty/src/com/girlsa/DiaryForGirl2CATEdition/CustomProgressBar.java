package com.girlsa.DiaryForGirl2CATEdition;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.util.AttributeSet;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.FrameLayout;
import android.widget.ImageView;


public class CustomProgressBar extends FrameLayout {
    private ImageView progressBarImage;
    private TranslateAnimation progressBarAnimation;

    public CustomProgressBar(Context context, AttributeSet attrs) {
        super(context, attrs);
        progressBarImage = new ImageView(getContext());
        progressBarImage.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        addView(progressBarImage);
    }

    public void setBackgroundAsTile(int tileImageId) {
        Bitmap tileBitmap = BitmapFactory.decodeResource(getResources(), tileImageId);
        BitmapDrawable tileRepeatedBitmap = new BitmapDrawable(getResources(), tileBitmap);
        tileRepeatedBitmap.setTileModeX(Shader.TileMode.REPEAT);

        initAnimation(tileBitmap.getWidth());
        progressBarImage.setBackgroundDrawable(tileRepeatedBitmap);
    }
    private void initAnimation(int tileImageWidth) {
        LayoutParams params = (LayoutParams) progressBarImage.getLayoutParams();
        if (params != null)
            params.setMargins(-tileImageWidth, 0, 0, 0);
        progressBarAnimation = new TranslateAnimation(0, tileImageWidth - 3, 0, 0);
        progressBarAnimation.setInterpolator(new LinearInterpolator());
        progressBarAnimation.setDuration(4000);
        progressBarAnimation.setRepeatCount(Animation.INFINITE);
    }
    public void startAnimation() {
        progressBarImage.startAnimation(progressBarAnimation);
    }
}