package com.girlsa.DiaryForGirl2CATEdition;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.view.*;
import android.webkit.DownloadListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import com.girlsa.DiaryForGirl2CATEdition.R;

public class MainWebView extends WebView {

    private MainActivity activity;
    private FrameLayout frameLayout;
    private MainWebChromeClient webChromeClient;
    private FrameLayout fullScreenVideoLayout;
    //public CustomProgressBar progressBar;
    public FrameLayout webViewLayout;
    private String currentUrl;

    public MainWebView(final MainActivity activity) {
        super(activity);
        this.activity = activity;
        currentUrl = activity.getString(R.string.APP_URL);
        setSettings();

        frameLayout = new FrameLayout(activity);
        FrameLayout wholeScreenLayout;


        try {
            wholeScreenLayout = (FrameLayout) LayoutInflater.from(activity).inflate(R.layout.whole_screen, null);
            webViewLayout = (FrameLayout) wholeScreenLayout.findViewById(R.id.webViewLayout);
            fullScreenVideoLayout = (FrameLayout) wholeScreenLayout.findViewById(R.id.fullScreenVideoLayout);

            /*progressBar = (CustomProgressBar) wholeScreenLayout.findViewById(R.id.progressBar);
            progressBar.setBackgroundAsTile(R.drawable.progress_bar);
            progressBar.setVisibility(View.GONE);
            progressBar.startAnimation();*/
            webViewLayout.addView(this);
            frameLayout.addView(wholeScreenLayout, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } catch (NullPointerException e) {
            Logging.err(e);
        }
        
        webChromeClient = new MainWebChromeClient(activity, this);
        setWebChromeClient(webChromeClient);
        setWebViewClient(new MainWebViewClient(activity, this));
        setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String s, String s2, String s3, String s4, long l) {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(s));
                activity.startActivity(i);
            }
        });
    }

    public void loadRemoteUrl(String url) {
        if (activity.checkNetworkConnection()) {
            super.loadUrl(checkTheUrl(url));
        }
        else {
            activity.showErrorScreen(true);
        }
    }
    public void loadHtml(String path) {
        loadUrl(path);
    }


    @SuppressLint({ "SetJavaScriptEnabled", "NewApi" })
    private void setSettings() {
        WebSettings settings = getSettings();
        settings.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
        settings.setJavaScriptEnabled(true);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            settings.setAllowContentAccess(true);
            settings.setDisplayZoomControls(true);
        }
        settings.setAllowFileAccess(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setBuiltInZoomControls(true);
        settings.setDomStorageEnabled(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSaveFormData(true);
        settings.setSavePassword(true);
        
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        if (activity.getResources().getString(R.string.SET_SUPPORT_ZOOM).equals(activity.SET_SUPPORT_ZOOM)) {
            settings.setSupportZoom(true);
        } else {
            settings.setSupportZoom(false);
        }


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO) {
            settings.setPluginState(WebSettings.PluginState.ON);
        }
        settings.setGeolocationEnabled(true);
        settings.setAppCacheEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUserAgentString(settings.getUserAgentString());
        //settings.setUserAgentString("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36"); // for iframe if it offer to download his android app
        String path = null;
        try {
            path = Environment.getDataDirectory().getAbsolutePath() + "/data/" + activity.getPackageName();
        } catch (Exception e) {
            Logging.err(e);
        }
        if (path != null) {
            settings.setDatabasePath(path + "/database/");
            settings.setAppCachePath(path + "/cache/");
            settings.setGeolocationDatabasePath(path + "/geolocation/");
        }

        if (activity.getResources().getString(R.string.USE_WIDE_VIEW_PORT).equals("true")) {
            settings.setUseWideViewPort(true);
        } else {
            settings.setUseWideViewPort(false);
        }
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.JELLY_BEAN)
            settings.setAllowUniversalAccessFromFileURLs(true);
    }

    public FrameLayout getLayout() {
        return frameLayout;
    }
    public boolean inFullScreenVideo() {
        return (webChromeClient.customView != null);
    }
    public void hideCustomView() {
        webChromeClient.onHideCustomView();
    }

    public FrameLayout getFullScreenVideoLayout() {
        return fullScreenVideoLayout;
    }

    public String getCurrentUrl() {
        return currentUrl;
    }

    public void setCurrentUrl(String currentUrl) {
        this.currentUrl = currentUrl;
    }

    private String checkTheUrl(String url) {
        if( url.endsWith(".pdf")     || url.endsWith(".PDF")
            || url.endsWith(".txt")     || url.endsWith(".TXT")
            || url.endsWith(".doc")     || url.endsWith(".DOC")
            || url.endsWith(".docx")    || url.endsWith(".DOCX")
            || url.endsWith(".xls")     || url.endsWith(".XLS")
            || url.endsWith(".xlsx")    || url.endsWith(".XLSX")
            || url.endsWith(".ppt")     || url.endsWith(".PPT")
            || url.endsWith(".pptx")    || url.endsWith(".PPTX")
            || url.endsWith(".pages")   || url.endsWith(".PAGES")
            || url.endsWith(".ai")      || url.endsWith(".AI")
            || url.endsWith(".psd")     || url.endsWith(".PSD")
            || url.endsWith(".tiff")    || url.endsWith(".TIFF")
            || url.endsWith(".dxf")     || url.endsWith(".DXF")
            || url.endsWith(".svg")     || url.endsWith(".SVG")
            || url.endsWith(".eps")     || url.endsWith(".EPS")
            || url.endsWith(".ps")      || url.endsWith(".PS")
            || url.endsWith(".ttf")     || url.endsWith(".TTF")
            || url.endsWith(".xps")     || url.endsWith(".XPS")
            || url.endsWith(".zip")     || url.endsWith(".ZIP")
            || url.endsWith(".rar")     || url.endsWith(".RAR")) {
            return "https://docs.google.com/gview?embedded=true&url=" + url;
        }
        return url;
    }
}
