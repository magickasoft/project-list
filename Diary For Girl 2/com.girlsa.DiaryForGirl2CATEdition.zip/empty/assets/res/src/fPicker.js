var fPicker = {
    el: null,
    cDate: null,
    fP: null,
    fWrap : null,
    calendar : null,
    title : null,
    ln: 'en',
    selY: false,
    zero: function(d){
        return (d < 10) ? '0'+d : d;
    },

    count_day: function(date) {
        var flag = false;
        for (var i = 0; i < storage.length; i++) {
            var key = storage.key(i);
            if (key.indexOf('girl_app') != -1 && key.indexOf(date) != -1) {
                flag = true;
                break;
            }
        }

        return flag;
    },

    init: function(ln){
        this.ln = ln || 'en';
        this.fP = document.getElementById('fPicker');
        this.fP.innerHTML = '<div id="fWrap"><table id="fCalNav"><tr><td id="fPrev"></td><td id="fTitle"></td><td id="fNext"></td></tr></table><table id="fCalendar" cellspacing="0" cellpadding="0"></table></div>';
        this.calendar = document.getElementById('fCalendar');
        this.title = document.getElementById('fTitle');
        this.fWrap = document.getElementById('fWrap');

        //this.fP.addEventListener('click', function(e){ e.preventDefault(); if(e.target.id == 'fPicker'){ fPicker.close(); } }, false);
        //this.fP.addEventListener('touchmove', function(e){ e.preventDefault(); }, false);
        
        //new Tap(this.calendar);
        new Tap (this.calendar);
        this.calendar.addEventListener('tap', fPicker.sel, false);

        var prv = document.getElementById('fPrev');
        new Tap(prv);
        prv.addEventListener('tap', fPicker.nav, false);

        var nxt = document.getElementById('fNext');
        new Tap(nxt);
        nxt.addEventListener('tap', fPicker.nav, false);

        new Tap(this.title);
        this.title.addEventListener('tap', function(e){ e.preventDefault(); fPicker.selY = !fPicker.selY; fPicker.fill(); }, false);
    },
    set: function(el, dt){
        el = typeof el === 'object' ? el : document.getElementById(el);
        el.addEventListener('focus', function(e){ e.preventDefault(); fPicker.open(e.target); this.blur(); }, false);
        if(dt){
            el.value = dt.getDate()+' '+fDates[fPicker.ln].monthsShort[dt.getMonth()]+' '+dt.getFullYear();
            el.dataset.val = dt.getFullYear()+'/'+fPicker.zero(dt.getMonth()+1)+'/'+fPicker.zero(dt.getDate());
        }
    },
    fill: function(){
        if(!fPicker.selY){
            var dayofmonth = (32 - new Date(fPicker.cDate.getFullYear(), fPicker.cDate.getMonth(), 32).getDate());
            var day_count = 1;
            var week = [[],[],[],[],[],[]];
            // First week
            var num = 0;
            for(var i = 0; i < 7; i++){
                var dayofweek = new Date(fPicker.cDate.getFullYear(), fPicker.cDate.getMonth(), day_count).getDay();
                dayofweek = dayofweek - 1;
                if(dayofweek == -1) dayofweek = 6;
                if(dayofweek == i){
                    week[num][i] = day_count;
                    day_count++;
                }else week[num][i] = '';
            }
            // Next weeks
            while(true){
                num++;
                for(var j = 0; j < 7; j++){
                    week[num][j] = day_count;
                    day_count ++;
                    if(day_count > dayofmonth) break;
                }
                if(day_count > dayofmonth) break;
            }
            var cY = this.cDate.getFullYear(),
                cM = this.cDate.getMonth(),
                cD = this.cDate.getDate(),
                day = this.cDate.getDay();

                var smiles_arr = JSON.parse(storage.getItem('girlapp_smiles'));

            var wLen = week.length;
            var cnt = '<tr><th>'+fDates[this.ln].daysShort[1]+'</th><th>'+fDates[this.ln].daysShort[2]+'</th><th>'+fDates[this.ln].daysShort[3]+'</th><th>'+fDates[this.ln].daysShort[4]+'</th><th>'+fDates[this.ln].daysShort[5]+'</th><th>'+fDates[this.ln].daysShort[6]+'</th><th>'+fDates[this.ln].daysShort[0]+'</th></tr>';
            for(var k = 0; k < wLen; k++){
                cnt += '<tr>';
                for(var l = 0; l < 7; l++){
                    var classes = [];
                    var compDate = cY+'.'+fPicker.zero(cM+1)+'.'+fPicker.zero(week[k][l]);
                    if(fPicker.el.value == week[k][l]+' '+fDates[fPicker.ln].monthsShort[cM]+' '+cY) classes.push('sel');
                    if(l == 5 || l == 6) classes.push('weekend');

                    // APP CODE

                    var class_list = "";

                    if(week[k][l] != '' && week[k][l] !== undefined){
                        if (fPicker.count_day(compDate)) {
                            class_list = "active2";
                        }

                        if (smiles_arr != null) {
                            if (typeof(smiles_arr[compDate]) != 'undefined') {
                                cnt += '<td class="itm '+classes.join(' ')+' '+class_list+'"><div><div class="smileCalendar '+smiles_arr[compDate]+'"></div><span class="dateBottom">'+week[k][l]+'</span>&nbsp;</div></td>';
                            } else {
                                cnt += '<td class="itm '+classes.join(' ')+' '+class_list+'"><div><span class="dateBottom">'+week[k][l]+'</span>&nbsp;</div></td>';
                            }
                        } else {
                            cnt += '<td class="itm '+classes.join(' ')+' '+class_list+'"><div><span class="dateBottom">'+week[k][l]+'</span>&nbsp;</div></td>';
                        }


                    }else{
                        if(k > 1) break;
                        cnt += '<td>&nbsp;</td>';
                    }
                }
                cnt += '</tr>';
            }
            this.calendar.innerHTML = cnt;
            this.title.innerText = fDates[this.ln].monthsShort[this.cDate.getMonth()] + ', ' + this.cDate.getFullYear();
        }else{
            var cnt = '';
            for(var i = 0; i < 4; i++){
                cnt += '<tr>';
                for(var j = 0; j < 3; j++){
                    cnt += '<td class="itm" data-mnth="'+(j+3*i)+'"><div>'+fDates[this.ln].monthsShort[j+3*i]+'</div></td>';
                }
                cnt += '</tr>';
            }
            this.calendar.innerHTML = cnt;
            this.title.innerText = this.cDate.getFullYear();
        }
    },
    open: function(el){
        //if(this.el.disabled) return false;
        this.selY = false;
        this.el = el;
        this.cDate = (el.dataset.val == '' || el.dataset.val === undefined) ? new Date() : new Date(el.dataset.val);
        this.fill();
        this.fP.style.display = 'block';
        // this.fWrap.style.marginTop = '-'+(this.fWrap.offsetHeight/2)+'px';
    },
    close: function(){
        // fPicker.fP.style.display = 'none';
    },
    sel: function(e){
        e.preventDefault();
        if(e.currentTarget == e.target) return false;
        var obj = e.target;
        while(obj != fPicker.calendar){
            if(obj.classList.contains('itm')){
                var td = obj;
                if(td.innerText.trim() == ''){ break; return false; }
                break;
            }
            obj = obj.parentNode;
        }

        if(fPicker.selY){
            fPicker.cDate.setMonth(td.dataset['mnth']);
            fPicker.selY = false;
            fPicker.fill();
        }else{
            if (typeof(td) != 'undefined') {
                fPicker.cDate.setDate(td.innerText.trim()*1);
            }
            var compDate = fPicker.cDate.getFullYear()+'/'+fPicker.zero(fPicker.cDate.getMonth()+1)+'/'+fPicker.zero(fPicker.cDate.getDate());
            fPicker.el.value = fPicker.cDate.getDate()+' '+fDates[fPicker.ln].monthsShort[fPicker.cDate.getMonth()]+' '+fPicker.cDate.getFullYear();
            fPicker.el.dataset.val = compDate;
/* APP CODE */
if(fPicker.el.id == 'iLastMenstruation'){
    var el = document.getElementById('iBirth');
    var dt = new Date(fPicker.cDate);
    dt.setDate(fPicker.cDate.getDate()+280);
    var dtt = dt.getFullYear()+'/'+fPicker.zero(dt.getMonth()+1)+'/'+fPicker.zero(dt.getDate());
    el.dataset.val = dtt;
    el.value = fPicker.toText(dtt);
}
if(fPicker.el.id == 'iBirth'){
    var el = document.getElementById('iLastMenstruation');
    var dt = new Date(fPicker.cDate);
    dt.setDate(fPicker.cDate.getDate()-280);
    var dtt = dt.getFullYear()+'/'+fPicker.zero(dt.getMonth()+1)+'/'+fPicker.zero(dt.getDate());
    el.dataset.val = dtt;
    el.value = fPicker.toText(dtt);
}
if(fPicker.el.id == 'noteDate'){
    document.getElementById('noteText').value = (localStorage.getItem('MTB_note_'+compDate)) ? JSON.parse(localStorage['MTB_note_'+compDate]).text : '';
}
if(fPicker.el.id == 'symptomDate'){
    Data.symptom.refresh();
}
if(fPicker.el.id == 'moodDate'){
    Data.mood.refresh();
}
/* APP CODE */
            fPicker.close();
            fPicker.fill();
            SMILE_CALENDAR.do_calendar_select();
        }
    },
    nav: function(e){
        e.preventDefault();
        var next = (this.id == 'fNext') ? true : false;
        if(fPicker.selY){
            if(next) fPicker.cDate.setFullYear(fPicker.cDate.getFullYear()+1); else fPicker.cDate.setFullYear(fPicker.cDate.getFullYear()-1);
        }else{
            if(next) fPicker.cDate.setMonth(fPicker.cDate.getMonth()+1); else fPicker.cDate.setMonth(fPicker.cDate.getMonth()-1);
        }
        fPicker.fill();
    },
    toText: function(t, noyear){
        t = t.split('/');
        return (noyear) ? fDates[fPicker.ln].monthsShort[t[1]*1-1]+' '+t[2] : t[2]+' '+fDates[fPicker.ln].monthsShort[t[1]*1-1]+' '+t[0];
    },
    toDigits: function(t){
        t = t.split(' ');
        return t[2]+'/'+fPicker.zero(fDates[fPicker.ln].monthsShort.indexOf(t[1])+1)+'/'+t[0];
    },
    getDay: function(t){
        return fDates[fPicker.ln].days[new Date(t).getDay()];
    }
}