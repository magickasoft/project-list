var _w = {
    diary_for_girls: {
        en: "Diary For Girls",
        de: "Tagebuch für Mädchen",
        fr: "Journal Intime Pour Filles",
        es: "Diario para niñas",
        zh: "女孩的日记",
        ja: "女子の日記",
        ko: "소녀 일기",
        it: "Diario Per Le Ragazze",
        pt: "Diário para meninas",
        ru: "Дневник для девочек",
        pl: "Dziennik dla dziewczyn"
    },

    secret: {
        en: "Secret",
        de: "Geheimnis",
        fr: "Secret",
        es: "Secreto",
        zh: "秘密",
        ja: "秘密",
        ko: "비밀",
        it: "Segreto",
        pt: "Segredo",
        ru: "Секрет",
        pl: "Tajemnica"
    },

    edit: {
        en: "Edit",
        de: "Editieren",
        fr: "Modifier",
        es: "Editar",
        zh: "编辑",
        ja: "エディット",
        ko: "수정",
        it: "Aggiungi",
        pt: "Editar",
        ru: "Редактировать",
        pl: "Dodaj"
    },

    mood_of_secret: {
        en: "Mood for writing",
        de: "Stimmung für Schreiben",
        fr: "Humeur pour écrire",
        es: "El estado de ánimo para escribir",
        zh: "写下心情",
        ja: "書きたい気分",
        ko: "쓰는 기분",
        it: "Stato d’anima",
        pt: "O humor para escrever",
        ru: "Настроение для записи",
        pl: "Nastrój dla zapisu"
    },

    title: {
        en: "Title",
        de: "Titel",
        fr: "Titre",
        es: "Título",
        zh: "标题",
        ja: "タイトル",
        ko: "제목",
        it: "Titolo",
        pt: "Título",
        ru: "Заголовок",
        pl: "Tytuł"
    },

    note: {
        en: "Note",
        de: "Notiz",
        fr: "Note",
        es: "Nota",
        zh: "注释",
        ja: "メモ",
        ko: "노트",
        it: "Nota",
        pt: "Nota",
        ru: "Заметка",
        pl: "Uwaga"
    },

    write_your_title: {
        en: "Enter your title",
        de: "Gebe deinen Titel ein",
        fr: "Entre le titre",
        es: "Escriba su título",
        zh: "输入你的标题",
        ja: "タイトルを入力",
        ko: "제목을 입력하세요",
        it: "Inserisci il titolo",
        pt: "Digite o título",
        ru: "Введите свой заголовок",
        pl: "Wpisz swój nagłówek"
    },

    write_your_secret: {
        en: "Write your secret here",
        de: "Schreibe dein Geheimnis hier",
        fr: "Entre le secret",
        es: "Escriba su secreto aquí",
        zh: "在这里写下你的秘密",
        ja: "秘密をここに書いてください",
        ko: "여기에 비밀을 남겨 주세요",
        it: "Inserisci il tuo segreto",
        pt: "Digite o seu segredo aqui",
        ru: "Введите свой секрет",
        pl: "Wpisz tutaj swój sekret"
    },

    mood_of_day: {
        en: "My mood today",
        de: "Meine Stimmung heute",
        fr: "Mon humeur aujourd'hui",
        es: "Mi estado de ánimo hoy",
        zh: "我今天的心情",
        ja: "今日の気分",
        ko: "오늘 나의 기분",
        it: "Il mio umore oggi",
        pt: "O meu estado de espírito hoje",
        ru: "Мое настроение сегодня",
        pl: "Mój dzsiejszyj nastrój"
    },

    settings: {
        en: "Settings",
        de: "Einstellungen",
        fr: "Réglages",
        es: "Ajustes",
        zh: "设置",
        ja: "設定",
        ko: "세팅",
        it: "Impostazioni",
        pt: "Definições",
        ru: "Настройки",
        pl: "Ustawienia"
    },

    password: {
        en: "Password",
        de: "Passwort",
        fr: "Mot de passe",
        es: "Contraseña",
        zh: "密码",
        ja: "パスワード",
        ko: "암호",
        it: "Password",
        pt: "Senha",
        ru: "Пароль",
        pl: "Hasło"
    },

    new_password: {
        en: "New Password",
        de: "Neues Passwort",
        fr: "Nouveau mot de passe",
        es: "Nueva Contraseña",
        zh: "新的密码",
        ja: "新パスワード",
        ko: "새로운 암호",
        it: "Nuova Password",
        pt: "Nova Senha",
        ru: "Новый пароль",
        pl: "Nowe Hasło"
    },

    submit_new_password: {
        en: "Confirm your password",
        de: "Bestätige dein Passwort",
        fr: "Confirmer le nouveau mot de passe",
        es: "Confirme Nueva Contraseña",
        zh: "确认你的密码",
        ja: "パスワード確認",
        ko: "암호를 확인하세요",
        it: "Conferma la nuova password",
        pt: "Confirme Nova Senha",
        ru: "Подтвердить новый пароль",
        pl: "Potwierdź swoje hasło"
    },

    submit: {
        en: "Confirm",
        de: "Bestätigen",
        fr: "Confirmer",
        es: "Confirmar",
        zh: "确认",
        ja: "確認",
        ko: "확인",
        it: "Conferma",
        pt: "Confirmar",
        ru: "Подтвердить",
        pl: "Potwierdz"
    },

    achivments: {
        en: "Achievements",
        de: "Leistungen",
        fr: "Réalisations",
        es: "Logros",
        zh: "成果",
        ja: "アチーブメント",
        ko: "애치브먼트",
        it: "Realizzazioni",
        pt: "Conquistas",
        ru: "Достижения",
        pl: "Osiągnięcia"
    },

    write_secret: {
        en: "Write your secret",
        de: "Schreibe dein Geheimnis",
        fr: "Écris ton secret",
        es: "Escriba su secreto",
        zh: "写下你的秘密",
        ja: "秘密を書く",
        ko: "비밀을 남겨 주세요",
        it: "Scrivi il tuo segreto",
        pt: "Escreva o seu segredo",
        ru: "Напиши свой секрет",
        pl: "Napisz swoją tajemnicę"
    },

    old_password: {
        en: "Old password",
        de: "Altes Passwort",
        fr: "Vieux mot de passe",
        es: "Contraseña Anterior",
        zh: "旧密码",
        ja: "元のパスワード",
        ko: "전 암호",
        it: "Vecchia password",
        pt: "Senha Antiga",
        ru: "Старый пароль",
        pl: "Stare hasło"
    },

    old_password_error: {
        en: "Old password is incorrect",
        de: "Altes Passwort ist falsch",
        fr: "Vieux mot de passe incorrect",
        es: "La antigua contraseña es incorrecta",
        zh: "旧密码不正确",
        ja: "入力された元のパスワードが間違っています",
        ko: "전 암호가 틀립니다",
        it: "La vecchia password è scorretta",
        pt: "Senha antiga está incorreta",
        ru: "Старый пароль введен неправильно",
        pl: "Stare hasło jest nieprawidłowe"
    },

    good_password: {
        en: "Password is successfully saved",
        de: "Passwort wird erfolgreich gespeichert",
        fr: "Mot de passe sauvegardé",
        es: "La contraseña ha guardado correctamente",
        zh: "密码保存成功",
        ja: "パスワードが無事に保存されました",
        ko: "암호가 저장되었습니다",
        it: "La password è salvata",
        pt: "A senha é guardada com sucesso",
        ru: "Пароль успешно сохранен",
        pl: "Hasło zostanie pomyślnie zapisane"
    },

    length_password: {
        en: "The length of password is 4 symbols",
        de: "Die Länge des Passworts ist 4 Zeichen",
        fr: "Mot de passe se compose de 4 symboles",
        es: "La longitud de la contraseña es de 4 caracteres",
        zh: "密码长度为4个字符",
        ja: "パスワードの文字数が4です",
        ko: "암호의 길이는 4 자입니다",
        it: "La lunghezza della password è di 4 simboli",
        pt: "O comprimento da senha é de 4 simbols",
        ru: "Длина пароля 4 символа",
        pl: "Długość hasła wynosi 4 symboli"
    },

    incorrect_password: {
        en: "Incorrect password",
        de: "Falsches Passwort",
        fr: "Mot de passe incorrect",
        es: "La contraseña incorrecta",
        zh: "密码不正确",
        ja: "入力されたパスワードが間違っています",
        ko: "암호가 틀립니다",
        it: "La password è scorretta",
        pt: "Senha incorreta",
        ru: "Неправильно ввели пароль",
        pl: "Niepoprawne hasło"
    },

    are_you_sure: {
        en: "DELETE<br>ARE YOU SURE?",
        de: "LÖSCHEN<br>SIND SIE SICHER?",
        fr: "SUPPRIMER<br>ETES-VOUS SUR?",
        es: "BORRAR<br>Estás seguro?",
        zh: "你确定要删除吗？",
        ja: "本当に削除しますか?",
        ko: "삭제",
        it: "CANC<br>SEI SICURO?",
        pt: "CANCELAR<br>TEM CERTEZA?",
        ru: "УДАЛИТЬ<br>ВЫ УВЕРЕНЫ?",
        pl: "USUŃ. Czy jesteś pewien?"
    },

    cancel: {
        en: "CANCEL",
        de: "ABBRECHEN",
        fr: "DECOMMANDER",
        es: "CANCELAR",
        zh: "取消",
        ja: "キャンセル",
        ko: "취소",
        it: "ANNULLA",
        pt: "Limpar",
        ru: "ОТМЕНА",
        pl: "ANULUJ"
    },

    ok: {
        en: "OK",
        de: "OK",
        fr: "OK",
        es: "OK",
        zh: "确定",
        ja: "OK",
        ko: "예",
        it: "OK",
        pt: "OK",
        ru: "ОК",
        pl: "Dobrze"
    },

    add: {
        en: "Add",
        ru: "Добавить",
        de: "Hinzufügen",
        es: "Adicionar",
        fr: "Ajouter",
        it: "Aggiungi ",
        ja: "加える",
        ko: "추가하기",
        pl: "Dodać",
        zh: "添加",
        pt: "Adicionar"
    },

    calendar: {
        en: "Calendar",
        ru: "Календарь",
        de: "Kalendar",
        fr: "Calendrier",
        es: "Calendario",
        zh: "日历",
        ja: "カレンダー",
        ko: "달력",
        it: "Calendario",
        pl: "Kalendarz",
        pt: "Calendario"
    },

    search: {
        en: "Search",
        ru: "Поиск",
        de: "Suche",
        fr: "Recherche",
        es: "Búsqueda",
        zh: "搜索",
        ja: "検索",
        ko: "검색",
        it: "Ricerca",
        pl: "Szukanie",
        pt: "Pesquisa"
    },

    themes: {
        en: "Skins",
        ru: "Темы",
        de: "Skins",
        fr: "les thèmes",
        es: "Temas",
        zh: "设计",
        ja: "スキン",
        ko: "스킨",
        it: "Skin",
        pl: "Tematy",
        pt: "Temas"
    },

    font_theme: {
        en: "Choose font",
        ru: "Выбрать Шрифт",
        de: "Schriftart wählen",
        fr: "Choisir des types",
        es: "Seleccionar la fuente",
        zh: "选择字体",
        ja: "フォントを選ぶ",
        ko: "세체 바꾸기",
        it: "Scegliere il carattere",
        pl: "Wybierz czcionkę",
        pt: "Selecionar o fonte"
    },

    a1: {
        en: "Yippee! You've written your first log!",
        de: "Hurra! Du hast deine erste Notiz geschrieben!",
        fr: "Très bien! Tu as publié ton premier message!",
        es: "¡Que bien! ¡Escribiste tu primer mensaje!",
        zh: "耶！你写你的第一个日志！",
        ja: "ヤッホー！初めての記録を書いたね！",
        ko: "첫 메세지 완료! 잘한다!",
        it: "Brava! Hai scritto nel diario per la prima volta!",
        pt: "Hooray! Você escreveu seu primeiro log!",
        ru: "Ты добавила свой первый секрет",
        pl: "Świetnie! Napisałaś swoją pierwszą wiadomość!"
    },

    a2: {
        en: "You’ve already written three logs today, can you do more?",
        de: "Sie haben bereits drei Notizen heute geschrieben, kannst du mehr tun?",
        fr: "Tu as déjà écrit 3 messages aujourd'hui! Tu veux en écrire plus?",
        es: "¿Has escrito tres mensajes de hoy, puedes escribir más?",
        zh: "你已经写了三个日志，你能做的更多？",
        ja: "今日は記録を３つ書いて、素晴らしい！もっともっと書きましょうね！",
        ko: "오늘 3 메시지를 써놓음. 더 하나 쓸까요?",
        it: "Hai già scritto 3 volte, scrivi ancora?",
        pt: "Você já escreveu três logs hoje, você pode fazer mais?",
        ru: "Ты сегодня написала уже 3 сообщения",
        pl: "Dziś napisałaś 3 wiadomości, dalej je pisz!"
    },

    a3: {
        en: "It’s great that you write almost every day!",
        de: "Es ist großartig, dass du fast jeden Tag schreibst!",
        fr: "C'est magnifique, tu écris chaque jour!",
        es: "¡Es genial que escribes casi todos los días!",
        zh: "几乎每天你写的都很好！",
        ja: "ほとんど毎日書いて、本当によかったね！",
        ko: "거의 매일 메시지를 써주니까 참 좋죠! ",
        it: "Che bello, scrivi quasi tutti i giorni!",
        pt: "É ótimo que você escreve quase todos os dias!",
        ru: "Как здорово, ты пишешь почти каждый день!",
        pl: "Świetnie! Prawie codziennie piszesz!"
    },

    a4: {
        en: "You are developing your writing skills with every log!",
        de: "Du entwickelst deine Schreibfähigkeiten mit jeder Notiz!",
        fr: "Tu écris de mieux en mieux!",
        es: "¡Estás desarrollando tus habilidades como escritor con cada mensaje!",
        zh: "每个日志都有提高写作技巧！",
        ja: "各記録を書いて、文章力を鍛えるわ！",
        ko: "각 메시지는 재주를 발달시켜줍니다.",
        it: "Ogni volta che scrivi, impari a scrivere meglio!",
        pt: "Você está desenvolvendo suas habilidades como escritor com cada log!",
        ru: "С каждым сообщение ты развиваешь свои письменные навыки.",
        pl: "Pisząc każdą wiadomość rozwijasz swoje umiejętności pisarskie."
    },

    a5: {
        en: "Yippee!<br>You have 50 logs now!",
        de: " Hurra!<br>Du hast jetzt 50 Notizen!",
        fr: "Très bien!<br>Tu as écrit 50 messages!",
        es: "¡Que bien!<br>¡Tienes 50 mensajes ahora!",
        zh: "开心<br>你现在有50的日志啦！",
        ja: "おお、記録はもう５０！",
        ko: "와우! 50 메시지를 썼음! ",
        it: "Brava!<br>50 volte!",
        pt: "Hooray!<br>Você tem 50 notas agora!",
        ru: "Ура!<br>У тебя уже 50 сообщений!",
        pl: "Świetnie!<br>Masz już 50 wiadomości!"
    },

    a6: {
        en: "Great! It’s good that you write every day – you won’t forget anything!",
        de: "Großartig! Es ist gut, dass du jeden Tag schreibst – du wirst nichts vergessen!",
        fr: "Super! Écris chaque jour pour ne rien oublier!",
        es: "¡Wow! ¡Qué bueno que escribes todos los días - no te olvides de nada!",
        zh: "很好，每一天都在写–你不会忘记任何事情！",
        ja: "よかったね！毎日書いて素晴らしい！何も忘れないわよね！",
        ko: "매일 틀림없이 쓰니까 진짜 잘하고 있어요! 이렇게 하루를 잊을 리가 없을 걸? ",
        it: "Brava! Scrivi tutti i giorni, che bello! Non ti dimenticherai di niente!",
        pt: "Otimo! É bom que você escreve todos os dias - você não vai esquecer de nada!",
        ru: "Здорово! Как хорошо, что ты пишешь каждый день – ничего не забудешь!",
        pl: "Świetnie! Bardzo dobrze, że codziennie piszesz - o niczym nie zapomnisz!"
    },

    a7: {
        en: "It’s only 2 logs and you will have 100 notes!",
        de: "Es braucht nur 2 Notizen, und du wirst 100 Notizen haben!",
        fr: "Deux messages de plus, et tu auras écrit 100 messages!",
        es: "¡2 mensajes más y vas a tener los 100 mensajes!",
        zh: "只有2个日志并且你将有100个笔记！",
        ja: "記録を２つを書いて、１００を届くわよ！",
        ko: "메시지 2 개 더 쓰면 총 100 메시지거 됩니다. 예쁘죠?",
        it: "Mancano 2 volte a 100!",
        pt: "Com apenas 2 notas você terá 100!",
        ru: "Еще 2 сообщения и у тебя будет целых 100 сообщений!",
        pl: "Jeszcze 2 wiadomości aby nabrać 100 wiadomości!"
    },

    a8: {
        en: "Wow, you have 100 logs! You are just like a real writer!",
        de: "Wow, du hast 100 Notizen! Du bist gerade wie ein echter Schriftsteller!",
        fr: "Très bien! Tu as écrit 100 messages! Tu peux devenir écrivaine!",
        es: "¡Wow, tienes 100 mensajes! ¡Eres como un escritor de verdad!",
        zh: "哇，你有100个日志啦！你就像一个真正的作家！",
        ja: "うわー、記録は１００！本物の作家みたいね！",
        ko: "100 메세지. 작가가 된 거 아니에요? ",
        it: "100 volte! Sei come una vera scrittrice!",
        pt: "Uau, você tem 100 notas! Você é como um escritor de verdade!",
        ru: "Ух ты, у тебя уже 100 сообщений! Ты как настоящая писательница!",
        pl: "Nieżle, masz już 100 wiadomości! Stajesz się prawdziwą pisarką!"
    },

    a9: {
        en: "Whoa! You have 500 notes, you have really done an awesome job!",
        de: "Hurra!! Du hast 500 Notizen, du hast wirklich einen tollen Job getan!",
        fr: "Quel bon résultat! 500 messages!",
        es: "¡Wow! ¡500 Mensajes es fantástico!",
        zh: "哇！你有500个笔记了，你真的做了一个超赞的工作！",
        ja: "信じられないわ！記録は５００！すごいじゃん！",
        ko: "와우! 500 메시지! 정말 잘하고 있네요! ",
        it: "500 volte! Sei proprio bravo!",
        pt: "Oi! Você tem mais de 500 notas, você realmente fez um trabalho incrível!",
        ru: "Вот это да! 500 собщений, ты настоящая молодец!",
        pl: "Świetnie! 500 wiadomości, gratulacje!"
    }
};

var _notif = {
    n1: {
        en: "How was your day? Write about it in the Diary.",
        de: "Wie war dein Tag? Schreibe darüber im Tagebuch.",
        fr: "Ça va? Écris un message pour ton journal intime.",
        es: "¿Cómo fue tu día? Escribe al respecto en el Diario.",
        zh: "你今天怎么样？写在日记里。",
        ja: "今日はどうだったの？日記で書きましょうか！",
        ko: "오늘 좀 어땠어? 말해봐요.",
        it: "Com’è andata la giornata? Scrivi sul diario!",
        pt: "Como foi seu dia? Escrever no Diário.",
        ru: "Как прошел твой день? Напиши об этом в Дневнике.",
        pl: "Jak minął twój dzień? Napisz o tym w pamiętniku."
    },

    n2: {
        en: "Write about your day in the Diary and don’t forget anything.",
        de: "Schreibe über deinen Tag im Tagebuch und vergiss nichts.",
        fr: "Écris un message pour ne rien oublier.",
        es: "Escribe sobre tu día en el Diario y no olvides nada.",
        zh: "你的一天写在日记里，别忘了任何东西。",
        ja: "この日を忘れないように日記で書きましょうか？",
        ko: "오늘 하루가 잊어지지 않게 일기에서 오늘 일에 대해 써봐요.",
        it: "Per non dimenticare la giornata, descrivila nel diario!",
        pt: "Escreva sobre o seu dia no Diário e não esquecer de nada.",
        ru: "Чтобы не забыть сегодняшний день, напиши о нем в Дневнике.",
        pl: "Aby nie zapomnieć o dzisiejszym dniu, napisz o nim w pamiętniku."
    },

    n3: {
        en: "How was your day? Is it different from the yesterday?",
        de: "Wie war dein Tag? Ist es von gestern verschieden?",
        fr: "Quoi de neuf aujourd'hui? Quelque chose d'intéresssant?",
        es: "¿Y cómo fue tu día hoy? ¿Es diferente de ayer?",
        zh: "你今天怎么样？和昨天有什么不同？",
        ja: "今日はどうだったのか？昨日とだいぶ違うはずだね！",
        ko: "오늘과 어제의 차이는 뭐예요?",
        it: "Cosa hai fatto oggi? Questa giornata è diversa dalla giornata di ieri?",
        pt: "Como foi seu dia? É diferente do de ontem?",
        ru: "А как прошел твой день сегодня, чем он отличается от вчерашнего?",
        pl: "Jak minął dzisiejszy dzień, czym się różnił od wczorajszego?"
    },

    n4: {
        en: "Come back to the Diary, it misses your logs!",
        de: "Komm zum Tagebuch zurück, es verpasst deine Notizen! ",
        fr: "N'oublie pas d'écrire dans ton journal intime!",
        es: "¡Vuelve a tu Diario, que extraña a tus mensajes!",
        zh: "回到日记本，它想念你的日志！",
        ja: "日記は寂しいわ、、、戻ってください、、、",
        ko: "일기를 완전히 버린 거 아니에요? 뉴스를 알고 싶네요.",
        it: "Ricomincia a scrivere sul diario, gli manchi!",
        pt: "Volta para o Diário, ele sente falta os seus logs!",
        ru: "Возвращайся в Дневник, он скучает по твоим сообщениям!",
        pl: "Wróć do pamiętnika, już dawno nic nie pisałaś!"
    },

    n5: {
        en: "No one keeps your secrets like the Diary does!",
        de: "Keiner behält deine Geheimnisse wie dieses Tagebuch!",
        fr: "Ton journal intime protégera tes secrets!",
        es: "¡Nadie guarda tus secretos como el Diario!",
        zh: "没有人会像日记一样保守你的秘密！",
        ja: "日記はあなたの秘密を絶対守る！",
        ko: "일기는 비밀을 아무에게도 말 안 할 거다.",
        it: "Nessuno custodisce i tuoi segreti così bene come il diario!",
        pt: "Ninguém mantém seus segredos como o Diário faz!",
        ru: "Никто не сохранит твои секреты так, как Дневник!",
        pl: "Nikt lepiej nie zachowa twoich sekretów niż pamiętnik!"
    },

    n6: {
        en: "Don’t forget to write about your day!",
        de: "Vergiss nicht, über deinen Tag zu schreiben!",
        fr: "N'oublie pas de partager tes impressions!",
        es: "¡No te olvides de escribir acerca de tu día!",
        zh: "不要忘了写关于你的一天！",
        ja: "今日はどうだったと書くのを忘れないでね！",
        ko: "오늘 하루가 어땠는지 잊지 말고 꼭 꼭 써줘요!",
        it: "Non dimenticarti di scrivere di com’è andata la giornata.",
        pt: "Não esqueça escrever sobre seu dia!",
        ru: "Не забудь записать, как прошел твой день",
        pl: "Nie zapomnij napisać, jak minął dzień"
    }
};
