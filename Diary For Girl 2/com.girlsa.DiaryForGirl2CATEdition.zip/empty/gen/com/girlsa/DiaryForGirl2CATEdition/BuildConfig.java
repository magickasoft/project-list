/** Automatically generated file. DO NOT MODIFY */
package com.girlsa.DiaryForGirl2CATEdition;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}