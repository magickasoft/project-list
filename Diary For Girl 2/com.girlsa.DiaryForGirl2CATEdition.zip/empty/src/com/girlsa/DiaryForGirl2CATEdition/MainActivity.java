package com.girlsa.DiaryForGirl2CATEdition;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.net.URISyntaxException;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;

import android.annotation.TargetApi;
import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentUris;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.ValueCallback;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.am.js.AlarmHelper;
import com.am.js.CameraHelper;
import com.am.js.FileHelper;
import com.am.js.ImagePickHelper;
import com.am.js.jsapi;
import com.girlsa.DiaryForGirl2CATEdition.R;

public class MainActivity extends Activity implements View.OnClickListener {

    private MainWebView webView;
    public ImageView errorImage;
    public RelativeLayout errorLayout;
    private Timer timer = null;
    private TimerTask timerTask = null;
    private Drawable picture;
    public ValueCallback<Uri> mUploadMessage;
    public final static int FILE_CHOOSER_RESULT_CODE = 1;
    private State state;
    private jsapi jsapi;
    private Menu menu;
    private String locale;
    
    //for alarm
    private Intent startedIntent=null;
    
    
    private Drawable
            backNDrawable,
            backDrawable,
            forwardNDrawable,
            forwardDrawable,
            refreshDrawable,
            refreshNDrawable;

    private MenuItem
            backItem,
            forwardItem,
            refreshItem,
            exitItem;
    
    private void keepScreenOn() {
    	this.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }
    
    public final String SHOW_PROGRESS_BAR = "true";
    public final String LOAD_URL = "load_url";
    public final String LOAD_HTML = "load_html";
    public final String SHOW_ACTION_BAR = "true";
    public final String SET_SUPPORT_ZOOM = "true";
    public final String USE_WIDE_VIEW_PORT = "true";
    public final String USE_JS_API = "true";

    public jsapi getJsapi() {
        return jsapi;
    }

    public enum State {LoadUrl, LoadHtml}

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        if (requestCode == FILE_CHOOSER_RESULT_CODE) {
            
        	if (mUploadMessage == null)
                return;
            Uri result = intent == null || resultCode != RESULT_OK ? null : intent.getData();
            mUploadMessage.onReceiveValue(result);
            mUploadMessage = null;
        }
        else if (requestCode == CameraHelper.CAMERA_CAPTURED_IMAGE_REQ_CODE) {
	        //
        	if (resultCode == RESULT_OK) {
	        	
	    	    CameraHelper cameraHelper=CameraHelper.getInstance(this, webView);
	    	    String lastFilePath= cameraHelper.getLastFilePath();
	    	    
	    	    File f = new File(lastFilePath);
	    	    Uri contentUri = Uri.fromFile(f);
	    	    
	    	    getContentResolver().notifyChange(contentUri, null);
	    	    
	    	    ImageManager.rotateNSave(lastFilePath);
	    	    
                Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,contentUri);
	    	    sendBroadcast(mediaScanIntent);
                
                cameraHelper.processImage(lastFilePath);
	    	    
	        } else if (resultCode == RESULT_CANCELED) {
	            // User cancelled the image capture
	        } else {
	            // Image capture failed, advise user
	        }
	    }
        else if (requestCode == ImagePickHelper.CHOOSE_PHOTO_REQ_CODE) {
        
        	
        	if (resultCode == RESULT_OK) {
        		if(intent==null||intent.getData()==null)
        			return;

	        	ImagePickHelper imagePickHelper=new ImagePickHelper(this,webView);
	        	String realFilePath=imagePickHelper.getRealPathFromURI(intent.getData());
	        	
	        	if(realFilePath!=null){
	        	
	        		ImageManager.rotateNSave(realFilePath);
	        	
		        	imagePickHelper.processImage(intent.getData());
	        	}
	        	else{
	        	
	        		File file=null;
	    			try {
	    				
	    				
	    				InputStream inputStream = this.getContentResolver().openInputStream(
	    						intent.getData());
	    				
	    	        	String newPath=intent.getData().getLastPathSegment()
	    	        			.replace("/", "").replace(":", "").replace(".", "");
	    	        	Logging.trace("hashBmap "+newPath);
	    				
	    	        	file = CameraHelper.getInstance(this, webView)
	    						.getOutputMediaFile(newPath);
	    				OutputStream outputStream = new FileOutputStream(file);

	    				byte[] buf = new byte[1024];
	    				int len;
	    				while ((len = inputStream.read(buf)) > 0) {
	    					outputStream.write(buf, 0, len);
	    					
	    				}
	    				
	    				outputStream.close();
	    				inputStream.close();
	    				
	    				ImageManager.rotateNSave(file.getPath());
			        	imagePickHelper.processImage(file.getPath());
	    				
	    				
	    				Uri contentUri=Uri.fromFile(file);
	    				Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,contentUri);
	    	    	    sendBroadcast(mediaScanIntent);
	                    
	    				
	    			} catch (IOException e) {
	    	
	    				imagePickHelper.genWebConnectErrorEvent();
	    				if(file!=null)
	    					FileHelper.deleteFile(file.getPath());
	    				
	    				e.printStackTrace();
	    				
	    			}
	    			
	        	}
	        	
	        	
	        } else if (resultCode == RESULT_CANCELED) {
	            // User cancelled the image capture
	        } else {
	            // Image capture failed, advise user
	        }
        	
	    }
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
  
        
        //alarm
        startedIntent=getIntent();
        keepScreenOn();
        	
        
       
        
        switch (getResources().getString(R.string.ORIENTATION)) {
            case "portrait":
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
                break;
            case "landscape":
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
                break;
            case "unspecified":
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
                break;
        }

        if (getResources().getString(R.string.SHOW_ACTION_BAR).equals(SHOW_ACTION_BAR)) {
            setTheme(android.R.style.Theme_Holo);
        } else {
            this.requestWindowFeature(Window.FEATURE_NO_TITLE);
            this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
        
        
        switch (getResources().getString(R.string.LOAD_METHOD)) {
            case LOAD_URL:
                state = State.LoadUrl;
                break;
            case LOAD_HTML:
                state = State.LoadHtml;
                break;
        }

        
        webView = new MainWebView(this);
        //jsapi needs webView to generate events in js code
        jsapi = new jsapi(this, webView);
        
        View wholeScreen = webView.getLayout();
        errorLayout = (RelativeLayout)wholeScreen.findViewById(R.id.errorLayout);
        errorImage = (ImageView) wholeScreen.findViewById(R.id.errorImage);
        errorLayout.setVisibility(View.GONE);
        errorLayout.setOnClickListener(this);
        

        
        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        }
        
        switch (state) {
            case LoadUrl:
                webView.loadRemoteUrl(getResources().getString(R.string.APP_URL));
                break;
            case LoadHtml:
                String index = "index.html";
                
                try {
                    locale = getResources().getConfiguration().locale.getLanguage();
                        if (Arrays.asList(getResources().getAssets().list("res")).contains("index_" + locale + ".html")) {
                            index = "index_" + locale + ".html";
                    }
                } catch (IOException e) {
                    Logging.err(e);
                }
                
                
                
                webView.loadUrl("file:///android_asset/res/" + index);
                
                break;
        }
        setContentView(wholeScreen);

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.HONEYCOMB) {
            ActionBar actionBar = getActionBar();
            if (actionBar != null) {
                actionBar.setDisplayShowHomeEnabled(false);
                actionBar.setDisplayShowTitleEnabled(false);
            }
        }
        
        
        
        
        Timer timer1 = new Timer();
        Timer timer2 = new Timer();
        Timer timer3 = new Timer();
        if (getString(R.string.FULLSCREEN_BANNER).equals("true")) {
        	//timer1.schedule(new showBanner(), 30000);
        	//timer2.schedule(new showBanner(), 90000);
        	//timer3.schedule(new showBanner(), 120000);
        }
        //webView.loadUrl("javascript:window.dispatchEvent(deviceready)");
        
    }
    
    class showBanner extends TimerTask {
    	@Override
    	public void run() {
    				try {
    	                Class<?> events = Class.forName("com.am.events.Event");
    	                java.lang.reflect.Method showInterstitialMethod = events.getMethod("showInterstitial", (Class[]) null);
    	                showInterstitialMethod.invoke(null);
    	            } catch (Exception e) {
    	                android.util.Log.e("Events", "showInterstitial Error!", e);
    	            }
    	}
    }
    
    
    public void processWebViewStart(WebView webView){
    	
    	
    	
    	if(startedIntent.getBooleanExtra("isAlarm", false)==true){
    		processWebViewAlarm(startedIntent);
    	}
    }
    
    private void processWebViewAlarm(Intent intent){
    	
    	int alarmId=intent.getIntExtra("alarmId", -1);
    	AlarmHelper.generateWebViewAlarm(webView, alarmId);
		
		
    	AlarmHelper alarmHelper=new AlarmHelper(this, MainActivity.class);
    	alarmHelper.processAlarmCome(alarmId);
    	
    	
        
     	Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
        window.addFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
    	
		//TODO
		intent.putExtra("isAlarm", false);
    }
    
    protected void onNewIntent (Intent intent){

    	Logging.trace("start onNewIntent ");
    	
 
    	if(intent.getBooleanExtra("isAlarm", false)==true){
    		Log.i("onNewIntent", "generate alarm");
    		processWebViewAlarm(intent);
    	}
    }
    
    
    @Override
    protected void onStart() {
        super.onStart();
        //com.am.analytics.StartStopDetector.onBind(this);
    }

    
    @Override
    protected void onResume() {
        super.onResume();
        Log.i("onResume", "start");
        
        jsapi.getJavaExecutor().resumeWork();
        jsapi.getJavaExecutor().restoreAllMedia();
        keepScreenOn();
        try {
            Class.forName("android.webkit.WebView").getMethod("onResume", (Class[])null).invoke(webView, (Object[])null);
        } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            Logging.err(e);
        }
        
    }

    @Override
    protected void onPause() {
        super.onPause();
        
        jsapi.getJavaExecutor().pauseWork();
        jsapi.getJavaExecutor().muteAllMedia();
        
        try {
            Class.forName("android.webkit.WebView").getMethod("onPause", (Class[])null).invoke(webView, (Object[])null);
        } catch (ClassNotFoundException | NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
            Logging.err(e);
        }
    }
    
    @Override
    protected void onStop() {
        super.onStop();
        //com.am.analytics.StartStopDetector.onUnbind(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
    
    public void showAd() {
    	Toast.makeText(this, "Test ad!", Toast.LENGTH_LONG).show();
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
		String exit, refresh, back, forward;
		switch (locale) {
		case "en": {
    		exit = "Exit";
    		refresh = "Refresh";
    		back = "Back";
    		forward = "Forward";
    		break;
    	}
    	case "ru": {
    		exit = "Выход";
    		refresh = "Обновить";
    		back = "Назад";
    		forward = "Вперёд";
    		break;
    	}
    	case "ko": {
    		exit = "엑시트";
    		refresh = "새로 고칩니다";
    		back = "뒤에";
    		forward = "앞으로";
    		break;
    	}
    	case "es": {
    		exit = "Salir";
    		refresh = "Actualizar";
    		back = "Atrás";
    		forward = "Adelante";
    		break;
    	}
    	case "ja": {
    		exit = "終了";
    		refresh = "リフレッシュする";
    		back = "バック";
    		forward = "フォワード";
    		break;
    	}
    	case "zh": {
    		exit = "出口";
    		refresh = "刷新";
    		back = "向后";
    		forward = "向前";
    		break;
    	}
    	case "de": {
    		exit = "Ausgang";
    		refresh = "Erfrischen";
    		back = "Zurück";
    		forward = "Voran";
    		break;
    	}
    	case "it": {
    		exit = "Uscire";
    		refresh = "Rifrescare";
    		back = "Indietro";
    		forward = "Avanti";
    		break;
    	}
    	case "fr": {
    		exit = "Quitter";
    		refresh = "Rafraîchir";
    		back = "Retour";
    		forward = "En avant";
    		break;
    	}
    	case "pl": {
    		exit = "Wyjście";
    		refresh = "Odśwież";
    		back = "Z powrotem";
    		forward = "Do przodu";
    		break;
    	}
    	default: {
    		exit = "Exit";
    		refresh = "Refresh";
    		back = "Back";
    		forward = "Forward";
    		break;
    	}
	}
    	
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        this.menu = menu;

//        init drawables
        backDrawable = getResources().getDrawable(R.drawable.back);
        backNDrawable = getResources().getDrawable(R.drawable.back_n);
        forwardDrawable = getResources().getDrawable(R.drawable.forward);
        forwardNDrawable = getResources().getDrawable(R.drawable.forward_n);
        refreshDrawable = getResources().getDrawable(R.drawable.update);
        refreshNDrawable = getResources().getDrawable(R.drawable.update_n);

        menu.findItem(R.id.exit).setIcon(getResources().getDrawable(R.drawable.close));
//        init MenuItems
        refreshItem = menu.findItem(R.id.refresh);
        refreshItem.setIcon(refreshNDrawable);
        refreshItem.setVisible(false);
        backItem = menu.findItem(R.id.back);
        backItem.setIcon(backNDrawable);
		backItem.setVisible(false);
        forwardItem = menu.findItem(R.id.forward);
        forwardItem.setIcon(forwardNDrawable);
		forwardItem.setVisible(false);
        exitItem = menu.findItem(R.id.exit);
        exitItem.setTitle(exit);
		refreshItem.setTitle(refresh);
        backItem.setTitle(back);
        forwardItem.setTitle(forward);
        return true;
    }

    @TargetApi(Build.VERSION_CODES.CUPCAKE)
    @Override
    public boolean onMenuOpened(int featureId, Menu menu) {
        if (webView.inFullScreenVideo() || getResources().getString(R.string.SHOW_ACTION_BAR).equals(SHOW_ACTION_BAR)) {
            return false;
        }
        switch (state) {
            case LoadUrl:
                if (!checkNetworkConnection()) {
                   setInactiveDrawables();
                } else {
                    setDrawables();
                }
                break;
            case LoadHtml:
                setDrawables();
                break;
        }
        return super.onMenuOpened(featureId, menu);
    }

    public void setDrawables() {
        if (menu != null) {
            if (webView.canGoBack()) {
                backItem.setIcon(backDrawable);
            } else {
                backItem.setIcon(backNDrawable);
            }

            if (webView.canGoForward()) {
                forwardItem.setIcon(forwardDrawable);
            } else {
                forwardItem.setIcon(forwardNDrawable);
            }
            refreshItem.setIcon(refreshDrawable);
        }
    }

    public void setInactiveDrawables() {
        backItem.setIcon(backNDrawable);
        forwardItem.setIcon(forwardNDrawable);
        refreshItem.setIcon(refreshNDrawable);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.back:
                if (state == State.LoadUrl && !checkNetworkConnection()) {
                    break;
                }
                if (webView.canGoBack()) {
                    webView.goBack();
                    errorLayout.setVisibility(View.GONE);
                    webView.webViewLayout.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.forward:
                if (state == State.LoadUrl && !checkNetworkConnection()) {
                    break;
                }
                if (webView.canGoForward()) {
                    webView.goForward();
                    errorLayout.setVisibility(View.GONE);
                    webView.webViewLayout.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.refresh:
                if (state == State.LoadUrl && !checkNetworkConnection()) {
                    break;
                } else {
                    webView.reload();
                }
                break;
            case R.id.exit:
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        Logging.info();
        if (state == State.LoadUrl && !checkNetworkConnection()) {
            showExitDialog();
        } else {
            if (webView.inFullScreenVideo())
                webView.hideCustomView();
            else if (webView.canGoBack()) {
                webView.goBack();
                errorLayout.setVisibility(View.GONE);
                webView.webViewLayout.setVisibility(View.VISIBLE);
            } else {
                showExitDialog();
            }
        }
    }

    private void showExitDialog(){
    	String title;
    	String negative;
    	String positive;
    	switch (locale) {
	    	case "en": {
	    		title = "Are you really want to quit?";
	    		positive = "Yes";
	    		negative = "No";
	    		break;
	    	}
	    	case "ru": {
	    		title = "Вы действительно хотите выйти?";
	    		positive = "Да";
	    		negative = "Нет";
	    		break;
	    	}
	    	case "ko": {
	    		title = "당신은 정말 �?가고 싶습니까?";
	    		positive = "네";
	    		negative = "아니요";
	    		break;
	    	}
	    	case "zh": {
	    		title = "你真的要退出吗？";
	    		positive = "�?�";
	    		negative = "否";
	    		break;
	    	}
	    	case "es": {
	    		title = "¿Quieres salir de verdad?";
	    		positive = "Si";
	    		negative = "No";
	    		break;
	    	}
	    	case "fr": {
	    		title = "Voulez-vous quitter?";
	    		positive = "Oui";
	    		negative = "Non";
	    		break;
	    	}
	    	case "pl": {
	    		title = "Czy na pewno chcesz skończyć?";
	    		positive = "Tak";
	    		negative = "Nie";
	    		break;
	    	}
	    	case "de": {
	    		title = "Sind Sie sicher, dass Sie gehen aus wollen?";
	    		positive = "Ya";
	    		negative = "Nein";
	    		break;
	    	}
	    	case "ja": {
	    		title = "終了してもよろしいですか？";
	    		positive = "イエス";
	    		negative = "ノー";
	    		break;
	    	}
	    	case "it": {
	    		title = "Sei sicuro che vuoi smettere?";
	    		positive = "Si";
	    		negative = "No";
	    		break;
	    	}
	    	default: {
	    		title = "Are you really want to quit?";
	    		positive = "Yes";
	    		negative = "No";
	    		break;
	    	}
    	}
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        dialogBuilder.setTitle(title);
        dialogBuilder.setNegativeButton(negative, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        dialogBuilder.setPositiveButton(positive, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                MainActivity.this.finish();
            }
        });
        dialogBuilder.show();
    }

    public boolean checkNetworkConnection() {
        ConnectivityManager connectivityManager = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return networkInfo != null && networkInfo.isConnected();
    }

    public void showErrorScreen(boolean isNetworkReason) {
        webView.webViewLayout.setVisibility(View.GONE);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        int imageSideSize = displayMetrics.widthPixels / 2;
        if (isNetworkReason) {
            errorLayout.setBackgroundColor(getResources().getColor(R.color.error_connection_screen));
            picture = getResources().getDrawable(R.drawable.error_connection);
        }
        else {
            errorLayout.setBackgroundColor(getResources().getColor(R.color.error_screen));
            picture = getResources().getDrawable(R.drawable.error_oops);
        }
        Bitmap bitmap = ((BitmapDrawable)picture).getBitmap();
        int bitmapSize = bitmap.getWidth();
        float scaleSize = ((float)imageSideSize) / bitmapSize;
        Matrix matrix = new Matrix();
        matrix.postScale(scaleSize, scaleSize);
        Bitmap resultBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmapSize, bitmapSize, matrix, false);
        errorImage.setImageBitmap(resultBitmap);
        errorLayout.setVisibility(View.VISIBLE);
    }

    @Override
    public void onClick(View view) {
        if (checkNetworkConnection()) {
            //webView.progressBar.setVisibility(View.GONE);
            errorLayout.setVisibility(View.GONE);
            webView.loadUrl(webView.getCurrentUrl());
            webView.webViewLayout.setVisibility(View.VISIBLE);
        }
        else {
            //webView.progressBar.setVisibility(View.VISIBLE);
            if (timer == null && timerTask == null) {
                timer = new Timer("Progress_Timer");
                timerTask = new TimerTask() {
                    @Override
                    public void run() {
                        MainActivity.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                //webView.progressBar.setVisibility(View.GONE);
                            }
                        });
                        timer.cancel();
                        timerTask.cancel();
                        timer = null;
                        timerTask = null;
                    }
                };
                timer.schedule(timerTask, 2000);
            }
        }
    }
    public boolean inErrorScreen() {
        return errorLayout.getVisibility() == View.VISIBLE;
    }
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (inErrorScreen()) {
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            int imageSideSize = displayMetrics.widthPixels / 2;
            Bitmap bitmap = ((BitmapDrawable)picture).getBitmap();
            int bitmapSize = bitmap.getWidth();
            float scaleSize = ((float)imageSideSize) / bitmapSize;
            Matrix matrix = new Matrix();
            matrix.postScale(scaleSize, scaleSize);
            Bitmap resultBitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmapSize, bitmapSize, matrix, false);
            errorImage.setImageBitmap(resultBitmap);
        }
    }

    @Override
    public boolean onKeyDown(int keycode, KeyEvent event) {
        return jsapi.getJavaExecutor().onKeyDown(keycode, webView) || super.onKeyDown(keycode, event);
    }
     
}

