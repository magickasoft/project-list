package com.girlsa.DiaryForGirl2CATEdition;

import android.content.Intent;
import android.net.Uri;
import android.util.JsonReader;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.*;
import android.widget.FrameLayout;
import android.widget.VideoView;
import com.am.js.jsapi;
import com.google.gson.Gson;
import com.girlsa.DiaryForGirl2CATEdition.R;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import com.girlsa.DiaryForGirl2CATEdition.R;

public class MainWebChromeClient extends WebChromeClient {

    private final String TEMP_TAG = "|||VideoTest|||";

    private View videoProgressView;

    public View customView;
    private CustomViewCallback customViewCallback;
    private MainActivity activity;
    private MainWebView mainWebView;

    
    public MainWebChromeClient(MainActivity activity, MainWebView mainWebView) {
        this.activity = activity;
        this.mainWebView = mainWebView;
    }

    @Override
    public void onShowCustomView(View view, CustomViewCallback callback) {
        Logging.trace(TEMP_TAG);
        super.onShowCustomView(view, callback);
        if (customView != null) {
            callback.onCustomViewHidden();
            return;
        }
        customView = view;
        customViewCallback = callback;

        if (customView instanceof FrameLayout) {
            FrameLayout layout = (FrameLayout) customView;
            if (layout.getFocusedChild() instanceof VideoView) {
                VideoView video = (VideoView) layout.getFocusedChild();
                layout.removeView(video);
                activity.setContentView(video);
                video.start();
            }
        }
        mainWebView.setVisibility(View.GONE);
        mainWebView.getFullScreenVideoLayout().addView(customView);
        mainWebView.getFullScreenVideoLayout().setVisibility(View.VISIBLE);
    }

    @Override
    public void onHideCustomView() {
        if (customView == null)
            return;
        customView.setVisibility(View.GONE);
        mainWebView.getFullScreenVideoLayout().removeView(customView);
        customView = null;
        mainWebView.getFullScreenVideoLayout().setVisibility(View.GONE);
        customViewCallback.onCustomViewHidden();
        mainWebView.setVisibility(View.VISIBLE);
    }

    @Override
    public View getVideoLoadingProgressView() {
        if (videoProgressView == null) {
            LayoutInflater inflater = LayoutInflater.from(activity);
            videoProgressView = inflater.inflate(R.layout.video_loading_progress, null);
        }
        return videoProgressView;
    }

    @Override
    public void onReceivedTitle(WebView view, String title) {
        activity.setTitle(title);
    }

    @Override
    public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
        callback.invoke(origin, true, false);
    }

    public void openFileChooser(ValueCallback<Uri> uploadMsg) {
        activity.mUploadMessage = uploadMsg;
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        activity.startActivityForResult(Intent.createChooser(intent, "File Chooser"), MainActivity.FILE_CHOOSER_RESULT_CODE);

    }
    public void openFileChooser( ValueCallback uploadMsg, String acceptType) {
        activity.mUploadMessage = uploadMsg;
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        activity.startActivityForResult(Intent.createChooser(intent, "File Browser"), MainActivity.FILE_CHOOSER_RESULT_CODE);
    }

    public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
        activity.mUploadMessage = uploadMsg;
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        activity.startActivityForResult(Intent.createChooser(intent, "File Chooser"), MainActivity.FILE_CHOOSER_RESULT_CODE);
    }

    @Override
    public boolean onJsPrompt(WebView view, String url, String message, String defaultValue, JsPromptResult result) {
        final String prefix = jsapi.class.getSimpleName()+".";
        if (!message.startsWith(prefix)) {
            return super.onJsPrompt(view, url, message, defaultValue, result);
        }
        final String meth_name = message.substring(prefix.length());
        String json_result = null;
        
        Gson gson = new Gson();
        try {
        	
        	
        	
        	List<Object> params=(List<Object>)gson.fromJson(defaultValue, Object.class);
            
        	Object[] paramValues = new Object[params.size()];
        	for(int i=0;i<params.size();i++){
        		paramValues[i]=params.get(i);
        	}
        	
            
            Method method = null;
            for (Method meth : jsapi.class.getMethods()){
                if (meth.getName().equals(meth_name)) {
                    method = meth;
                    break;
                }
            }
            
            Log.e("prefix", "prefix | method " + method.getName());
           
            if (null == method) {
                throw new NoSuchMethodException();
            }
         
            
            String resultJSONStr=null;
            
            
            if (paramValues.length > 0)
            	resultJSONStr=gson.toJson(method.invoke(activity.getJsapi(), paramValues));
            else
            	resultJSONStr=gson.toJson(method.invoke(activity.getJsapi()));
            
            Log.i("result", resultJSONStr);
            final JSONObject res = new JSONObject();
            res.put("result", resultJSONStr);
            
        
            json_result = res.toString();
            Log.i("result json", json_result);
            
            
            
        }
        catch (JSONException | NoSuchMethodException | IllegalArgumentException | IllegalAccessException | InvocationTargetException e) {
            Logging.err(e);
        }
        result.confirm(json_result);
        return true;
    }
}
