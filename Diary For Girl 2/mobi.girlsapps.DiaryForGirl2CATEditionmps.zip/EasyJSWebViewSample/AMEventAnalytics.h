//
// Created by mike on 16/01/15.
// Copyright (c) 2015 Mikhail Demidov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AMEventAnalytics : NSObject

+ (instancetype)shared;
- (void)start;//don't use it!!! use c-functions!
- (void)startWithoutAppStateTracking;

@end