//
//  AMInterstitial.h
//  AMInterstitial
//
//  Created by Mikhail Demidov on 07/07/14.
//  Copyright (c) 2014 Mikhail Demidov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AMInterstitial : NSObject

+ (void)show;
+ (void)forceShow;
+ (bool)setInterstitialListener;
+ (void)onInterstitialLoaded;
+ (void)onInterstitialFailed;

@end
