//
//  AddressBook.h
//  Max Test Location
//
//  Created by Максим Шанин on 18.04.15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>

@interface AddressBook :NSObject;
@property (copy) NSString *contactName;
@property (copy) NSString *phoneNumber;
@property (copy) NSString *photoUrl;
-(id)initWith:(ABAddressBookRef) bookRef;
-(void)setName:(NSString *)name withNumber:(NSString *)number withPhotoUrl:(NSString *)photo;
@end