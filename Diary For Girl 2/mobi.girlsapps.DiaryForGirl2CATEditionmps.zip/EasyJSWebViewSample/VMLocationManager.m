//
//  VMLocationManager.m
//  iOSVM
//
//  Created by Dmitry Tihonov on 05.07.13.
//  Copyright (c) 2013 Voodoo Mobile. All rights reserved.
//

#import "VMLocationManager.h"

#define METERS_PER_DEGREE 111319.5

static VMLocationManager *instance;

@implementation VMLocationManager

- (id)init
{
	self = [super init];
    
    locationManager = [[CLLocationManager alloc] init];
    locationManager.distanceFilter = kCLDistanceFilterNone;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    
    geocoder = [[CLGeocoder alloc] init];
    
	return self;
}

+ (VMLocationManager *)sharedManager;
{
	if (!instance) {
		instance = [[VMLocationManager alloc] init];
	}
	return instance;
}

#pragma mark Core Location Delegate

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    [self updateLocation:newLocation];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    [self updateLocation:locations.lastObject];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    [self updateLocation:nil];
}

- (void)currentLocationWithCompletion:(UpdateLocationBlock)block isRecursively:(BOOL)recursively
{
    [self stopUpdating];
    changeLocationBlock = block;
    isRecursivelyUpdating = recursively;
    locationManager.delegate = self;
//    
//#define IS_OS_8_OR_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
//    
//    //In ViewDidLoad
//    if(IS_OS_8_OR_LATER) {
//        [locationManager requestAlwaysAuthorization];
//    }

    
    [locationManager startUpdatingLocation];
}

- (void)randomLocationInRadius:(float)radius withCompletition:(UpdateLocationBlock)block isRecursively:(BOOL)recursively;
{
    [self currentLocationWithCompletion:^(CLLocation *newLocation) {
        double randomLat = newLocation.coordinate.latitude - radius / METERS_PER_DEGREE + ((float)rand() / RAND_MAX) * 2 * radius / METERS_PER_DEGREE;
        double randomLng = newLocation.coordinate.longitude - radius / METERS_PER_DEGREE + ((float)rand() / RAND_MAX) * 2 * radius / METERS_PER_DEGREE;
        CLLocation *randomLocation = [[CLLocation alloc] initWithLatitude:randomLat longitude:randomLng];
        block (randomLocation);
        
    } isRecursively:recursively];
}

- (void)updateLocation:(CLLocation *)newLocation
{
    if (changeLocationBlock) {
        changeLocationBlock(newLocation);
    }
    if (!isRecursivelyUpdating){
        [self stopUpdating];
    }
}

- (void)stopUpdating
{
    [locationManager stopUpdatingLocation];
    changeLocationBlock = nil;
    locationManager.delegate = nil;
}

- (void)trackDistance:(NSInteger)distance fromLocation:(CLLocation *)location completion:(TrackLocationBlock)block
{
    [self currentLocationWithCompletion:^(CLLocation *newLocation) {
        if ([newLocation distanceFromLocation:location] > distance){
            [self stopUpdating];
            block();
        }
    } isRecursively:YES];
}

- (void)addressForCurrentLocationWithCompletition:(AddressBlock)block;
{
    [self currentLocationWithCompletion:^(CLLocation *newLocation) {
        [geocoder reverseGeocodeLocation:newLocation completionHandler:^(NSArray *placemarks, NSError *error) {
            NSLog(@"Found placemarks: %@, error: %@", placemarks, error);
            NSString *address = nil;
            if (error == nil && [placemarks count] > 0) {
                placemark = [placemarks lastObject];
                NSMutableArray *addressStrings = [NSMutableArray array];
                NSArray *keys = @[@"thoroughfare", @"subThoroughfare", @"subAdministrativeArea", @"administrativeArea", @"postalCode"];
                for (NSString *key in keys) {
                    if ([placemark valueForKey:key] != nil) {
                        [addressStrings addObject:[placemark valueForKey:key]];
                    }
                }
                address = [addressStrings componentsJoinedByString:@", "];
            } else {
                NSLog(@"%@", error.debugDescription);
            }
             if (block) {
                 block(address);
             }
        } ];
    } isRecursively:NO];
}

- (void)addressForCurrentLocationWithCompletition:(AddressBlock)block currentLocation:(CLLocation *)currentLocation;
{
    [geocoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemarks, NSError *error) {
        NSLog(@"Found placemarks: %@, error: %@", placemarks, error);
        NSString *address = nil;
        if (error == nil && [placemarks count] > 0) {
            placemark = [placemarks lastObject];
            NSMutableArray *addressStrings = [NSMutableArray array];
            NSArray *keys = @[@"thoroughfare", @"subThoroughfare", @"subAdministrativeArea", @"administrativeArea", @"postalCode"];
            for (NSString *key in keys) {
                if ([placemark valueForKey:key] != nil) {
                    [addressStrings addObject:[placemark valueForKey:key]];
                }
            }
            address = [addressStrings componentsJoinedByString:@", "];
        } else {
            NSLog(@"%@", error.debugDescription);
        }
        if (block) {
            block(address);
        }
    } ];
}

- (void)locationForAddress:(NSString *)address withCompletion:(LocationBlock)block
{
    [geocoder geocodeAddressString:address completionHandler: block];
}

@end
