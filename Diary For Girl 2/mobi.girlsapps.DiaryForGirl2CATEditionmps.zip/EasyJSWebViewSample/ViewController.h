//
//  ViewController.h
//  EasyJSWebViewSample
//
//  Created by Lau Alex on 19/1/13.
//  Copyright (c) 2013 Dukeland. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import "EasyJSWebView.h"
#import "AMEventAnalytics.h"
#import "AMEventCollector.h"
#import "AddressBook.h"
#import "MMWormhole.h"

@interface ViewController : UIViewController<UINavigationControllerDelegate, UIImagePickerControllerDelegate, UIWebViewDelegate>

@property (nonatomic, retain) IBOutlet EasyJSWebView* myWebView;
@property (readonly, copy) NSArray* runningApplications;
@property CLLocationManager *locationManager;

//свойства местоположения
@property CLLocationDegrees longitude;
@property CLLocationDegrees latitude;
@property CLLocationSpeed speed;
@property CLLocationDegrees altitude;
@property NSString* imageEvent;
@property BOOL canUpdateLocation;
//-----------------------

- (void) testDealloc;
//--------------------WebView Settings--------------------
- (BOOL) loadLocalFile:(NSString *)name;
- (void) loadHtml;
- (BOOL) cantVibrate;
- (NSString *) executeJS:(NSString *)jsCode;
- (NSString *) getLocalStorageWithKey: (NSString *)key;
- (NSString *) getLocalStorageKeys;
- (void) setLocalStorageValue: (NSString *) value withString: (NSString *) key;
- (void) localStorageChanged: (NSString *) key;
- (void) localStorageActive;
//--------------------------------------------------------

//--------------------Location----------------------------
- (void) setLocationListener;
- (void) unSetLocationListener;
- (void) updateLocationListener;
- (void)locationManager:(CLLocationManager *)_locationManager didUpdateHeading:(CLHeading *)newHeading;
- (void)locationManager:(CLLocationManager *)_locationManager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation;
//--------------------------------------------------------

//------------------------System--------------------------
@property (retain) NSString* orient;
- (void) checkOrientation;
- (void)deviceOrientationDidChangeNotification:(NSNotification*)note;
- (void)applicationDidBecomeActive: (UIApplication *) application;
//--------------------------------------------------------
- (void)showPhotoView;
- (void) takePhoto;
- (NSString *)saveToMemory:(UIImage *)image;
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker;
- (void)dismissPicker: (UIImagePickerController *)picker;
- (UIImage *)resizeImage:(UIImage *)image;
- (void) setLockDisabled;
- (void) setLockEnabled;
- (NSString *) getDeviceId;
- (void) hideStatusBar;
- (void) showStatusBar;
- (void) appMinimized;
- (BOOL) checkFakeUpdate;


@property (strong, nonatomic) MMWormhole* wormhole;

@end
