//
//  InterfaceController.m
//  Max Test Location.temp_caseinsensitive_rename WatchKit Extension
//
//  Created by Максим Шанин on 12.05.15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import "InterfaceController.h"
#import "rowController.h"

static NSArray* languages;
static NSString* language;

static NSDate* myDate;

static NSDictionary* notesA;
static NSDictionary* noData;

static NSDictionary* globalData = nil;

@interface InterfaceController()

@end


@implementation InterfaceController

- (void) updateInterface {
    [self.dateLabel setText:[self dateToStr]];
    [self.notesTitleLabel setText:@""];
    
    //[self.notesTitleLabel setText:data ];
    //NSLog(@"%@", data);
    if (!globalData) {
        [self.table setHidden:YES];
        [self.notesTitleLabel setText:[NSString stringWithFormat:@"%@\n%@", [notesA objectForKey:language], [noData objectForKey:language] ]];
    } else {
        if ([globalData count] == 0){
            [self.table setHidden:YES];
            [self.notesTitleLabel setText:[NSString stringWithFormat:@"%@\n%@", [notesA objectForKey:language], [noData objectForKey:language] ]];
        }else{
            [self.table setHidden:NO];
            [self.notesTitleLabel setText:[NSString stringWithFormat:@"%@", [notesA objectForKey:language] ]];
            [self configureTableWithData];
        }
    }
}

- (void)configureTableWithData {
    NSInteger cnt = [globalData count];
    NSInteger i = 0;
    
    [self.table setNumberOfRows:cnt withRowType:@"tableRow"];
    
    for (NSDictionary* obj in globalData) {
        rowController* theRow = [self.table rowControllerAtIndex:i];
        i++;
        
        NSDictionary* object = [globalData objectForKey:obj];
        
        NSString* iName = ([[object objectForKey:@"smile"] isEqualToString:@""]) ? @"s0" : [object objectForKey:@"smile"];
        
        [theRow.rTitle setText:[object objectForKey:@"title"]];
        [theRow.rText setText:[object objectForKey:@"text"]];
        [theRow.rImage setImageNamed:iName];
    }
    
}

- (void)table:(WKInterfaceTable *)table didSelectRowAtIndex:(NSInteger)rowIndex {
    NSInteger i = 0;

    NSMutableDictionary* openData = [[NSMutableDictionary alloc] init];

    for (NSDictionary* obj in globalData) {
        if (i == rowIndex) {
            NSDictionary* object = [globalData objectForKey:obj];

            NSString* iName = ([[object objectForKey:@"smile"] isEqualToString:@""]) ? @"s0" : [object objectForKey:@"smile"];

            [openData setObject:[self dateToStr] forKey:@"date"];
            [openData setObject:[object objectForKey:@"title"] forKey:@"title"];
            [openData setObject:[object objectForKey:@"text"] forKey:@"text"];
            [openData setObject:iName forKey:@"image"];
        }
        i++;
    }
    
    [self pushControllerWithName:@"MessageController" context:openData];
}

- (NSString*) dateToStr {
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    NSLocale *usLocale = [[NSLocale alloc] initWithLocaleIdentifier:language];
    [format setLocale:usLocale];
    [format setTimeStyle:NSDateFormatterNoStyle];
    [format setDateStyle:NSDateFormatterMediumStyle];
    NSString *string = [format stringFromDate:myDate];
    
    return string;
}

- (NSString*) dateToLsStr {
    NSDateFormatter *format = [[NSDateFormatter alloc] init];

    [format setDateFormat:@"yyyy.MM.dd"];
    NSString *string = [format stringFromDate:myDate];

    return [NSString stringWithFormat:@"girl_app|%@", string];
}


- (IBAction)rightClick {
    
    [self.wormhole stopListeningForMessageWithIdentifier:[self dateToLsStr]];
    //NSLog(@"Stop Listen: %@", [self dateToLsStr]);
    
    myDate = [myDate dateByAddingTimeInterval:60*60*24*1];
    
    //NSLog(@"Start Listen: %@", [self dateToLsStr]);
    
    [self.wormhole listenForMessageWithIdentifier:[self dateToLsStr] listener:^(id messageObject) {
        globalData = messageObject;
        [self updateInterface];
    }];

    globalData = [self.wormhole messageWithIdentifier:[self dateToLsStr]];
    [self updateInterface];
}

- (IBAction)leftClick {
    [self.wormhole stopListeningForMessageWithIdentifier:[self dateToLsStr]];
    //NSLog(@"Stop Listen: %@", [self dateToLsStr]);

    myDate = [myDate dateByAddingTimeInterval:60*60*24*-1];
    
    //NSLog(@"Start Listen: %@", [self dateToLsStr]);
    
    [self.wormhole listenForMessageWithIdentifier:[self dateToLsStr] listener:^(id messageObject) {
        globalData = messageObject;
        [self updateInterface];
    }];
    
    globalData = [self.wormhole messageWithIdentifier:[self dateToLsStr]];
    [self updateInterface];
}

#pragma mark -

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        language = @"ko";
        languages = [[NSArray alloc] initWithObjects:@"en", @"ru", @"de", @"es", @"fr", @"it", @"ja", @"ko", @"pl", @"zh", @"pt", nil];
        language = [NSString stringWithFormat:@"%@", [[NSLocale preferredLanguages] objectAtIndex:0]];
        if (![languages containsObject:language]) { language = @"en"; }
        
        myDate = [NSDate date];
        //NSLog(@"Today: %@", myDate);
        
        //NSLog(@"Today2: %@", [self dateToStr]);
       
        
        //NSString* asd = @"girl_app|2015.07.16.1437049149434";
        //        NSLog(@"neeed: %@", [asd substringToIndex:19]);
        
        //NSLog(@"LS date: %@", [self dateToLsStr]);
        
        notesA = @{
           @"en": @"Notes:",
           @"ru": @"Заметки:",
           @"de": @"Notizen:",
           @"fr": @"Notes:",
           @"es": @"Notas:",
           @"zh": @"短记:",
           @"ja": @"メモ:",
           @"ko": @"메모:",
           @"it": @"Note:",
           @"pl": @"Notatki:",
           @"pt": @"Notas:"
        };
        
        noData = @{
            @"en": @"No records",
            @"ru": @"Нет записей",
            @"de": @"Keine Notizen",
            @"fr": @"Pas de notes",
            @"es": @"No hay notas",
            @"zh": @"没有短记",
            @"ja": @"記がありません。",
            @"ko": @"메모가 없습니다",
            @"it": @"Nessuna nota",
            @"pl": @"Brak notatków",
            @"pt": @"Nenhuma nota"
        };

    }
    return self;
}

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    // Configure interface objects here.
    //[self getData];
    self.wormhole = [[MMWormhole alloc] initWithApplicationGroupIdentifier:@"group.mobi.girlsapps.DiaryForGirl2CATEditionmps" optionalDirectory:@"DiaryForGirl"];
    
    [self.wormhole listenForMessageWithIdentifier:[self dateToLsStr] listener:^(id messageObject) {
        globalData = messageObject;
        [self updateInterface];
    }];

    globalData = [self.wormhole messageWithIdentifier:[self dateToLsStr]];

    [self.notesTitleLabel setText:[notesA objectForKey:language]];
    [self updateInterface];

    //NSLog(@"unreq: %@", ([self.wormhole messageWithIdentifier:@"asd"] == NULL) ? @"yes" : @"no");
}

- (void)willActivate {
    [super willActivate];
}

- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

@end



