//
//  MessageController.h
//  Diary For Girl 2 - CAT Edition
//
//  Created by user on 31.07.15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface MessageController : WKInterfaceController

@property (weak, nonatomic) IBOutlet WKInterfaceLabel *curDateLabel;
@property (weak, nonatomic) IBOutlet WKInterfaceImage *curImage;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *curTitleLabel;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *curMessageLabel;

@end
