document.addEventListener('DOMContentLoaded', ready, false);
var storage = window['localStorage'];

var mySwiper;

var snd_ach;
var snd_post;
var snd_open;
var snd_wrong;
var snd_tap;

var Shown = 1; // при первом запуске реклама уже показывалась
var timer;

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

// PAGE obj
var PAGE = {
    prevpage: '',
    arr_back: [],

    open: function(page){
        switch(page){
        // выполняем нужный код при открытии страницы
            case 'list_menu':
                    document.getElementById('header_name').innerHTML = _w.diary_for_girls[lang];
                break;
            case 'add_menu':
                    document.getElementById('header_name').innerHTML = _w.add[lang];
                break;
            case 'read_menu':
                    document.getElementById('header_name').innerHTML = _w.secret[lang];
                break;
            case 'edit_menu':
                    document.getElementById('header_name').innerHTML = _w.edit[lang];
                break;
            case 'calendar_menu':
                    document.getElementById('header_name').innerHTML = _w.calendar[lang];
                break;
            case 'settings_menu':
                    document.getElementById('header_name').innerHTML = _w.settings[lang];
                break;
        }

        PAGE.do_right_btn(page);
        active_bottom_menu(page);

        if (page != "list_menu" && page != "add_menu" && page != "calendar_menu" && page != "settings_menu") {
            this.arr_back.push(page);
        } else {
            this.arr_back = [];
            this.arr_back.push(page);
        }

        if (this.arr_back.length != 1) {
            document.getElementById('back').style.display = "block";
        } else {
            document.getElementById('back').style.display = "none";
        }

        if(document.getElementById(this.prevpage)) {
            document.getElementById(this.prevpage).style.display = 'none';
        }

        document.getElementById(page).style.display = 'block';

        this.prevpage = page;

        if(Shown == 0){
            JSAPI.showAd();
            Shown = 1;
            clearInterval(timer);
            timer = setInterval(function(){ // раз в минуту устанавливаем в непоказано
                Shown = 0;
            }, 1000 * 60 * 1);
        }
    },

    // функция для возврата на экран назад
    back: function() {
        var arr = this.arr_back;
        var last = "";
        if (arr.length !== 0) {
            arr.splice(arr.length -1, 1);

            if (arr.length == 1) {
                last = arr[arr.length - 1];
                arr.splice(arr.length -1, 1);
            }

            this.arr_back = arr;

            if (last == "") {
                PAGE.open(arr[arr.length - 1]);
                arr.splice(arr.length -1, 1);
            } else {
                PAGE.open(last);
            }
        }
    },

    do_right_btn: function(page) {
        var arr = document.getElementsByClassName('right_btn');
        for (var i = 0; i < arr.length; i++) {
            arr[i].style.display = "none";
        }

        switch(page) {
            case 'add_menu':
                    document.getElementById('submit_add').style.display = "block";
                break;
            case 'read_menu':
                    document.getElementById('edit').style.display = "block";
                break;
            case 'edit_menu':
                    document.getElementById('submit_edit').style.display = "block";
                break;
        }
    }
};

var LIST = {
    girl_time: 100,
    image_arr: [],
    active_delete: "",

    // вернуть ключ для записи
    key: function() {
        var date = new Date();
        var year = date.getFullYear();
        var month = date.getMonth() + 1;
        if (month.toString().length == 1){
            month = "0" + month;
        }
        var day = date.getDate();
        if (day.toString().length == 1){
            day = "0" + day;
        }
        var milliseconds = date.getTime();

        var key = "girl_app|" + year + "." + month + "." + day + "." + milliseconds;
        return key;
    },

    return_date: function(key) {
        var date = key.split('|')[1];
        var arr = date.split('.');

        return arr[2] + "." + arr[1] + "." + arr[0];
    },

    // добавление записи
    add: function() {
        snd_post.play();
        var title = document.getElementById('add_title').value;
        var text = document.getElementById('add_text').value;

        var key = LIST.key();
        var obj = {};
        if (title == "") {
                title = this.return_date(key);
        }

        obj.title = title;
        obj.text = text;
        obj.image = PHOTO.arr_photo;
        var add_smile = document.getElementById('add_smile').dataset.value;
        if (typeof(add_smile) == 'undefined') {
            obj.smile = "";
        } else {
            obj.smile = add_smile;
        }

        var str = JSON.stringify(obj);

        storage.setItem(key, str);

        storage.setItem('kWatchFirstOneLineLabel', this.return_date(key));
        if (title == "" && storage.getItem('kWatchSecondOneLineLabel') != null) {
            storage.removeItem('kWatchSecondOneLineLabel');
        } else if (title != "") {
            storage.setItem('kWatchSecondOneLineLabel', title);
        }

        if (text == "" && storage.getItem('kWatchWideLabel') != null) {
            storage.removeItem('kWatchWideLabel');
        } else if (text != "") {
            storage.setItem('kWatchWideLabel', text);
        }

        if (add_smile != "") {
            storage.setItem('kWatchImageView', 'img/' + add_smile + ".png");
        } else {
            storage.setItem('kWatchImageView', 'watch_img/icon.png');
        }

        LIST.list();
        PAGE.open('list_menu');
        LIST.clear();
        PHOTO.clear();

        var storageLength = storage.getItem('girlapp_length');
        storageLength++;
        storage.setItem('girlapp_length', storageLength);

        ACHIV.check();
    },

    // вывести список приложений
    list: function(girl) {
        var result = "";
        var search_flag = false;
        var arr_result = [];
        for (var i = 0; i < storage.length; i++) {
            var key = storage.key(i);
            if (key.indexOf('girl_app') != -1) {
                arr_result.push(key);
            }
        }

        arr_result.sort();

        for (var i = arr_result.length - 1; i >= 0; i--) {
            key = arr_result[i];
            var str = storage.getItem(key);
            var obj = JSON.parse(str);
            if (obj.title.indexOf(document.getElementById('search').value) != -1) {
                var curr_date = LIST.return_date(key);

                result += '<div class="container_one_list">'
                result += '<div class="one_list" data-key="'+key+'">';
                result += '<div class="one_top"></div>';
                result += '<div class="one_date">'+curr_date+'</div>';
                result += '<div class="one_smile '+obj.smile+'"></div>';
                result += '<div class="one_title"><div class="title_icon"></div>'+obj.title+'</div>';
                result += '<div class="one_text">'+obj.text+'</div>';
                result += '</div><!-- one_list -->';
                result += '<div class="delete_one_list" data-key="'+key+'"></div>';
                result += '</div>';
            }
            if (document.getElementById('search').value != ""){
                search_flag = true;
            }
        }

        // скорость появления девочки
        if (typeof(girl) != 'undefined') {
            this.girl_time = 700;
        } else {
            this.girl_time = 100;
        }

        if (result == "" && search_flag == false) {
            document.getElementById('girl').style.display = "block";
            document.getElementById('girl_words').style.display = "table";
            document.getElementById('search_div').style.display = "none";
            setTimeout(function(){
                document.getElementById('girl').classList.add('open');
                document.getElementById('girl_words').classList.add('open');
            }, this.girl_time);
        } else {
            document.getElementById('girl').classList.remove('open');
            document.getElementById('girl').style.display = "none";
            document.getElementById('girl_words').classList.remove('open');
            document.getElementById('girl_words').style.display = "none";
            document.getElementById('search_div').style.display = "block";
        }

        document.getElementById('list_content').innerHTML = result;

        var arr = document.getElementById('list_menu').getElementsByClassName('one_list');
        for (var i = 0; i < arr.length; i++) {
            new Tap(arr[i]);
            arr[i].addEventListener('tap', function(e){
                e.preventDefault();
                PAGE.open('read_menu');
                LIST.read(this.dataset.key);
            });

            arr[i].addEventListener('swipe', function(e){
                if (e.detail.direction == "left" && e.detail.length > 30) {
                    if (LIST.active_delete != "") {
                        LIST.active_delete.classList.remove('delete');
                    }
                    this.classList.add('delete');
                    LIST.active_delete = this;
                } else if (e.detail.direction == "right" && e.detail.length > 30) {
                    this.classList.remove('delete');
                }
            });
        }

        var arr_delete = document.getElementById('list_menu').getElementsByClassName('delete_one_list');
        for (var i = 0; i < arr_delete.length; i++) {
            new Tap(arr_delete[i]);
            arr_delete[i].addEventListener('tap', function(e){
                e.preventDefault();
                var test = document.querySelector('.one_list[data-key="'+this.dataset.key+'"]');
                test.classList.remove('delete');
                test.addEventListener('webkitTransitionEnd', function(e) {
                    e.preventDefault();
                    this.removeEventListener('webkitTransitionEnd', arguments.callee);
                    POPUP.open(_w.are_you_sure[lang], 'delete', this.dataset.key);
                });
            });
        }

        getInformationCalendar(document.getElementById('fPicker_input').dataset.val);
    },

    read: function(key) {
        var obj = JSON.parse(storage.getItem(key));

        var result = "";
        var curr_date = LIST.return_date(key);

        result += '<div class="one_list" data-key="'+key+'">';
            result += '<div class="one_top"></div>';
            result += '<div class="one_date">'+curr_date+'</div>';
            result += '<div class="one_smile '+obj.smile+'"></div>';
            result += '<div class="one_title"><div class="title_icon"></div>'+obj.title+'</div>';
            result += '<div class="one_text">'+obj.text+'</div>';
            result += '<div id="read_photo_list"></div>';
        result += '</div><!-- one_list -->';

        document.getElementById('read_menu').innerHTML = result;
        PHOTO.id = "read";
        PHOTO.read_photo = obj.image;
        PHOTO.list();
        document.getElementById('edit').dataset.key = key;
    },

    edit: function() {
        var key = document.getElementById('edit').dataset.key;
        document.getElementById('submit_edit').dataset.key = key;

        var obj = JSON.parse(storage.getItem(key));
        document.getElementById('edit_title').value = obj.title;
        document.getElementById('edit_text').value = obj.text;

        PHOTO.id = "edit";
        PHOTO.edit_photo = obj.image;
        PHOTO.list();

        var arr = document.getElementById('edit_smile').getElementsByClassName('smile_one');
        for (var i = 0; i < arr.length; i++) {
            arr[i].classList.remove('active');
        }

        if (obj.smile != "")
            document.getElementById('edit_smile').getElementsByClassName(obj.smile)[0].classList.add('active');
    },

    submit_edit: function() {
        snd_post.play();
        var key = document.getElementById('submit_edit').dataset.key;
        var obj = {};

        obj.title = document.getElementById('edit_title').value;
        if (obj.title == "") {
            obj.title = this.return_date(key);
        }

        obj.text = document.getElementById('edit_text').value;
        obj.image = PHOTO.edit_photo;

        var edit_smile = document.getElementById('edit_smile').dataset.value;
        if (typeof(edit_smile) == 'undefined') {
            obj.smile = "";
        } else {
            obj.smile = edit_smile;
        }

        var str = JSON.stringify(obj);
        storage.setItem(key, str);
        LIST.list();
        LIST.read(key);
        PAGE.back();
    },

    clear: function() {
        var arr = document.getElementById('add_smile').getElementsByClassName('smile_one');
        for (var i = 0; i < arr.length; i++) {
            arr[i].classList.remove('active');
        }
        // очистить инпуты
        document.getElementById('add_title').value = "";
        document.getElementById('add_text').value = "";

        document.getElementById('add_smile').dataset.value = "";
    }
};

var POPUP = {
    action: "",
    open: function(title, action, key) {
        document.getElementById('popup').style.display = "block";
        setTimeout(function(){
            document.getElementById('popup').style.opacity = "1";
        }, 50);

        document.getElementById('input-title-popup').innerHTML = title;
        document.getElementById('ok-popup').dataset.key = key;
        this.action = action;
    },

    close: function() {
        document.getElementById('popup').style.opacity = "0";
        document.getElementById('popup').addEventListener('webkitTransitionEnd', function() {
            document.getElementById('popup').style.display = "none";
            this.removeEventListener('webkitTransitionEnd', arguments.callee);
        });
    },

    submit: function() {
        var action = this.action;
        switch(action) {
            case 'delete':
                    var key = document.getElementById('ok-popup').dataset.key;
                    storage.removeItem(key);
                    PAGE.open('list_menu');
                    LIST.list();
                    POPUP.close();
                    var storageLength = storage.getItem('girlapp_length');
                    storageLength--;
                    storage.setItem('girlapp_length', storageLength);
                break;
        }
    }
};

var SMILE_CALENDAR = {
    do_smile_calendar: function(el) {
        if (typeof el != 'undefined') {
            if (document.getElementById('smile_calendar').getElementsByClassName(el)[0].classList.contains('active')) {
                document.getElementById('smile_calendar').getElementsByClassName(el)[0].classList.remove('active');
                var smiles_day = JSON.parse(storage.getItem('girlapp_smiles'));
                var date = document.getElementById('fPicker_input').dataset.val;
                date = date.split('/');
                var newDate = date[0] + "." + date[1] + "." + date[2];
                delete smiles_day[newDate];
                var str = JSON.stringify(smiles_day);
                storage.setItem('girlapp_smiles', str);

            } else {
                var arr = document.getElementById('smile_calendar').getElementsByClassName('smile_one');
                for (var i = 0; i < arr.length; i++) {
                    arr[i].classList.remove('active');
                }

                document.getElementById('smile_calendar').getElementsByClassName(el)[0].classList.add('active');
                var date = document.getElementById('fPicker_input').dataset.val;
                date = date.split('/');
                var newDate = date[0] + "." + date[1] + "." + date[2];

                var flag = -1;

                var smiles_day = JSON.parse(storage.getItem('girlapp_smiles'));
                if (smiles_day != null) {
                    smiles_day[newDate] = el;
                    var str = JSON.stringify(smiles_day);
                    storage.setItem('girlapp_smiles', str);
                } else {
                    smiles_day = {};
                    smiles_day[newDate] = el;
                    var str = JSON.stringify(smiles_day);
                    storage.setItem('girlapp_smiles', str);
                }
            }

            fPicker.fill();
        }
    },

    do_calendar_select: function() {
        var arr = document.getElementById('smile_calendar').getElementsByClassName('smile_one');
        for (var i = 0; i < arr.length; i++) {
            arr[i].classList.remove('active');
        }

        var date = document.getElementById('fPicker_input').dataset.val;
        getInformationCalendar(date);
        SMILE_CALENDAR.select_one_smile(date);
    },

    select_one_smile: function(date) {
        date = date.split('/');
        var newDate = date[0] + "." + date[1] + "." + date[2];

        var smiles_day = JSON.parse(storage.getItem('girlapp_smiles'));
        if (smiles_day != null) {
            if (typeof (smiles_day[newDate]) != 'undefined') {
                document.getElementById('smile_calendar').getElementsByClassName(smiles_day[newDate])[0].classList.add('active');
            }
        }
    }
};

var SMILE_ADD = {
    do_smile_calendar: function(el, id) {
        if (typeof el != 'undefined') {
            if (document.getElementById(id).getElementsByClassName(el)[0].classList.contains('active')) {
                document.getElementById(id).getElementsByClassName(el)[0].classList.remove('active');
                document.getElementById(id).dataset.value = "";
            } else {
                var arr = document.getElementById(id).getElementsByClassName('smile_one');
                for (var i = 0; i < arr.length; i++) {
                    arr[i].classList.remove('active');
                }
                document.getElementById(id).getElementsByClassName(el)[0].classList.add('active');
                document.getElementById(id).dataset.value = el;
            }
        }
    }
};

var ACHIV = {
    add_all: function() {
        for (var i = 1; i < 10; i++) {
            storage.setItem('girlapp_ach' + i, "0");
        }
    },

    check: function() {
        var storageLength = storage.getItem('girlapp_length');
        switch(storageLength) {
            case '1':
                    ACHIV.open('a1', _w.a1[lang]);
                    storage.setItem('girlapp_ach1', '1');
                    ACHIV.list();
                break;
            case '3':
                    ACHIV.open('a2', _w.a2[lang]);
                    storage.setItem('girlapp_ach2', '1');
                    ACHIV.list();
                break;
            case '30':
                    ACHIV.open('a3', _w.a3[lang]);
                    storage.setItem('girlapp_ach3', '1');
                    ACHIV.list();
                break;
            case '40':
                    ACHIV.open('a4', _w.a4[lang]);
                    storage.setItem('girlapp_ach4', '1');
                    ACHIV.list();
                break;
            case '50':
                    ACHIV.open('a5', _w.a5[lang]);
                    storage.setItem('girlapp_ach5', '1');
                    ACHIV.list();
                break;
            case '80':
                    ACHIV.open('a6', _w.a6[lang]);
                    storage.setItem('girlapp_ach6', '1');
                    ACHIV.list();
                break;
            case '98':
                    ACHIV.open('a7', _w.a7[lang]);
                    storage.setItem('girlapp_ach7', '1');
                    ACHIV.list();
                break;
            case '100':
                    ACHIV.open('a8', _w.a8[lang]);
                    storage.setItem('girlapp_ach8', '1');
                    ACHIV.list();
                break;
            case '500':
                    ACHIV.open('a9', _w.a9[lang]);
                    storage.setItem('girlapp_ach9', '1');
                    ACHIV.list();
                break;
        }
    },

    open: function(number, text) {
        var ach = document.getElementById('popup_achievement');
        ach.getElementsByClassName('icon')[0].classList.remove('a1');
        ach.getElementsByClassName('icon')[0].classList.remove('a2');
        ach.getElementsByClassName('icon')[0].classList.remove('a3');
        ach.getElementsByClassName('icon')[0].classList.remove('a4');
        ach.getElementsByClassName('icon')[0].classList.remove('a5');
        ach.getElementsByClassName('icon')[0].classList.remove('a6');
        ach.getElementsByClassName('icon')[0].classList.remove('a7');
        ach.getElementsByClassName('icon')[0].classList.remove('a8');
        ach.getElementsByClassName('icon')[0].classList.remove('a9');
        ach.getElementsByClassName('icon')[0].classList.remove('a10');

        ach.getElementsByClassName('achievements-title')[0].innerHTML = '<div>' + text + '</div>';
        ach.getElementsByClassName('icon')[0].classList.add(number);
        document.getElementById('popup_achievement_cat').style.display = "block";
        snd_ach.play();
        setTimeout(function() {
            document.getElementById('popup_achievement_cat').classList.add('open');
        }, 100);

        setTimeout(function() {
            if (document.getElementById('popup_achievement_cat').classList.contains('open'))
            ACHIV.close();
        }, 4000);
    },

    close: function() {
        document.getElementById('popup_achievement_cat').classList.remove('open');
        document.getElementById('popup_achievement_cat').addEventListener('webkitTransitionEnd', function() {
            document.getElementById('popup_achievement_cat').style.display = "none";
            document.getElementById('popup_achievement_cat').removeEventListener('webkitTransitionEnd', arguments.callee);
        });
    },

    list: function() {
        for (var i = 1; i < 10; i++) {
            var curr = storage.getItem('girlapp_ach' + i);
            if (curr != null && curr == '1') {
                document.getElementById('ach' + i).classList.add('active');
            }
        }
    }
};

var PASSWORD = {
    status: function() {
        var obj = JSON.parse(storage.getItem('girlapp_password'));
        if (obj.status == 0) {
            return false;
        } else {
            return true;
        }
    },

    change: function() {
        var obj = JSON.parse(storage.getItem('girlapp_password'));
        if (document.getElementById('switch').classList.contains('active')) {
            document.getElementById('new_old_password').style.display = "block";
            if (obj.pass == "") {
                document.getElementById('old_password').parentNode.style.display = "none";
            } else {
                obj.status = 1;
                document.getElementById('old_password').parentNode.style.display = "block";
            }
        } else {
            obj.status = 0;
            obj.pass = "";
            document.getElementById('new_old_password').style.display = "none";
        }

        var str = JSON.stringify(obj);
        storage.setItem('girlapp_password', str);
    },

    submit: function() {
        var obj = JSON.parse(storage.getItem('girlapp_password'));
        if (obj.pass == "") {
            PASSWORD.new_password();
        } else {
            var old_pass = document.getElementById('old_password').value;
            if (old_pass != '' && old_pass == obj.pass) {
                PASSWORD.new_password();
            } else {
                snd_wrong.play();
                document.getElementById('old_password').parentNode.classList.add('error');
                document.getElementById('error_text').style.display = "block";
                document.getElementById('error_text').innerHTML = _w.old_password_error[lang];
            }
        }
    },

    new_password: function() {
        var obj = JSON.parse(storage.getItem('girlapp_password'));
        var pass1 = document.getElementById('new_password').value;
        var pass2 = document.getElementById('submit_new_password').value;
        if (pass1 == pass2 && pass1 != '' && pass2 != '') {
            if (pass1.length == 4 && pass2.length == 4) {
                document.getElementById('error_text').style.display = "block";
                document.getElementById('error_text').innerHTML = _w.good_password[lang];
                obj.pass = pass1;
                obj.status = 1;
                var str = JSON.stringify(obj);
                storage.setItem('girlapp_password', str);
                snd_post.play();
                setTimeout(function(){
                    document.getElementById('error_text').style.display = "none";
                    document.getElementById('new_password').value = "";
                    document.getElementById('submit_new_password').value = "";
                    document.getElementById('old_password').value = "";
                    document.getElementById('old_password').style.display = "block";
                    document.getElementById('new_password').blur();
                    document.getElementById('submit_new_password').blur();
                    document.getElementById('old_password').blur();
                }, 1500);
            } else {
                document.getElementById('submit_new_password').parentNode.classList.add('error');
                document.getElementById('error_text').style.display = "block";
                document.getElementById('error_text').innerHTML = _w.length_password[lang];
                snd_wrong.play();
            }
        } else {
            document.getElementById('submit_new_password').parentNode.classList.add('error');
            document.getElementById('error_text').style.display = "block";
            document.getElementById('error_text').innerHTML = _w.incorrect_password[lang];
            snd_wrong.play();
        }
    }
};

var PHOTO = {
    arr_photo: [],
    read_photo: [],
    edit_photo: [],
    id: "",
    add: function(url){
        switch(this.id) {
            case 'add':
                    this.arr_photo.push(url);
                break;
            case 'edit':
                    this.edit_photo.push(url);
                break;
        }

        this.list();
    },

    list: function() {
        switch(this.id) {
            case 'add':
                if (this.arr_photo.length == 0) {
                    document.getElementById('add_photo_list').style.display = "none";
                } else {
                    document.getElementById('add_photo_list').style.display = "block";
                }

                this.list_add();
                break;

            case 'read':
                    this.list_read();
                break;
            case 'edit':
                if (this.edit_photo.length == 0) {
                    document.getElementById('edit_photo_list').style.display = "none";
                } else {
                    document.getElementById('edit_photo_list').style.display = "block";
                }
                this.list_edit();
                break;
        }
    },

    list_edit: function() {
        var result = "";
        for (var i = 0; i < this.edit_photo.length; i++) {
            result += "<div class='one_photo_list' data-id='"+i+"' style='background-image: url(\""+this.edit_photo[i]+"\");'><div class='delete_one_photo'></div></div>";
        }

        document.getElementById('edit_photo_list').innerHTML = result;
        this.calculate_height();

        var arr = document.getElementById('edit_photo_list').getElementsByClassName('one_photo_list');
        for (var i = 0; i < arr.length; i++) {
            new Tap(arr[i]);
            arr[i].addEventListener('tap', function(e){
                e.preventDefault();
                PHOTO.delete_el_edit(this.dataset.id);
            });
        }
    },

    list_read: function(){
        var result = "";
        for (var i = 0; i < this.read_photo.length; i++) {
            result += "<div class='one_photo_list' data-id='"+i+"' style='background-image: url(\""+this.read_photo[i]+"\");'></div>";
        }

        document.getElementById('read_photo_list').innerHTML = result;
        this.calculate_height();

        var arr = document.getElementById('read_photo_list').getElementsByClassName('one_photo_list');
        for (var i = 0; i < arr.length; i++) {
            new Tap(arr[i]);
            arr[i].addEventListener('tap', function(e) {
                e.preventDefault();
                PHOTO.open_full_photo(PHOTO.read_photo, this.dataset.id);
            });
        }
    },

    list_add: function() {
        var result = "";
        for (var i = 0; i < this.arr_photo.length; i++) {
            result += "<div class='one_photo_list' data-id='"+i+"' style='background-image: url(\""+this.arr_photo[i]+"\");'><div class='delete_one_photo'></div></div>";
        }

        document.getElementById('add_photo_list').innerHTML = result;
        this.calculate_height();

        var arr = document.getElementById('add_photo_list').getElementsByClassName('one_photo_list');
        for (var i = 0; i < arr.length; i++) {
            new Tap(arr[i]);
            arr[i].addEventListener('tap', function(e){
                e.preventDefault();
                PHOTO.delete_el(this.dataset.id);
            });
        }
    },

    delete_el: function(id) {
        this.arr_photo.splice(id, 1);
        this.list();
    },

    delete_el_edit: function(id) {
        this.edit_photo.splice(id, 1);
        this.list();
    },

    calculate_height: function() {
        var arr = document.getElementsByClassName('one_photo_list');
        if (document.body.offsetWidth >= 768) {
            var height = (document.body.offsetWidth * 0.85 - 40 - document.body.offsetWidth * 0.85 * 0.05 + 6) * 0.3;
        } else {
            var height = (document.body.offsetWidth * 0.9 - 20 - document.body.offsetWidth * 0.9 * 0.05 + 6) * 0.3;
        }

        for (var i = 0; i < arr.length; i++) {
            arr[i].style.height = height + "px";
        }
    },

    clear: function() {
        this.arr_photo = [];
        switch(this.id){
            case 'add':
                    document.getElementById('add_photo_list').innerHTML = "";
                    document.getElementById('add_photo_list').style.display = "none";
                break;
        }
    },

    open_full_photo: function(arr, id) {
        document.getElementById('full_photo').style.display = "block";

        var myNode = document.getElementById("my_swiper");
        while (myNode.firstChild) {
            myNode.removeChild(myNode.firstChild);
        }

        var result = "";
        for (var i = 0; i < arr.length; i++) {
            result += "<div class='swiper-slide'><div class='full_in_photo' style='background-image: url(\""+arr[i]+"\");'></div></div>";
        }

        document.getElementById('my_swiper').innerHTML = result;

        if (typeof(mySwiper) != 'undefined') {
            mySwiper.update(true);
        } else {
            mySwiper = new Swiper('#full_photo',{
                mode:'horizontal',
                loop: false
            });
        }

        mySwiper.slideTo(id, 0);
    },

    close_full_photo: function() {
        document.getElementById('full_photo').style.display = "none";
        document.getElementById('my_swiper').innerHTML = "";
    }
};

// активные кнопки в меню
function active_bottom_menu(page) {
    if (page == "list_menu" || page == "add_menu" || page == "calendar_menu" || page == "settings_menu") {
        var arr = document.getElementsByClassName('bottom_menu_one');
        for (var i = 0; i < arr.length; i++) {
            arr[i].classList.remove('active');
        }

        var btn = page.split('_');
        document.getElementById('btn_' + btn[0]).classList.add('active');
    }
}

// достать информацию из календаря
function getInformationCalendar(date) {
    date = date.split('/');
    var newDate = date[0] + "." + date[1] + "." + date[2];

    var result = "";
    for (var i = 0; i < storage.length; i++) {
        var key = storage.key(i);
        if (key.indexOf('girl_app') != -1 && key.indexOf(newDate) != -1) {
            var obj = JSON.parse(storage.getItem(key));
            var curr_date = LIST.return_date(key);
            result += '<div class="one_list" data-key="'+key+'">';
                result += '<div class="one_top"></div>';
                result += '<div class="one_date">'+curr_date+'</div>';
                result += '<div class="one_smile '+obj.smile+'"></div>';
                result += '<div class="one_title"><div class="title_icon"></div>'+obj.title+'</div>';
                result += '<div class="one_text">'+obj.text+'</div>';
            result += '</div><!-- one_list -->';
        }
    }

    document.getElementById('calendar_input_text').innerHTML = result;

    var arr = document.getElementById('calendar_input_text').getElementsByClassName('one_list');
    for (var i = 0; i < arr.length; i++) {
        new Tap(arr[i]);
        arr[i].addEventListener('tap', function(e){
            e.preventDefault();
            PAGE.open('read_menu');
            LIST.read(this.dataset.key);
        });
    }
}

// определяет когда вводить пароль
function need_password() {
    if (PASSWORD.status()) {
        document.getElementById('password').classList.add('open');
        document.getElementById('info-password').style.display = "block";
        setTimeout(function(){
            document.getElementById('main_password').focus();
        }, 100);
    } else {
        document.getElementById('main_password').blur();
        document.getElementById('password').classList.add('close');
        document.getElementById('container').style.display = "block";
        LIST.list('girl');
        document.getElementById('password').addEventListener('webkitTransitionEnd', function() {
            document.getElementById('begin_paper').classList.add('open');
            snd_open.play();
            document.getElementById('begin_paper').addEventListener('webkitTransitionEnd', function() {
                document.getElementById('begin').style.display = "none";
            });
        });
    }
}

// перепарсивает для апдейта
function do_parse() {
    var key = "";
    var length = 0;
    for (var i = 0; i < storage.length; i++) {
        key = storage.key(i);
        if (key.indexOf('girl_app') != -1) {
            var arr = storage.getItem(key).split('|');
            var obj = {};

            obj.title = arr[0];
            obj.text = arr[1];
            obj.image = [];
            obj.smile = "";

            var str = JSON.stringify(obj);

            storage.setItem(key, str);
            length++;
        }
    }

    storage.setItem('girlapp_length', length);

        if (length >= 1) {
            storage.setItem('girlapp_ach1', '1');
        }

        if (length >= 3) {
            storage.setItem('girlapp_ach2', '1');
        }

        if (length >= 30) {
            storage.setItem('girlapp_ach3', '1');
        }

        if (length >= 40) {
            storage.setItem('girlapp_ach4', '1');
        }

        if (length >= 50) {
            storage.setItem('girlapp_ach5', '1');
        }

        if (length >= 80) {
            storage.setItem('girlapp_ach6', '1');
        }

        if (length >= 98) {
            storage.setItem('girlapp_ach7', '1');
        }

        if (length >= 100) {
            storage.setItem('girlapp_ach8', '1');
        }

        if (length >= 500) {
            storage.setItem('girlapp_ach9', '1');
        }

    ACHIV.list();
}

// вычислить высоту баннера
function banner_height() {
    var title = document.title;
    if (title.indexOf('PRO') != -1 || title.indexOf('pro') != -1 || title.indexOf('INAPP') != -1 || title.indexOf('inapp') != -1) {} else {
        document.getElementById('banner').style.display = "block";
        document.getElementById('banner_background').style.display = "block";

        var h_banner = 0;
        var w = document.body.clientWidth;
        if (w < 768) {
            h_banner = 50;
        } else {
            h_banner = 90;
        }

        document.getElementById('bottom_menu').style.bottom = h_banner + "px";
    }
}

// функция, которая запускается при запуске программы
function ready() {
    timer = setInterval(function(){ // раз в минуту устанавливаем в непоказано
        Shown = 0;
    }, 1000 * 60 * 1);

    banner_height();

    document.getElementById('add_title').placeholder = _w.write_your_title[lang];
    document.getElementById('add_text').placeholder = _w.write_your_secret[lang];
    document.getElementById('edit_title').placeholder = _w.write_your_title[lang];
    document.getElementById('edit_text').placeholder = _w.write_your_secret[lang];

    document.getElementById('old_password').placeholder = _w.old_password[lang];
    document.getElementById('new_password').placeholder = _w.new_password[lang];
    document.getElementById('submit_new_password').placeholder = _w.submit_new_password[lang];

    if (storage.getItem('reparcegirl') == null) {
        do_parse();
        storage.setItem('reparcegirl', 1);
    }

    snd_ach = new Sound('music/achievement.wav');
    snd_post = new Sound('music/add_post.wav');
    snd_open = new Sound('music/open_book.wav');
    snd_wrong = new Sound('music/wrong_password.wav');
    snd_tap = new Sound('music/tap.wav');

    snd_tap.volume(0.2);

    PAGE.open('list_menu');

    var main_password = document.getElementById('main_password');
    main_password.addEventListener('input', function(){
       var str = this.value;
        document.getElementById('title-password').classList.remove('error');
        if (str.length == 4) {
            var obj = JSON.parse(storage.getItem('girlapp_password'));
            if (str == obj.pass) {
                document.getElementById('main_password').blur();
                document.getElementById('password').classList.remove('open');
                document.getElementById('password').classList.add('close');
                document.getElementById('container').style.display = "block";
                LIST.list('girl');
                document.getElementById('password').addEventListener('webkitTransitionEnd', function() {
                    document.getElementById('begin_paper').classList.add('open');
                    snd_open.play();
                    document.getElementById('begin_paper').addEventListener('webkitTransitionEnd', function() {
                        document.getElementById('begin').style.display = "none";
                    });
                });
            } else {
                snd_wrong.play();
                document.getElementById('title-password').classList.add('error');
            }

            this.value = "";
        }
    });

    var begin_paper = document.getElementById('begin_paper');
    new Tap(begin_paper);
    begin_paper.addEventListener('tap', function(e){
        e.preventDefault();
        need_password();
    });

    begin_paper.addEventListener('swipe', function(e){
        e.preventDefault();
        if (e.detail.direction == "left") {
            need_password();
        }
    });

    var password = document.getElementById('password');
    new Tap(password);
    password.addEventListener('tap', function(){
        need_password();
    });

    password.addEventListener('swipe', function(e){
        e.preventDefault();
        if (e.detail.direction == "right") {
            need_password();
        }
    });

    var btn_list = document.getElementById('btn_list');
    new Tap(btn_list);
    btn_list.addEventListener('tap', function(e){
        e.preventDefault();
        PAGE.open('list_menu');
    });

    var btn_add = document.getElementById('btn_add');
    new Tap(btn_add);
    btn_add.addEventListener('tap', function(e) {
        e.preventDefault();
        PAGE.open('add_menu');
    });

    var btn_calendar = document.getElementById('btn_calendar');
    new Tap(btn_calendar);
    btn_calendar.addEventListener('tap', function(e) {
        e.preventDefault();
        PAGE.open('calendar_menu');
    });

    var btn_settings = document.getElementById('btn_settings');
    new Tap(btn_settings);
    btn_settings.addEventListener('tap', function(e) {
        e.preventDefault();
        PAGE.open('settings_menu');
    });

    var submit_add = document.getElementById('submit_add');
    new Tap(submit_add);
    submit_add.addEventListener('tap', function(e) {
        e.preventDefault();
        LIST.add();
    });

    var back = document.getElementById('back');
    new Tap(back);
    back.addEventListener('tap', function(e){
        e.preventDefault();

        PAGE.back();
    });

    var edit = document.getElementById('edit');
    new Tap(edit);
    edit.addEventListener('tap', function(e){
        e.preventDefault();
        PAGE.open('edit_menu');
        LIST.edit();
    });

    var submit_edit = document.getElementById('submit_edit');
    new Tap(submit_edit);
    submit_edit.addEventListener('tap', function(e) {
        e.preventDefault();
        LIST.submit_edit();
    });

    var delete_secret = document.getElementById('delete_secret');
    new Tap(delete_secret);
    delete_secret.addEventListener('tap', function(e) {
        e.preventDefault();
        POPUP.open(_w.are_you_sure[lang], 'delete', document.getElementById('submit_edit').dataset.key);
    });

    var cancel_popup = document.getElementById('cancel-popup');
    new Tap(cancel_popup);
    cancel_popup.addEventListener('tap', function(e){
        e.preventDefault();
       POPUP.close();
    });

    var ok_popup = document.getElementById('ok-popup');
    new Tap(ok_popup);
    ok_popup.addEventListener('tap', function(e){
        e.preventDefault();
        POPUP.submit();
    });

    var popup = document.getElementById('popup');
    new Tap(popup);
    popup.addEventListener('tap', function(e) {
        e.preventDefault();
        POPUP.close();
    });

    var girl = document.getElementById('girl');
    new Tap(girl);
    girl.addEventListener('tap', function(e){
        e.preventDefault();
        PAGE.open('add_menu');
    });

    var girl_words = document.getElementById('girl_words');
    new Tap(girl_words);
    girl_words.addEventListener('tap', function(e) {
        e.preventDefault();
        PAGE.open('add_menu');
    });

    var switch_password = document.getElementById('switch');
    new Tap(switch_password);
    switch_password.addEventListener('tap', function(e){
        e.preventDefault();
        document.getElementById('switch').classList.toggle('active');
        PASSWORD.change();
    });

    switch_password.addEventListener('swipe', function(e){
        document.getElementById('switch').classList.toggle('active');
        PASSWORD.change();
    });

    /* работа с календарем */
    fPicker.init(lang);
    fPicker.set('fPicker_input', new Date());
    fPicker.open(document.getElementById('fPicker_input'));


    getInformationCalendar(document.getElementById('fPicker_input').dataset.val);
    SMILE_CALENDAR.select_one_smile(document.getElementById('fPicker_input').dataset.val);

    /* работа со смайлами */
    var arr = document.getElementById('smile_calendar').getElementsByClassName('smile_one');
    for (var i = 0; i < arr.length; i++) {
        new Tap(arr[i]);
        arr[i].addEventListener('tap', function(e){
            e.preventDefault();
            snd_tap.play();
            SMILE_CALENDAR.do_smile_calendar(this.dataset.value);
        });
    }

    var add_smile = document.getElementById('add_smile').getElementsByClassName('smile_one');
    for (var i = 0; i < add_smile.length; i++) {
        new Tap(add_smile[i]);
        add_smile[i].addEventListener('tap', function(e){
            e.preventDefault();
            snd_tap.play();
            SMILE_ADD.do_smile_calendar(this.dataset.value, 'add_smile');
        });
    }

    var edit_smile = document.getElementById('edit_smile').getElementsByClassName('smile_one');
    for (var i = 0; i < edit_smile.length; i++) {
        new Tap(edit_smile[i]);
        edit_smile[i].addEventListener('tap', function(e){
            e.preventDefault();
            snd_tap.play();
            SMILE_ADD.do_smile_calendar(this.dataset.value, 'edit_smile');
        });
    }

    if (storage.getItem('girlapp_ach1') == null) {
        ACHIV.add_all();
    } else {
        ACHIV.list();
    }

    if (storage.getItem('girlapp_length') == null) {
        storage.setItem('girlapp_length', '0');
    }

    if (storage.getItem('girlapp_password') == null) {
        var obj = {};
        obj.pass = "";
        obj.status = 0;
        var str = JSON.stringify(obj);
        storage.setItem('girlapp_password', str);
    }

    if (PASSWORD.status()) {
        document.getElementById('switch').classList.add('active');
        document.getElementById('new_old_password').style.display = "block";
        document.getElementById('old_password').style.display = "block";
    }

    var submit_password = document.getElementById('submit_password');
    new Tap(submit_password);
    submit_password.addEventListener('tap', function(e){
        e.preventDefault();
       PASSWORD.submit();
    });

    var new_password = document.getElementById('new_password');
    new_password.addEventListener('input', function(){
        document.getElementById('submit_new_password').classList.remove('error');
        document.getElementById('old_password').parentNode.classList.remove('error');
        document.getElementById('error_text').style.display = "none";
    });

    var submit_new_password = document.getElementById('submit_new_password');
    submit_new_password.addEventListener('input', function(){
        document.getElementById('submit_new_password').parentNode.classList.remove('error');
        document.getElementById('old_password').parentNode.classList.remove('error');
        document.getElementById('error_text').style.display = "none";
    });

    var old_password = document.getElementById('old_password');
    old_password.addEventListener('input', function(){
        document.getElementById('submit_new_password').parentNode.classList.remove('error');
        document.getElementById('old_password').parentNode.classList.remove('error');
        document.getElementById('error_text').style.display = "none";
    });

    var add_picture = document.getElementById('add_picture');
    new Tap(add_picture);
    add_picture.addEventListener('tap', function(e){
        e.preventDefault();
        PHOTO.id = "add";
        JSAPI.pickPhoto();
    });

    var add_photo = document.getElementById('add_photo');
    new Tap(add_photo);
    add_photo.addEventListener('tap', function(e){
        e.preventDefault();
        PHOTO.id = "add";
        JSAPI.takePhoto();
    });

    var edit_picture = document.getElementById('edit_picture');
    new Tap(edit_picture);
    edit_picture.addEventListener('tap', function(e){
        e.preventDefault();
        PHOTO.id = "edit";
        JSAPI.pickPhoto();
    });

    var edit_photo = document.getElementById('edit_photo');
    new Tap(edit_photo);
    edit_photo.addEventListener('tap', function(e){
        e.preventDefault();
        PHOTO.id = "edit";
        JSAPI.takePhoto();
    });

    window.addEventListener('pickedImageEvent', function() {
        PHOTO.add(getBufferEventVar().path);
    });

    window.addEventListener('cameraCapturedImageEvent', function() {
        PHOTO.add(getBufferEventVar().path);
    });

    var full_photo = document.getElementById('full_photo');
    new Tap(full_photo);
    full_photo.addEventListener('tap', function(e) {
        e.preventDefault();
        PHOTO.close_full_photo();
    });

    // нотификация при каждом заходе в приложение на следующий день
    var curr_date = new Date().getTime() + (1000 * 60 * 60 * 24); // плюс один день
    var random = getRandomInt(1, 6);
    JSAPI.cancelNotif(1);
    JSAPI.createUnitNotif(0, curr_date, 1, _w.diary_for_girls[lang], _notif['n' + random][lang], _notif['n' + random][lang], 1000, '');

    var color_arr = document.getElementsByClassName('color');
    for (var i = 0; i < color_arr.length; i++) {
        new Tap(color_arr[i]);
        color_arr[i].addEventListener('tap', function(e){
            e.preventDefault();
            var curr_font = localStorage.getItem('font_diary');
            if (curr_font != null) {
                document.body.className = curr_font;
            } else {
                document.body.className = "";
            }

            var last_color = localStorage.getItem('theme_diary');
            if (last_color != null) {
                last_color = last_color.replace('b', '');
            } else {
                last_color = "color1";
            }

            document.getElementById(last_color).classList.remove('active');
            this.classList.add('active');

            switch(this.dataset.value) {
                case "1":
                        localStorage.removeItem('theme_diary');
                    break;
                case "2":
                        document.body.classList.add('bcolor2');
                        localStorage.setItem('theme_diary', 'bcolor2');
                    break;
                case "3":
                    document.body.classList.add('bcolor3');
                    localStorage.setItem('theme_diary', 'bcolor3');
                    break;

                case "4":
                    document.body.classList.add('bcolor4');
                    localStorage.setItem('theme_diary', 'bcolor4');
                    break;
                case "5":
                    document.body.classList.add('bcolor5');
                    localStorage.setItem('theme_diary', 'bcolor5');
                    break;
            }
        });
    }

    var font_arr = document.getElementsByClassName('font');
    for (var i = 0; i < font_arr.length; i++) {
        new Tap(font_arr[i]);
        font_arr[i].addEventListener('tap', function(e){
            e.preventDefault();
            var curr_theme = localStorage.getItem('theme_diary');
            if (curr_theme != null) {
                document.body.className = curr_theme;
            } else {
                document.body.className = "";
            }

            var last_font = localStorage.getItem('font_diary');
            if (last_font != null) {
                last_font = last_font.replace('b', '');
            } else {
                last_font = "font1";
            }

            document.getElementById(last_font).classList.remove('active');
            this.classList.add('active');

            switch(this.dataset.value) {
                case "1":
                    localStorage.removeItem('font_diary');
                    break;
                case "2":
                    document.body.classList.add('bfont2');
                    localStorage.setItem('font_diary', 'bfont2');
                    break;
                case "3":
                    document.body.classList.add('bfont3');
                    localStorage.setItem('font_diary', 'bfont3');
                    break;
                case "4":
                    document.body.classList.add('bfont4');
                    localStorage.setItem('font_diary', 'bfont4');
                    break;
                case "5":
                    document.body.classList.add('bfont5');
                    localStorage.setItem('font_diary', 'bfont5');
                    break;
            }
        });
    }

    var string;

    var delete_search = document.getElementById('delete_search');
    new Tap(delete_search);
    delete_search.addEventListener('tap', function(e){
        e.preventDefault();
        document.getElementById('search').value = "";
        LIST.list(girl);
    });

    var search = document.getElementById('search');
    search.oninput = function() {
        if (search.value.length > 1) {
            LIST.list(girl);
        } else {
            LIST.list(girl);
        }
    }

    document.getElementById('search').placeholder = _w.search[lang];

    if (!localStorage.getItem('first_diary_go')) {
        for (var i = 0; i < localStorage.length; i++) {
            var key = localStorage.key(i);
            if (key.indexOf('girl_app') != -1) {
                var obj = localStorage.getItem(key);
                localStorage.setItem(key, obj);
            }
        }

        localStorage.setItem('first_diary_go', '1');
    }

    var popup_ach_cat = document.getElementById('popup_achievement_cat');
    new Tap(popup_ach_cat);
    popup_ach_cat.addEventListener('tap', function(e){
        e.preventDefault();
        ACHIV.close();
    });

    JSAPI.keepScreenOn();
}
