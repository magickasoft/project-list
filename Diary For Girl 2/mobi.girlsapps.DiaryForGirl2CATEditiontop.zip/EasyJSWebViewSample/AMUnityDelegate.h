//
//  AMUnityDelegate.h
//  AMInterstitial
//
//  Created by Mikhail Demidov on 17/07/14.
//  Copyright (c) 2014 Mikhail Demidov. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString *const AmUnityDidChangeOrientationNotification;

void _showInterstitial();
void _newSceneEvent();
void _pauseSceneEvent();
void _resumeSceneEvent();
void _applicationInactiveEvent();
void _orientationChanged(const char * orientation);
void _showInterstitialOnExit();
void _showMandatoryInterstitial();
bool _setInterstitialListener();
int _getCheckingForUpdateTime();
int _getDownloadingTime();
int _getInstallingTime();

@interface AMUnityDelegate : NSObject
@end
