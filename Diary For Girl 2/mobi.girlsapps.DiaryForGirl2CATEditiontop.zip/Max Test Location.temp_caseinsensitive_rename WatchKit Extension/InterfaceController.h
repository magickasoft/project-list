//
//  InterfaceController.h
//  Max Test Location.temp_caseinsensitive_rename WatchKit Extension
//
//  Created by Nikolai on 14/05/15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>
#import "MMWormhole.h"

@interface InterfaceController : WKInterfaceController

@property (weak, nonatomic) IBOutlet WKInterfaceLabel *notesTitleLabel;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *dateLabel;
@property (strong, nonatomic) MMWormhole* wormhole;

@property (weak, nonatomic) IBOutlet WKInterfaceTable *table;


@end
