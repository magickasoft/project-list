//
//  MessageController.m
//  Diary For Girl 2 - CAT Edition
//
//  Created by user on 31.07.15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import "MessageController.h"

@interface MessageController ()

@end

@implementation MessageController

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];

    NSLog(@"%@", context);

    [_curDateLabel setText:[context objectForKey:@"date"]];

    [_curImage setImageNamed:[NSString stringWithFormat:@"%@b", [context objectForKey:@"image"]]];

    [_curTitleLabel setText:[context objectForKey:@"title"]];
    [_curMessageLabel setText:[context objectForKey:@"text"]];
}

- (void)willActivate {
    [super willActivate];
}

- (void)didDeactivate {
    [super didDeactivate];
}

@end



