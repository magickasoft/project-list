//
//  NotificationController.h
//  Max Test Location.temp_caseinsensitive_rename WatchKit Extension
//
//  Created by Nikolai on 14/05/15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface NotificationController : WKUserNotificationInterfaceController

@end
