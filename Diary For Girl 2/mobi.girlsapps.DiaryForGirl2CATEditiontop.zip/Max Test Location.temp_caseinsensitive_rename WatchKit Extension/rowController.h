//
//  rowController.h
//  Business Letters Template GOLD
//
//  Created by Dmitry on 17.07.15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface rowController : NSObject
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *rTitle;
@property (weak, nonatomic) IBOutlet WKInterfaceImage *rImage;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *rText;

@end
