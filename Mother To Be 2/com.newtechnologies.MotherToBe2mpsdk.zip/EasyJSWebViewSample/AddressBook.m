//
//  AddressBook.m
//  Max Test Location
//
//  Created by Максим Шанин on 18.04.15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import "AddressBook.h"

@implementation AddressBook
__block BOOL accessGranted = NO;

-(id)initWith:(ABAddressBookRef) bookRef {
    self = [super init];
    NSLog(@"AddressBook Created");
}

@end