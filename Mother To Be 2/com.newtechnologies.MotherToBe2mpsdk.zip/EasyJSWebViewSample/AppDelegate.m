//
//  AppDelegate.m
//  EasyJSWebViewSample
//
//  Created by Lau Alex on 19/1/13.
//  Copyright (c) 2013 Dukeland. All rights reserved.
//

#import "AppDelegate.h"

#import "ViewController.h"
#import "InterfaceController.h"


@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
       //[[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
    //[[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationNone];
    
    //[[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
    
    ////[application setStatusBarHidden: YES];
    //[[UIApplication sharedApplication] setStatusBarHidden: YES];
    
    //[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    
    /*UIUserNotificationSettings* notificationSettings = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:notificationSettings];
    */
    //-----
  /*  [self registerForRemoteNotification];
    
    if ([UIApplication instancesRespondToSelector:@selector(registerUserNotificationSettings:)]){
        [application registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeAlert|UIUserNotificationTypeBadge|UIUserNotificationTypeSound categories:nil]];
    }*/
    //----
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
	self.viewController = [[ViewController alloc] initWithNibName:@"ViewController_iPhone" bundle:nil];
	self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    
    return YES;
}



//------------
- (void)registerForRemoteNotification {
    
    NSOperatingSystemVersion ios8_0_1 = (NSOperatingSystemVersion){8, 0, 1};
    if ([[NSProcessInfo processInfo] isOperatingSystemAtLeastVersion:ios8_0_1]) {
        UIUserNotificationType types = UIUserNotificationTypeSound | UIUserNotificationTypeBadge | UIUserNotificationTypeAlert;
        UIUserNotificationSettings *notificationSettings = [UIUserNotificationSettings settingsForTypes:types categories:nil];
        [[UIApplication sharedApplication] registerUserNotificationSettings:notificationSettings];
    } else {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    }
}

#ifdef __IPHONE_8_0
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings {
    [application registerForRemoteNotifications];
}
#endif
//-----------


- (BOOL) locationUpdating {
    _locationUpdating = false;
}



- (void)applicationWillResignActive:(UIApplication *)application
{
	// Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
	// Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    NSLog(@"Will resign active");
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
	// Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
	// Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    ViewController *vc = self.window.rootViewController;
    [vc updateLocationListener];
    NSLog(@"Application is active!");
}

- (void)applicationWillTerminate:(UIApplication *)application
{
	// Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    NSLog(@"Test");
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    ViewController *vc;
    vc = self.window.rootViewController;
    [vc appMinimized];
    NSString* stringForFirsLabel = [self.viewController getLocalStorageWithKey: kWatchFirstOneLineLabel];
    NSLog(@"string for first label: %@", stringForFirsLabel);
}

#pragma mark - Apple Watch

/*
     В данный момент на часах есть 2 однострочных лейбла, одна картинка, из 1 трехстрочный лейбл;
     Ключи для UI элементов находятся в InterfaceController.h
     Значения для лейблов берутся из LocalStorage, по этим ключам. Если значение NIL или Пустая строка, то лейбл не показывается.
     Картинка берется из проекта по имени в поле "imageName" в файле InterfaceController.h (по умолчанию iwatchImageView.png)
     Текущий размер картинки 136х47 чтобы все вошло на одну страницу, без скрола.
     Нужно либо поменять имя в этом поле, либо переименовать нужную картинку в "iwatchImageView.png"
     Обновление данных на часах происходит по таймеру раз в pollingInterval (InterfaceController.h)
     UI обновляется если были какие либо изменения в LocalStorage для часов.
*/

- (void)application:(UIApplication *)application handleWatchKitExtensionRequest:(NSDictionary *)userInfo reply:(void(^)(NSDictionary *replyInfo))reply NS_AVAILABLE_IOS(8_2){
    
    NSMutableDictionary* infoToWatch = [[NSMutableDictionary alloc] init];
    
    //  Test string values
    //NSString* stringForFirsLabel = @"First label string";
    //NSString* stringForSecondLabel = @"Second label string";
    //NSString* stringForWideLabel = @"Wide label string for three lines bla-bla-bla-bla-bla";
    
    //  Раскоментить когда заработает LocalStorage
    //NSString* stringForFirsLabel = [self.viewController getLocalStorageWithKey: kWatchFirstOneLineLabel];
    NSString* stringForFirsLabel = [self.viewController.myWebView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"localStorage.getItem(\"%@\")", kWatchFirstOneLineLabel]];
    NSString* stringForSecondLabel = [self.viewController.myWebView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"localStorage.getItem(\"%@\")", kWatchSecondOneLineLabel]];
    NSString* stringForWideLabel = [self.viewController.myWebView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"localStorage.getItem(\"%@\")", kWatchWideLabel]];
    NSString* linkToWatchImage = [self.viewController.myWebView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"localStorage.getItem(\"%@\")", kWatchImageView]];
    NSString *imageLink = [NSString stringWithFormat:@"../assets/%@", linkToWatchImage];
//    NSString* stringForSecondLabel = [self.viewController getLocalStorageWithKey: kWatchSecondOneLineLabel];
//    NSString* stringForWideLabel = [self.viewController getLocalStorageWithKey: kWatchWideLabel];
    
    //  Set a string value for watch labels
    [infoToWatch setValue: stringForFirsLabel   forKey: kWatchFirstOneLineLabel];
    [infoToWatch setValue: stringForSecondLabel forKey: kWatchSecondOneLineLabel];
    [infoToWatch setValue: stringForWideLabel   forKey: kWatchWideLabel];

    //  Set an image
    UIImage* image = [UIImage imageNamed: imageLink];
    NSData* imageData = UIImagePNGRepresentation(image);
    [infoToWatch setValue: imageData forKey: kWatchImageView];

    
//    Send the data to Watch
    if (self.viewController.needToRefreshDataForWatch){
        self.viewController.needToRefreshDataForWatch = NO;
        reply(infoToWatch);
    } else {
        reply(@{kEmptyInfo : @"Don't need to refresh"});
    }


}

@end
