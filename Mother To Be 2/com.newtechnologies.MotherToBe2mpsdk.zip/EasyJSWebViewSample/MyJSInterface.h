//
//  MyJSInterface.h
//  EasyJSWebViewSample
//
//  Created by Lau Alex on 19/1/13.
//  Copyright (c) 2013 Dukeland. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>
#import <AddressBook/AddressBook.h>
#import <AddressBookUI/AddressBookUI.h>
#import "EasyJSDataFunction.h"
#import "AMInterstitial.h"
#import "ViewController.h"
#import "VMLocationManager.h"

@interface MyJSInterface : NSObject
//Sounds
@property (assign) NSMutableArray* Sounds;
@property (assign) ViewController* viewController;
@property (assign) NSString* imgurl;


//--------------Sounds--------------
- (NSString *) newSound: (NSString *) link;
- (void) playSound: (NSString *) sid withVolume: (NSString *) volume;
- (void) playMedia: (NSString *) sid;
- (void) playLoopedSound: (NSString *) sid withVolume: (NSString *) volume;
- (void) changeVolume: (NSString *) sid : (NSString *) volume;
- (void) setPosition: (NSString *) sid : (NSString *) position;
- (void) setLoop: (NSString *) sid : (NSString *) state;
- (void) stopSound: (NSString *) sid;
- (void) pauseSound: (NSString *) sid;
- (NSString *) getDuration: (NSString *) sid;
- (NSString *) getPosition: (NSString *) sid;
- (void) listenLocation: (int) minTime : (int) minDistance : (NSString *) provider;
//----------------------------------
- (void) sharing: (NSString *) Text withImg: (NSString *) Image64; //шаринг
-(id) initWithController:(ViewController *) vc;



- (void) vibrate: (NSString *) vTime;
//------
//Notifications
@property (strong, nonatomic) NSMutableArray* notificationNames;
@property (strong, nonatomic) NSMutableArray* notifications;
- (void) createNotification: (NSString *) fullText withId: (NSString *) sid withDate: (NSString *) stime;
- (NSInteger) getNotificationNumber: (NSInteger) notificationName;
- (void) cancelNotification: (NSInteger) notificationName;
//-------------
//Images
- (void) getImageUrl: (NSString *) path;
- (void) showPhotoView;
- (void) takePhoto;
//------
//Ads
- (void)showAd;
//---
//LocalStorage
- (void) localStorageChanged: (NSString *) key;
- (void) localStorageActive;
//------------
//Location
- (void) listenLocation: (NSString *) provider;
- (void) stopListenLocation;
//------------
- (void) log: (NSString *) input;
- (void) test;
- (void) setLockDisabled;
- (void) setLockEnabled;
- (NSString *) getDeviceId;
- (void) hideStatusBar;
- (void) showStatusBar;
- (void) checkFakeUpdate;
- (void) getNotificationSettings;
@end
