//
//  MyJSInterface.m
//  EasyJSWebViewSample
//
//  Created by Lau Alex on 19/1/13.
//  Copyright (c) 2013 Dukeland. All rights reserved.
//

#import "MyJSInterface.h"
#import "REActivityViewController.h"

@implementation MyJSInterface

ABAddressBookRef addressBookRef;

- (void) test {
    //addressBookRef = ABAddressBookCreateWithOptions(NULL, NULL);
    //AddressBook *book = nil;
    //[book initWith:addressBookRef];
	NSLog(@"test called");
}

//шаринг (убирать для удаления Pods)
- (void) sharing: (NSString *) Text withImg: (NSString *) Image64 {
    NSLog(@"Sharing!!!!!!!!!!!!!!");
    NSLog(@"[UIDevice currentDevice].model: %@",[UIDevice currentDevice].model);
    REFacebookActivity *facebookActivity = [[REFacebookActivity alloc] init];
    RETwitterActivity *twitterActivity = [[RETwitterActivity alloc] init];
    REVKActivity *vkActivity = [[REVKActivity alloc] initWithClientId:@"4868891"];
    RETumblrActivity *tumblrActivity = [[RETumblrActivity alloc] initWithConsumerKey:@"xqeif69Tlw5YyCuEM8lcTLc6L4BF5VsXEiMrDH2hHbaHGoHVmj" consumerSecret:@"EXFVqQpq8WktnHmns9YwFJHti8hOdEy974Sx2Zz2eFmGAqo5RM"];
    REMessageActivity *messageActivity = [[REMessageActivity alloc] init];
    REMailActivity *mailActivity = [[REMailActivity alloc] init];
    REPocketActivity *pocketActivity = [[REPocketActivity alloc] initWithConsumerKey:@"35976-8d28da40e521379b1f69e85c"];
    NSArray *activities = @[facebookActivity, twitterActivity, vkActivity, tumblrActivity,
                            messageActivity, mailActivity, pocketActivity];
    
    // Create REActivityViewController controller and assign data source
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    REActivityViewController *activityViewController = [[REActivityViewController alloc] initWithViewController:vc activities:activities];
    NSString *text;
    UIImage *ret;
    if (![Text  isEqual: @""] && ![Text  isEqual: @"undefined"]){
        text = [Text stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }
    if (![Image64  isEqual: @""] && ![Image64  isEqual: @"undefined"]){
        NSURL *imageurl = [NSURL URLWithString:Image64];
        NSData *imageData = [NSData dataWithContentsOfURL:imageurl];
        ret = [UIImage imageWithData:imageData];
    }
    
    if (![Text  isEqual: @""] && ![Text  isEqual: @"undefined"] && ![Image64  isEqual: @""] && ![Image64  isEqual: @"undefined"]) {
        activityViewController.userInfo = @{
                                            @"text": text,
                                            @"image": ret
                                            };
    }
    
    else {
        if (![Text  isEqual: @""] && ![Text  isEqual: @"undefined"]){
            activityViewController.userInfo = @{
                                                @"text": text
                                                //@"url": [NSURL URLWithString:@"https://github.com/romaonthego/REActivityViewController"],
                                                //@"coordinate": @{@"latitude": @(37.751586275), @"longitude": @(-122.447721511)}
                                                };
            
        }
        if (![Image64  isEqual: @""] && ![Image64  isEqual: @"undefined"]){
            activityViewController.userInfo = @{
                                                @"image": ret
                                                //@"url": [NSURL URLWithString:@"https://github.com/romaonthego/REActivityViewController"],
                                                //@"coordinate": @{@"latitude": @(37.751586275), @"longitude": @(-122.447721511)}
                                                };
        }
    }
    
    
    NSRange range = [[UIDevice currentDevice].model rangeOfString:@"iPad"];
    if (range.location != NSNotFound) {
        UIPopoverController *_activityPopoverController;
        CGRect rect = CGRectMake(vc.view.bounds.size.width/2, 20, 1, 1);
        _activityPopoverController = [[UIPopoverController alloc] initWithContentViewController:activityViewController];
        _activityPopoverController.backgroundColor = [UIColor colorWithRed:0/255.0f green:0/255.0f blue:0/255.0f alpha:0.7f];
        activityViewController.presentingPopoverController = _activityPopoverController;
        [_activityPopoverController presentPopoverFromRect:(CGRect)rect
                                                    inView:(UIView *)vc.view
                                  permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
    } else {
        [activityViewController presentFromRootViewController];
    }
}

//Sounds
//Вибрация
- (void) vibrate:(NSString *)vTime {
    NSLog(@"Vibrate!");
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
}

- (id) initWithController:(ViewController *)vc {
    [super init];
    _viewController = vc;
}

//Создание объекта звука
- (NSString *) newSound: (NSString *) link {
    NSString *audioFile = [NSString stringWithFormat:@"%@/assets/%@", [[NSBundle mainBundle] resourcePath], link];
    NSURL *soundURL = [NSURL fileURLWithPath:audioFile];
    AVAudioPlayer* audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:soundURL error:nil];
    [self.Sounds addObject:audioPlayer];
    [audioPlayer prepareToPlay];
    NSLog(@"Make new sound!");
    return [NSString stringWithFormat:@"%lu", ([self.Sounds count] - 1)];
}


//Проигрывание звука
- (void) playSound: (NSString *) sid withVolume: (NSString *) volume {
    float _volume = [volume floatValue];
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    //NSLog(@"Play sound: %@", audioPlayer.url);
    //NSLog(@"Play sound");
    audioPlayer.volume = _volume;
    audioPlayer.play ? [audioPlayer stop] : YES;
    audioPlayer.currentTime = 0;
    [audioPlayer play];
}

- (void) playMedia:(NSString *)sid {
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    audioPlayer.play ? [audioPlayer stop] : YES;
    [audioPlayer play];
}

- (void) changeVolume: (NSString *) sid : (NSString *) volume {
    NSLog(@"Change volume to %@", volume);
    float _volume = [volume floatValue];
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    [audioPlayer setVolume:_volume];
}

- (void) setPosition: (NSString *) sid : (NSString *) position {
    NSTimeInterval _position = [position integerValue];
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    audioPlayer.currentTime = _position;
}

- (void) setLoop: (NSString *) sid : (NSString *) state {
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    if ([state isEqual:@"on"]) {
        NSLog(@"Media loop is on.");
        audioPlayer.numberOfLoops = -1;
    } else {
        NSLog(@"Media loop is off.");
        audioPlayer.numberOfLoops = 0;
    }
}

- (NSString *) getDuration: (NSString *) sid {
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    return [NSString stringWithFormat:@"%f", audioPlayer.duration];
}

- (NSString *) getPosition: (NSString *) sid {
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    return [NSString stringWithFormat:@"%f", audioPlayer.currentTime];
}

-(void) stopSound:  (NSString *) sid {
    /**/
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    NSLog(@"Stop sound");
    [audioPlayer stop];
    audioPlayer.currentTime = 0;
    /**/
   
}

-(void) pauseSound:  (NSString *) sid {
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    NSLog(@"Stop sound");
    [audioPlayer pause];
}

- (void) playLoopedSound: (NSString *) sid withVolume: (NSString *) volume {
    float _volume = [volume floatValue];
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.Sounds[_id];
    NSLog(@"Play sound");
    audioPlayer.volume = _volume;
    audioPlayer.play ? [audioPlayer stop] : YES;
    audioPlayer.currentTime = 0;
  
    
    audioPlayer.numberOfLoops = -1;
    [audioPlayer play];
}


//------
//Берём фото из галереи
- (void)showPhotoView
{
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc showPhotoView];
}

//Берём фото с камеры
- (void) takePhoto {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc takePhoto];
}

//Notifications
//Создание нотификации
- (void) createNotification: (NSString *) fullText withId: (NSString *) sid withDate: (NSString *) stime {
    NSLog(@"Set notification!");
    
    if ([UIApplication instancesRespondToSelector:@selector(registerUserNotificationSettings:)]) {
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes: UIUserNotificationTypeAlert|UIUserNotificationTypeSound categories:nil]];
    }
    
    [self.notificationNames addObject:sid];
    [self.notificationNames addObject:sid];
    long int time = [stime integerValue];
    NSDate* date = [NSDate dateWithTimeIntervalSince1970:time];
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = date;
    localNotification.soundName = @"alarm2.mp3";
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithObject:sid forKey:@"mynotif"];
    localNotification.userInfo = userInfo;
    
    localNotification.alertBody = fullText;
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber: 0];
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    [self.notifications addObject:localNotification];
}

//Ищем номер нотификации по её имени
- (NSInteger) getNotificationNumber:(NSInteger)notificationName {
    NSInteger result = [self.notificationNames indexOfObject:notificationName];
    return result;
}

//Удаляем нотификацию
- (void) cancelNotification:(NSString *)notificationName {
    for (UILocalNotification *notif in [[UIApplication sharedApplication] scheduledLocalNotifications])
    {
        if([[notif.userInfo objectForKey:@"mynotif"] isEqualToString:notificationName]){
            [[UIApplication sharedApplication] cancelLocalNotification:notif];
            NSLog(@"Clear notification!");
        }
    }
}

//Перезагрузка страницы
- (void) reloadView {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc.myWebView reload];
}

//Ads
- (void)showAd {
    NSLog(@"Show Banner!");
    [AMInterstitial show];
}
//---
//Image
- (void) getImageUrl: (NSString *) path {
    NSLog(@"GET IMAGE URL!");
    _imgurl = path;
}
//-----
//LocalStorage
- (void) localStorageChanged: (NSString *) key {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc localStorageChanged: key];
}
//------------
//Location
- (void) listenLocation: (NSString *) provider {
    if ([provider isEqualToString:@"gps"]) {
        ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
        [vc setLocationListener];
    } else {
        NSLog(@"listenLocation() error! Please, check the provider name.");
    }
}
//-------------
- (void) log: (NSString *) input {
    NSLog(input);
}

- (void) stopListenLocation {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc unSetLocationListener];
}

- (void) setLockDisabled {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc setLockDisabled];
}

- (void) setLockEnabled {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc setLockEnabled];
}

- (NSString *) getDeviceId {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    return [vc getDeviceId];
}

- (void) hideStatusBar {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc hideStatusBar];
}

- (void) showStatusBar {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc showStatusBar];
}

- (void) checkFakeUpdate {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc checkFakeUpdate];
}

- (void) localStorageActive {
    ViewController *vc = [UIApplication sharedApplication].keyWindow.rootViewController;
    [vc localStorageActive];
    NSLog(@"LocalStorage is active!");
}

- (void) getNotificationSettings {
    NSLog(@"Try to get notification settings");
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
}



@end
