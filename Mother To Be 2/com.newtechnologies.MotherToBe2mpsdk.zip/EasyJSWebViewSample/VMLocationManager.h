//
//  VMLocationManager.h
//  iOSVM
//
//  Created by Dmitry Tihonov on 05.07.13.
//  Copyright (c) 2013 Voodoo Mobile. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

typedef void(^UpdateLocationBlock)(CLLocation *newLocation);
typedef void(^TrackLocationBlock)();
typedef void(^AddressBlock)(NSString *address);
typedef void(^LocationBlock)(NSArray* placemarks, NSError* error);

@interface VMLocationManager : NSObject <CLLocationManagerDelegate>
{
    CLLocationManager *locationManager;
    UpdateLocationBlock changeLocationBlock;
    
    BOOL isRecursivelyUpdating;
    
    CLGeocoder *geocoder;
    CLPlacemark *placemark;
}

+ (VMLocationManager *)sharedManager;

- (void)trackDistance:(NSInteger)distance fromLocation:(CLLocation *)location completion:(TrackLocationBlock)block;
- (void)currentLocationWithCompletion:(UpdateLocationBlock)block isRecursively:(BOOL)recursively;
- (void)randomLocationInRadius:(float)radius withCompletition:(UpdateLocationBlock)block isRecursively:(BOOL)recursively;
- (void)addressForCurrentLocationWithCompletition:(AddressBlock)block;
- (void)locationForAddress:(NSString *)address withCompletion:(LocationBlock)block;
- (void)stopUpdating;

- (void)addressForCurrentLocationWithCompletition:(AddressBlock)block currentLocation:(CLLocation *)currentLocation;

@end
