//
//  ViewController.m
//  EasyJSWebViewSample
//
//  Created by Lau Alex on 19/1/13.
//  Copyright (c) 2013 Dukeland. All rights reserved.
//

#import "ViewController.h"
#import "MyJSInterface.h"
#import "InterfaceController.h"

static NSArray* watchKeys;

@interface ViewController ()

@end

@implementation ViewController

//-----------------------Main-----------------------------
MyJSInterface* interface;


- (void)viewDidLoad
{
  
    [super viewDidLoad];
    _canUpdateLocation = false;
    [UIApplication sharedApplication].statusBarHidden = YES;
	// Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
	interface = [[MyJSInterface alloc] init];
    interface.Sounds = [[NSMutableArray alloc] init];
	[self.myWebView addJavascriptInterfaces:interface WithName:@"MyJS"];
	[interface release];
    [self loadHtml];
    self.needToRefreshDataForWatch = YES;
}

- (BOOL) checkFakeUpdate {
    return NO;
}

/*-(UIStatusBarStyle)preferredStatusBarStyle{ //Белый шрифт в статус баре
    return UIStatusBarStyleLightContent;
}*/

BOOL status = NO;

- (BOOL)prefersStatusBarHidden
{
    return status;
}

- (IBAction)onHide:(id)sender;
{
    status = YES;
    [self setNeedsStatusBarAppearanceUpdate];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self registerForKeyboardNotifications];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self unregisterForKeyboardNotifications];
}


- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    
}

- (void)unregisterForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardDidShowNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillHideNotification
     
                                                  object:nil];
}


- (void)keyboardWasShown:(NSNotification*)aNotification{
    status = YES;
    [self setNeedsStatusBarAppearanceUpdate];
    
}


- (void)keyboardWillBeHidden:(NSNotification*)aNotification{
    
    status = NO;
    [self setNeedsStatusBarAppearanceUpdate];
    
}



- (void) testDealloc{
	[self.myWebView removeFromSuperview];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//--------------------------------------------------------


//--------------------WebView Settings--------------------
//Подгрузка конкретного html-файла.
- (BOOL) loadLocalFile:(NSString *)name {
    NSString* path = [[NSBundle mainBundle] pathForResource:name ofType:@"html" inDirectory:@"assets"];
    if (path == nil) return NO;
    NSURL* baseUrl = [NSURL fileURLWithPath:path];
    NSString* content = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    if (content != nil) {
        //self.myWebView.delegate = self;
        [self.myWebView loadHTMLString:content baseURL:baseUrl];
        //[self.myWebView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path isDirectory:NO]]];
        for (id subview in self.myWebView.subviews) if ([[subview class] isSubclassOfClass:[UIScrollView class]]) ((UIScrollView *)subview).bounces = NO;
        self.myWebView.scalesPageToFit = YES;
        return YES;
    }
    return NO;
}

/*- (void)webViewDidFinishLoad:(UIWebView *)webView {
    //Fake update
    NSLog(@"webview loaded");
    if ([self checkFakeUpdate]) {
        [self executeJS:@"window.dispatchEvent(fakeUpdateStarted);"];
    }
}*/

//Подгрузка локального html-файла в зависимости от выбраной локали.
- (void) loadHtml {
    NSString* locale = [NSString stringWithFormat:@"index_%@", [NSLocale preferredLanguages][0]];
    if ([locale isEqualToString:@"index_en"]) locale = @"index";
    if (![self loadLocalFile:locale]) [self loadLocalFile:@"index"];
}

//Проверка типа девайса. Возвращает YES, если девайс может вибрировать и NO, если нет.
- (BOOL)cantVibrate {
    NSString *device = [UIDevice currentDevice].model;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad || [device isEqualToString:@"iPod"]) {
        return YES;
    }
    return NO;
}

//Вызов JavaScript-кода из Objective-C
- (NSString *) executeJS:(NSString *)jsCode {
    return [self.myWebView stringByEvaluatingJavaScriptFromString:jsCode];
}
//--------------------------------------------------------

- (void)showPhotoView
{
    //NSLog(@"show photo view");
    _imageEvent = @"pickedImageEvent";
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    [self presentViewController:picker animated:NO completion:nil];
}

- (void) takePhoto
{
    //NSLog(@"take photo");
    _imageEvent = @"cameraCapturedImageEvent";
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    if (image) {
        [self saveToMemory:[self resizeImage:image]];
    }
    [self dismissPicker: picker];
}

//Return image URL
- (NSString *)saveToMemory:(UIImage *)image {
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    
    NSDate *date = [NSDate date];
    NSDateFormatter *dateFormater = [[NSDateFormatter alloc] init];
    [dateFormater setDateFormat:@"yyyy-MM-dd-HH-mm-ss"];
    
    NSString *dateText = [dateFormater stringFromDate:date];
    
    NSString *pngFilePath = [NSString stringWithFormat:@"%@/%@photo.png", docDir, dateText];
    NSData *data1 = [NSData dataWithData:UIImagePNGRepresentation(image)];
    [data1 writeToFile:pngFilePath atomically:YES];
    NSLog(@"%@", pngFilePath);
    [interface getImageUrl:pngFilePath];
    [self executeJS:[NSString stringWithFormat:@"bufferEventVar.path = \'%@\';", pngFilePath]];
    [self executeJS:[NSString stringWithFormat:@"window.dispatchEvent(%@);", _imageEvent]];
    return pngFilePath;
}

- (UIImage *)resizeImage:(UIImage *)image
{
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat factor = MIN(image.size.width / (screenRect.size.width/2), image.size.height / (screenRect.size.height/2));
    
    UIImage *thImage = [UIImage imageWithCGImage:image.CGImage scale:factor orientation:image.imageOrientation];
    
    UIGraphicsBeginImageContext(thImage.size);
    [thImage drawInRect:CGRectMake(0,0,thImage.size.width,thImage.size.height)];
    thImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return thImage;
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissPicker: picker];
}

- (void)dismissPicker: (UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
    picker = nil;
    picker.delegate = nil;
}

//Вызов данных о localStorage
- (NSString *) getLocalStorageWithKey: (NSString *)key {
    //NSString *result = [self executeJS:[NSString stringWithFormat:@"getLocalStorageValue(%@)", key]];
    NSString *result = [self.myWebView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"localStorage.getItem(\"%@\")", key]];
    return result;
    //return @"test";
}

- (void) localStorageActive {
    self.needToRefreshDataForWatch = YES;
}

//Вызов списка ключей из localStorage
- (NSString *) getLocalStorageKeys {
    NSString *result = [self.myWebView stringByEvaluatingJavaScriptFromString: @"getLocalStorageKeys()"];
    NSLog(@"Local storage keys: %@", result);
    return result;
}

//Заменяем поле в localStorage по ключу key на значение value
- (void) setLocalStorageValue: (NSString *) value withString: (NSString *) key {
    [self executeJS:[NSString stringWithFormat:@"localStorageSetItem(\"%@\", \"%@\")", key, value]];
}

//Функция, которая вызывается при изменении LocalStorage
- (void) localStorageChanged: (NSString *) key {
    NSLog(@"%@",[NSString stringWithFormat:@"Local storage changed with key: %@", key]);
    watchKeys = @[kWatchFirstOneLineLabel, kWatchSecondOneLineLabel, kWatchWideLabel, kWatchImageView];
//    //  Watch key changed, need to refresh data
//    for (NSString* keyWatch in watchKeys){
//        if ([keyWatch isEqualToString: key]){
//            NSLog(@"Watch key (%@) changed", key);
//            self.needToRefreshDataForWatch = YES;
//            break;
//        }
//    }
    
    if ([watchKeys containsObject: key]){
                    NSLog(@"Watch key (%@) changed", key);
                    self.needToRefreshDataForWatch = YES;
    }
}

//------------------------System--------------------------
//Проверяет текущую ориентацию экрана
- (void) checkOrientation {
    UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
    if ((orientation == UIInterfaceOrientationLandscapeLeft) || (orientation == UIInterfaceOrientationLandscapeRight)) self.orient = @"landscape";
    else self.orient = @"portrait";
}

//Обработка изменения ориентации экрана
- (void)deviceOrientationDidChangeNotification:(NSNotification*)note {
    [self checkOrientation];
}

- (void)applicationDidBecomeActive: (UIApplication *) application {
    NSLog(@"Application Active!");
}
//--------------------------------------------------------

//-----------------------Location-------------------------
- (void) setLocationListener {
    _locationManager = [[CLLocationManager alloc] init];
    _locationManager.delegate = self;
    _locationManager.distanceFilter = kCLDistanceFilterNone;
    _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    NSArray *vcomp = [[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."];
    if ([_locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [_locationManager requestWhenInUseAuthorization];
    }
    //[_locationManager startUpdatingLocation];
    _canUpdateLocation = true;
    [_locationManager startUpdatingLocation];
    [_locationManager startUpdatingHeading];
    NSLog(@"Location listener set");
}

//Событие сворачивания приложения
- (void)appMinimized {
    NSLog(@"App minimized!");
    [self executeJS:@"window.dispatchEvent(appCloseEvent);"];
}

- (void) unSetLocationListener {
    [_locationManager stopUpdatingLocation];
}

/** /
- (void)locationManager:(CLLocationManager *)_locationManager didUpdateLocations:(NSArray *)locations {
    CLLocation *userLocation = locations.lastObject;
    if (userLocation != nil) {
        [self executeJS:@"window.dispatchEvent(locationChangedEvent);"];
        NSLog(@"Location changed");
        _latitude = userLocation.coordinate.latitude;
        _longitude = userLocation.coordinate.longitude;
        _speed = userLocation.speed;
        _altitude = userLocation.altitude;
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.latitude = %f;", _latitude]];
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.longitude = %f;", _longitude]];
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.altitude = %f;", _altitude]];
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.speed = %f;", _speed]];
    } else {
        NSLog(@"User location getting error!");
    }
}
/**/

- (void)locationManager:(CLLocationManager *)locationManager didUpdateHeading:(CLHeading *)newHeading {
    NSLog(@"update heading");
}

- (void)locationManager:(CLLocationManager *)locationManager didUpdateLocations:(NSArray *)locations {
    static int counter = 0;
    CLLocation *userLocation = locations.lastObject;
    if (userLocation != nil) {
        [self executeJS:@"window.dispatchEvent(locationChangedEvent);"];
        //NSLog(@"Location changed");
        _latitude = userLocation.coordinate.latitude;
        _longitude = userLocation.coordinate.longitude;
        _speed = userLocation.speed;
        _altitude = userLocation.altitude;
        //NSLog(@"lat %f long %f", _latitude, _longitude);
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.latitude = %f;", _latitude]];
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.longitude = %f;", _longitude]];
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.altitude = %f;", _altitude]];
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.speed = %f;", _speed]];
        if (counter++ < 1) {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                [NSThread sleepForTimeInterval:0.1];
                dispatch_async(dispatch_get_main_queue(), ^{
                    NSLog(@"------> try update location again;");
                    [self locationManager:locationManager didUpdateLocations:locations];
                });
            });
        }
        
    } else {
        NSLog(@"User location getting error!");
    }
}

- (void) updateLocationListener {
    if (_canUpdateLocation) [_locationManager startUpdatingLocation];
}
//--------------------------------------------------------
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    NSLog(@"Initialization.");
    //some init code
    //лучше добавить в самом конце метода, так как этот код будет показывать UI, лучше чтобы всё в приложении успело инициализироваться
    return YES;
}

-(void) setLockDisabled {
    [UIApplication sharedApplication].idleTimerDisabled = YES;
}

-(void) setLockEnabled {
    [UIApplication sharedApplication].idleTimerDisabled = NO;
}

- (NSString *) getDeviceId {
    NSString *uniqueIdentifier = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    return uniqueIdentifier;
}

- (void) hideStatusBar {
    status = YES;
    [self setNeedsStatusBarAppearanceUpdate];
}

- (void) showStatusBar {
    status = NO;
    [self setNeedsStatusBarAppearanceUpdate];
}

@end
