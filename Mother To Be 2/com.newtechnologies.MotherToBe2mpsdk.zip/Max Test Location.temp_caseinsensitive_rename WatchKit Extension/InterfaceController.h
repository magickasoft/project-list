//
//  InterfaceController.h
//  Max Test Location.temp_caseinsensitive_rename WatchKit Extension
//
//  Created by Nikolai on 14/05/15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

//------------------Ключи для UI элементов--------------------------------
static NSString* kWatchFirstOneLineLabel = @"kWatchFirstOneLineLabel";
static NSString* kWatchSecondOneLineLabel = @"kWatchSecondOneLineLabel";
static NSString* kWatchWideLabel = @"kWatchWideLabel";

static NSString* kWatchImageView = @"kWatchImageView";
//------------------------------------------------------------------------

static NSString* kEmptyInfo = @"kEmptyInfo";

static NSString* imageName = @"iwatchImageView.png";

//  Один раз в pollingInterval часы запрашивают данные у телефона
static NSTimeInterval pollingInterval = 1.0;

@interface InterfaceController : WKInterfaceController

@property (weak, nonatomic) IBOutlet WKInterfaceLabel *firstOneLineLabel;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *secondOneLineLabel;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *wideLabel;
@property (weak, nonatomic) IBOutlet WKInterfaceImage *imageView;

+ (NSArray*) getWatchKeys;

@end
