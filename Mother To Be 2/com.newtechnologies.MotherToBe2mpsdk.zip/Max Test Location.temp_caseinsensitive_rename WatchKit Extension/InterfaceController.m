//
//  InterfaceController.m
//  Max Test Location.temp_caseinsensitive_rename WatchKit Extension
//
//  Created by Максим Шанин on 12.05.15.
//  Copyright (c) 2015 Dukeland. All rights reserved.
//

#import "InterfaceController.h"

static NSArray* keysForStringValue;
static NSArray* labels;

@interface InterfaceController()

@end


@implementation InterfaceController

+ (void) initialize{
    keysForStringValue = @[kWatchFirstOneLineLabel, kWatchSecondOneLineLabel, kWatchWideLabel];
}

- (void)awakeWithContext:(id)context {
    labels = @[self.firstOneLineLabel, self.secondOneLineLabel, self.wideLabel];
    [self clearPlaceholdersFromIB];
    [self getDataFromIphone];
    [self startPollingIphone];
    [super awakeWithContext:context];
    // Configure interface objects here.
}

- (void)willActivate {
    // This method is called when watch view controller is about to be visible to user
    [self getDataFromIphone];
    [super willActivate];
}

- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

- (NSString*) getStringDataForKey: (NSString*) key fromDictionary: (NSDictionary*) dictionary{
    NSString* value;
    value = [dictionary objectForKey: key];
    if (value && [value isKindOfClass:[NSString class]]){
        return value;
    }
    return nil;
}

//- (IBAction)action {
//    [self getDataFromIphone];
//}

- (void) startPollingIphone{
    [NSTimer scheduledTimerWithTimeInterval:pollingInterval target:self selector:@selector(getDataFromIphone) userInfo:nil repeats:YES];
}

/**/
- (void) getDataFromIphone{
    NSDictionary* watchData = [NSDictionary dictionaryWithObject:@"message from the watch" forKey:@"watchKey"];
    
    [WKInterfaceController openParentApplication: watchData reply:^(NSDictionary *replyInfo, NSError *error) {
        if (error){
            NSLog(@"Error: %@", [error localizedDescription]);
        } else {
            // If data has changes - reload UI elements
                 NSString* emptyValue = [replyInfo objectForKey: kEmptyInfo];
                 if (!emptyValue || ![emptyValue isEqualToString:@"Don't need to refresh"]){
                [self loadStringDataForLabels: replyInfo];
                if ([replyInfo objectForKey: kWatchImageView]){
                    [self.imageView setImageData: [replyInfo objectForKey: kWatchImageView]];
                    [self.imageView setHidden: NO];
                } else {
                    NSLog(@"Image will be hidden");
                    [self.imageView setHidden:YES];
                }

            }
        }
    }];
}
/**/

- (void) loadStringDataForLabels: (NSDictionary*) replyInfo{
    
    NSString* value;
    for (int i = 0; i < [keysForStringValue count]; i++){
        value = [self getStringDataForKey: keysForStringValue[i] fromDictionary: replyInfo];
                    NSLog(@"value: %@", value);        if (value && ![value isEqualToString:@""]){
            [labels[i] setText: value];

            [labels[i] setHidden:NO];
        } else {
            [labels[i] setHidden:YES];
            NSLog(@"No data for the %@, it will be hidden", keysForStringValue[i]);
        }
    }
}

- (void) clearPlaceholdersFromIB{
    for (WKInterfaceLabel* label in labels){
        [label setText:@""];
    }
}

@end



