//
//  InterfaceController.h
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

#import "Model.h"

#import "MainTable.h"

@interface InterfaceController : WKInterfaceController

@property (strong, nonatomic) MMWormhole *wormhole;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *weeksPass;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *weeksWord;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *weeksLeft;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceGroup *noBornGroup;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceGroup *bornGroup;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceGroup *noDataGroup;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *noDataLabel;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *bornAge;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *bornNumber;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *bornWeeks;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceGroup *imageGroup;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *bornDayNumber;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *bornDayName;


@end
