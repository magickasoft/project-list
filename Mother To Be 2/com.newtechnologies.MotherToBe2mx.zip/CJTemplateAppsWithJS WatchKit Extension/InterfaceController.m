//
//  InterfaceController.m
//

#import "InterfaceController.h"


@interface InterfaceController() {
    NSArray* languages;
    NSString* language;
    
    NSDictionary* titles;
    NSString* mDate;
    NSDictionary* weekNames;
    NSArray* aEndings;
    NSDictionary* dayNames;
    NSArray* aDayEndings;
    
    NSDictionary* launch;
    NSDictionary* age;
    NSDictionary* leftW;
}

@end


@implementation InterfaceController

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    
    [self becomeCurrentPage];
    
    languages = [[NSArray alloc] initWithObjects:@"en", @"ru", @"de", @"es", @"fr", @"it", @"ja", @"ko", @"zh", @"pt", nil];
    language = [[NSString stringWithFormat:@"%@", [[NSLocale preferredLanguages] objectAtIndex:0]] substringToIndex:2];
    if (![languages containsObject:language]) {
        language = @"en";
    }
    
    titles = @{
               @"en": @"Week",
               @"ru": @"Неделя",
               @"de": @"Wochen",
               @"fr": @"Semaine",
               @"es": @"Semana",
               @"zh": @"星期",
               @"ja": @"週間",
               @"ko": @"주",
               @"it": @"Settimana",
               @"pl": @"Tydzień",
               @"pt": @"Semana"
               };
    
    weekNames = @{
                  @"nedelya": @{
                          @"en": @"week",
                          @"ru": @"неделя",
                          @"de": @"wochen",
                          @"fr": @"semaine",
                          @"es": @"semana",
                          @"zh": @"星期",
                          @"ja": @"週間",
                          @"ko": @"주",
                          @"it": @"settimana",
                          @"pl": @"tydzień",
                          @"pt": @"semana"
                          },
                  @"nedeli": @{
                          @"en": @"weeks",
                          @"ru": @"недели",
                          @"de": @"wochen",
                          @"fr": @"semaines",
                          @"es": @"semanas",
                          @"zh": @"星期",
                          @"ja": @"週間",
                          @"ko": @"주",
                          @"it": @"settimane",
                          @"pl": @"tygodnia",
                          @"pt": @"semanas"
                          },
                  @"nedel": @{
                          @"en": @"weeks",
                          @"ru": @"недель",
                          @"de": @"wochen",
                          @"fr": @"semaines",
                          @"es": @"semanas",
                          @"zh": @"星期",
                          @"ja": @"週間",
                          @"ko": @"주",
                          @"it": @"settimane",
                          @"pl": @"tygodni",
                          @"pt": @"semanas"
                          },
                  };
    aEndings = @[ [[weekNames objectForKey:@"nedelya"] objectForKey:language], [[weekNames objectForKey:@"nedeli"] objectForKey:language], [[weekNames objectForKey:@"nedel"] objectForKey:language] ];
    
    dayNames = @{
                 @"dney": @{
                         @"de": @"tage",
                         @"en": @"days",
                         @"es": @"días",
                         @"fr": @"jours",
                         @"it": @"giorni",
                         @"ja": @"日",
                         @"ko": @"일",
                         @"pl": @"dni",
                         @"ru": @"дней",
                         @"zh": @"天",
                         @"pt": @"dias"
                         },
                 @"dnya": @{
                         @"de": @"tage",
                         @"en": @"days",
                         @"es": @"días",
                         @"fr": @"jour",
                         @"it": @"giorno",
                         @"ja": @"日",
                         @"ko": @"일",
                         @"pl": @"dnia",
                         @"ru": @"дня",
                         @"zh": @"天",
                         @"pt": @"dias"
                         },
                 @"den": @{
                         @"de": @"tag",
                         @"en": @"day",
                         @"es": @"día",
                         @"fr": @"jour",
                         @"it": @"giorno",
                         @"ja": @"日",
                         @"ko": @"일",
                         @"pl": @"dzień",
                         @"ru": @"день",
                         @"zh": @"天",
                         @"pt": @"dia"
                         }
                 };
    aDayEndings = @[ [[dayNames objectForKey:@"den"] objectForKey:language], [[dayNames objectForKey:@"dnya"] objectForKey:language], [[dayNames objectForKey:@"dney"] objectForKey:language] ];
    
    launch = @{
               @"ru": @"Запустите приложение на телефоне",
               @"en": @"Launch the app on your phone",
               @"de": @"Starten Sie die App auf Ihrem Handy",
               @"it": @"Avvia l'applicazione sul tuo telefono",
               @"es": @"Inicia la aplicación en tu teléfono",
               @"pt": @"Inicie o aplicativo no seu telefone",
               @"fr": @"Démarrez l'application sur votre portable ",
               @"zh": @"启动手机上的应用程序",
               @"ja": @"電話でアプリをスタートさせてください",
               @"ko": @"휴대 전화에서 앱을 실행하세요",
               @"pl": @"Launch the app on your phone",
               @"tr": @"Telefonda uygulamayı aç"
               };
    [self.noDataLabel setText:[launch objectForKey:language]];
    
    age = @{
            @"en": @"Age",
            @"ru": @"Возраст",
            @"de": @"Alter",
            @"fr": @"Âge",
            @"es": @"Edad",
            @"zh": @"年龄",
            @"ja": @"年齢",
            @"ko": @"나이",
            @"it": @"Eta",
            @"pl": @"Wiek",
            @"pt": @"Idade"
            };
    [self.bornAge setText:[age objectForKey:language]];
    
    leftW = @{
              @"en": @"Left",
              @"ru": @"Осталось",
              @"de": @"Geblieben",
              @"fr": @"Il reste",
              @"es": @"quedan",
              @"zh": @"还有",
              @"ja": @"が残っています。",
              @"ko": @"남고 있습니다",
              @"it": @"Lasciato",
              @"pl": @"Zostało",
              @"pt": @"Deixou"
              };
    
    [self setTitle:[titles objectForKey:language]];
    
    _wormhole = [Model shared].wormhole;
    
    //[_wormhole clearAllMessageContents];
}

- (void)willActivate {
    [super willActivate];
    mDate = [[_wormhole messageWithIdentifier: @"mDate"] mutableCopy];
    
    [self updateInterface];
    
    [_wormhole listenForMessageWithIdentifier: @"mDate" listener:^(id messageObject){
        mDate = [messageObject mutableCopy];
        [self updateInterface];
    }];
}

- (void)didDeactivate {
    [super didDeactivate];
}

- (void)updateInterface {
    if (mDate) {
        [self.noDataGroup setHidden:YES];
        [self.noBornGroup setHidden:YES];
        [self.bornGroup setHidden:YES];
        // ------------------------------------------------------------------------------------------
        NSArray* df = [mDate componentsSeparatedByString:@"|"];
        
        NSDateFormatter* format = [[NSDateFormatter alloc] init];
        [format setDateFormat:@"yyyy/MM/dd"];
        NSDate* dt = [format dateFromString:[NSString stringWithFormat:@"%@", [df objectAtIndex:1]]];
        
        if ([[NSString stringWithFormat:@"%@", [df objectAtIndex:0]] isEqualToString:@"0"]) {
            // df is last menstruation
            dt = [dt dateByAddingTimeInterval:280*24*60*60];
        }
        
        CGFloat diff = [dt timeIntervalSinceNow];
        
        if (diff > 0) {
            NSLog(@"not yet born");
            
            NSInteger left = ceil(diff/60/60/24/7);
            NSInteger pass = 40 - left;
            
            if (pass > 0) {
                [self.weeksPass setText:[NSString stringWithFormat:@"%ld", (long)pass]];
            } else {
                [self.weeksPass setText:@"0"];
            }
            
            [self.weeksWord setText:[self getNumEnding:pass :aEndings]];
            [self.weeksLeft setText:[NSString stringWithFormat:@"%@\n %ld %@", [leftW objectForKey:language], (long)left, [self getNumEnding:left :aEndings]]];
            
            NSInteger passCircle = pass;
            if (passCircle > 40) {
                passCircle = 40;
            } else if(passCircle) {
                passCircle = 0;
            }
            
            [self.imageGroup setBackgroundImageNamed:[NSString stringWithFormat:@"timer_%ld", (long)pass]];
            
            [self.noBornGroup setHidden:NO];
        } else {
            NSLog(@"has born");
            
            [self.bornGroup setHidden:NO];
            
            NSInteger ageDays = fabs(floor(diff/60/60/24));
            NSInteger ageWeeks = 0;
            
            ageDays = ageDays-1;
            if (ageDays >= 7) {
                ageWeeks = floor(ageDays/7);
                ageDays = ageDays-floor(ageWeeks*7);
            }
            
            [self.bornNumber setText:[NSString stringWithFormat:@"%ld", (long)ageWeeks]];
            [self.bornWeeks setText:[self getNumEnding:ageWeeks :aEndings]];
            
            
            [self.bornDayNumber setText:[NSString stringWithFormat:@"%ld", (long)ageDays]];
            [self.bornDayName setText:[self getNumEnding:ageDays :aDayEndings]];
            // TODO
        }
        
        
        
        NSLog(@"interval: %f", [dt timeIntervalSinceNow]);
        
        
        NSLog(@"dt: %@", dt);
        // ------------------------------------------------------------------------------------------
    } else {
        [self.noDataGroup setHidden:NO];
        [self.noBornGroup setHidden:YES];
        [self.bornGroup setHidden:YES];
    }
    
    
    
    
    //    for (NSInteger i = 0; i < 13; i++) {
    //        NSLog(@"%ld %@", (long)i, [self getNumEnding:i] );
    //    }
}

- (NSString*)getNumEnding:(NSInteger)iNumber : (NSArray*)withArray {
    NSString* sEnding;
    NSInteger i;
    
    iNumber = iNumber % 100;
    
    if (iNumber>=11 && iNumber<=19){
        sEnding=withArray[2];
    }else{
        i = iNumber % 10;
        switch (i){
            case (1): sEnding = withArray[0]; break;
            case (2):
            case (3):
            case (4): sEnding = withArray[1]; break;
            default: sEnding = withArray[2];
        }
    }
    return sEnding;
}

@end



