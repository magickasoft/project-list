//
//  MainTable.h
//  WhereAreYouNow
//
//  Created by User on 15.09.15.
//  Copyright (c) 2015 myWork. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface MainTable : NSObject

@property (weak, nonatomic) IBOutlet WKInterfaceSeparator *tableSeparator;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *tableDate;

@property (weak, nonatomic) IBOutlet WKInterfaceLabel *tableAltitudeM;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *tableAltitudeFt;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *tableLatitude;
@property (weak, nonatomic) IBOutlet WKInterfaceLabel *tableLongitude;

@end
