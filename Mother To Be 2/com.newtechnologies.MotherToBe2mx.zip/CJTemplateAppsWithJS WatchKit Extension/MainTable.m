//
//  MainTable.m
//  WhereAreYouNow
//
//  Created by User on 15.09.15.
//  Copyright (c) 2015 myWork. All rights reserved.
//

#import "MainTable.h"

@implementation MainTable

@end
