//
//  MoodController.h
//  WhereAreYouNowFULL
//
//  Created by Dmitry on 17.09.15.
//  Copyright © 2015 myWork. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>
#import "MoodTable.h"

#import "Model.h"

@interface MoodController : WKInterfaceController

@property (strong, nonatomic) MMWormhole *wormhole;

@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceTable *moodTable;

@end
