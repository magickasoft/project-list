//
//  MoodController.m
//  WhereAreYouNowFULL
//
//  Created by Dmitry on 17.09.15.
//  Copyright © 2015 myWork. All rights reserved.
//

#import "MoodController.h"

@interface MoodController () {
    NSArray* languages;
    NSString* language;
    
    NSDictionary* titles;
    
    NSString* currentKey;
    
    NSArray* moodNames;
    NSDictionary* moods;
    NSMutableArray* activeMoods;
}

@end

@implementation MoodController

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    
    currentKey = [NSString stringWithFormat:@"MTB_mood_%@", [self getDateFormatted]];
    
    languages = [[NSArray alloc] initWithObjects:@"en", @"ru", @"de", @"es", @"fr", @"it", @"ja", @"ko", @"zh", @"pt", @"pl", nil];
    language = [[NSString stringWithFormat:@"%@", [[NSLocale preferredLanguages] objectAtIndex:0]] substringToIndex:2];
    if (![languages containsObject:language]) {
        language = @"en";
    }
    
    titles = @{
       @"en": @"Mood",
       @"ru": @"Настроение",
       @"de": @"Laune",
       @"fr": @"Humeur",
       @"es": @"Estado de ánimo",
       @"zh": @"情绪",
       @"ja": @"ムード",
       @"ko": @"기분",
       @"it": @"Umore",
       @"pl": @"Nastrój",
       @"pt": @"Humor"
    };
    [self setTitle:[titles objectForKey:language]];
    
    moodNames = @[
                  @"angry",
                  @"calm",
                  @"confused",
                  @"depression",
                  @"emotional",
                  @"forgetful",
                  @"good",
                  @"ill",
                  @"irritable",
                  @"rude",
                  @"sleepy",
                  @"sure",
                  @"tired",
                  @"concerned"
                  ];
    
    moods = @{
              
              @"angry": @{
                      @"en": @"Angry",
                      @"ru": @"Сердита",
                      @"de": @"Verärgert",
                      @"fr": @"Furieuse",
                      @"es": @"Enfadada",
                      @"zh": @"生气",
                      @"ja": @"怒りっぽい",
                      @"ko": @"성납니다",
                      @"it": @"Arrabbiato",
                      @"pl": @"Zła",
                      @"pt": @"Zangado"
                      },
              @"calm": @{
                      @"en": @"Calm",
                      @"ru": @"Спокойна",
                      @"de": @"Ruhig",
                      @"fr": @"Calme",
                      @"es": @"Tranquila",
                      @"zh": @"宁静",
                      @"ja": @"安全っぽい",
                      @"ko": @"조용합니다",
                      @"it": @"Calma",
                      @"pl": @"Spokojna",
                      @"pt": @"Calma"
                      },
              @"confused": @{
                      @"en": @"Confused",
                      @"ru": @"Смущена",
                      @"de": @"Verwirrt",
                      @"fr": @"Confuse",
                      @"es": @"Turbada",
                      @"zh": @"受窘",
                      @"ja": @"恥ずかしい感じをする",
                      @"ko": @"쑥스럽습니다",
                      @"it": @"Lusingato",
                      @"pl": @"Skrępowana",
                      @"pt": @"Lisonjeada"
                      },
              @"depression": @{
                      @"en": @"Depression",
                      @"ru": @"Депрессия",
                      @"de": @"Depression",
                      @"fr": @"Dépression",
                      @"es": @"Depresiónón",
                      @"zh": @"忧郁",
                      @"ja": @"うつ病",
                      @"ko": @"불경기",
                      @"it": @"Depressione",
                      @"pl": @"Depresja",
                      @"pt": @"Depressão"
                      },
              @"emotional": @{
                      @"en": @"Emotional",
                      @"ru": @"Эмоциональна",
                      @"de": @"Emotional",
                      @"fr": @"Émotionnelle",
                      @"es": @"Emocionada",
                      @"zh": @"感情",
                      @"ja": @"感情的",
                      @"ko": @"감정적입니다",
                      @"it": @"Emotivo",
                      @"pl": @"Emocjonalna",
                      @"pt": @"Emocional"
                      },
              @"forgetful": @{
                      @"en": @"Forgetful",
                      @"ru": @"Забывчива",
                      @"de": @"Vergesslich",
                      @"fr": @"Oublieuse",
                      @"es": @"Disraída",
                      @"zh": @"健忘",
                      @"ja": @"忘れっぽい",
                      @"ko": @"쥐정신입니다",
                      @"it": @"Smemorato",
                      @"pl": @"Zapominalska",
                      @"pt": @"Esquecido"
                      },
              @"good": @{
                      @"en": @"Good mood",
                      @"ru": @"Хорошее",
                      @"de": @"Gute Laune",
                      @"fr": @"Bonne humeur",
                      @"es": @"Buen humor",
                      @"zh": @"很好的情绪",
                      @"ja": @"良い気分",
                      @"ko": @"기분이 좋습니다",
                      @"it": @"Di buon umore",
                      @"pl": @"Dobry nastrój",
                      @"pt": @"De bom humor"
                      },
              @"ill": @{
                      @"en": @"Sick",
                      @"ru": @"Больна",
                      @"de": @"Krank",
                      @"fr": @"Malade",
                      @"es": @"Enferma",
                      @"zh": @"生病",
                      @"ja": @"体調不良",
                      @"ko": @"아픕니다",
                      @"it": @"Ammalata",
                      @"pl": @"Chora",
                      @"pt": @"Doente"
                      },
              @"irritable": @{
                      @"en": @"Nervous",
                      @"ru": @"Раздражительна",
                      @"de": @"Reizbar",
                      @"fr": @"Irritable",
                      @"es": @"Irascible",
                      @"zh": @"易激动",
                      @"ja": @"イライラっぽい",
                      @"ko": @"갈급증이 납니다",
                      @"it": @"Nervosa",
                      @"pl": @"Nerwowa",
                      @"pt": @"Nervosa"
                      },
              @"rude": @{
                      @"en": @"Rude",
                      @"ru": @"Груба",
                      @"de": @"Grob",
                      @"fr": @"Indélicate",
                      @"es": @"Ruda",
                      @"zh": @"粗暴",
                      @"ja": @"粗っぽい",
                      @"ko": @"무례합니다",
                      @"it": @"Rude",
                      @"pl": @"Niegrzeczna",
                      @"pt": @"Rude"
                      },
              @"sleepy": @{
                      @"en": @"Sleepy",
                      @"ru": @"Сонная",
                      @"de": @"Verschlafen",
                      @"fr": @"Somnolente",
                      @"es": @"Semidormida",
                      @"zh": @"想睡",
                      @"ja": @"眠っぽい",
                      @"ko": @"졸립니다",
                      @"it": @"Sonnolenta",
                      @"pl": @"Senna",
                      @"pt": @"Sonolento"
                      },
              @"sure": @{
                      @"en": @"Confident",
                      @"ru": @"Уверена",
                      @"de": @"Sicher",
                      @"fr": @"Sûre",
                      @"es": @"Segura",
                      @"zh": @"确信",
                      @"ja": @"自身ある",
                      @"ko": @"자신감 있습니다",
                      @"it": @"Sicura di sé",
                      @"pl": @"Pewna",
                      @"pt": @"Confiante"
                      },
              @"tired": @{
                      @"en": @"Exhausted",
                      @"ru": @"Утомлена",
                      @"de": @"Müde",
                      @"fr": @"Fatiguée",
                      @"es": @"Cansada",
                      @"zh": @"疲倦",
                      @"ja": @"疲れっぽい",
                      @"ko": @"피곤합니다",
                      @"it": @"Esausta",
                      @"pl": @"Wyczerpana",
                      @"pt": @"Esgotado"
                      },
              @"concerned": @{
                      @"en": @"Anxious",
                      @"ru": @"Обеспокоена",
                      @"de": @"Beunruigt",
                      @"fr": @"Concerné",
                      @"es": @"Inquietada",
                      @"zh": @"心烦",
                      @"ja": @"不安っぽい",
                      @"ko": @"우려합니다",
                      @"it": @"Ansiosa",
                      @"pl": @"Niespokojna",
                      @"pt": @"Ansioso"
                      }
              
              };
    
    _wormhole = [Model shared].wormhole;
    [self configureTable];
}

- (void)willActivate {
    // This method is called when watch view controller is about to be visible to user
    [super willActivate];
    
    activeMoods = [[_wormhole messageWithIdentifier: currentKey] mutableCopy];
    
    [self configureTable];
    
    [_wormhole listenForMessageWithIdentifier: currentKey listener:^(id messageObject){
        if ([[_wormhole messageWithIdentifier:@"device"] isEqualToString:@"phone"]) {
            activeMoods = [messageObject mutableCopy];
            [self configureTable];
        }
    }];

}

- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

- (NSString*)getDateFormatted {
    NSDateFormatter* format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy_MM_dd"];
    return [format stringFromDate:[NSDate date]];
}

- (NSString*)getTimeFormatted {
    NSDateFormatter* format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"HH:mm"];
    return [format stringFromDate:[NSDate date]];
}


- (void)configureTable {
    if (!activeMoods) {
        activeMoods = [@[] mutableCopy];
    }
    [self.moodTable setNumberOfRows:[moodNames count] withRowType:@"moodRow"];
    
    //NSLog(@"%@", activeMoods );
    
    for (NSInteger i = 0; i < self.moodTable.numberOfRows; i++) {
        MoodTable* theRow = [self.moodTable rowControllerAtIndex:i];
        BOOL empty = YES;
        for (NSInteger j = 0; j < [activeMoods count]; j++) {
            if ([[moodNames objectAtIndex:i] isEqualToString: [[activeMoods objectAtIndex:j] objectAtIndex:1]]) {
                [theRow.mSeparator setHidden:NO];
                [theRow.mTime setHidden:NO];
                [theRow.mTime setText:[[activeMoods objectAtIndex:j] objectAtIndex:0]];
                empty = NO;
            }
        }
        if (empty) {
            [theRow.mSeparator setHidden:YES];
            [theRow.mTime setHidden:YES];
        }
        
        [theRow.mTitle setText: [[moods objectForKey: [moodNames objectAtIndex:i] ] objectForKey:language] ];
        [theRow.mImage setImageNamed: [moodNames objectAtIndex:i] ];
    }
    NSLog(@"active moods %@", activeMoods);
}

- (void)table:(WKInterfaceTable *)table didSelectRowAtIndex:(NSInteger)rowIndex {
    NSString* mood = [moodNames objectAtIndex:rowIndex];
    NSString* time = [self getTimeFormatted];
    
    [activeMoods addObject:@[time, mood]];

    [_wormhole passMessageObject:@"watch" identifier:@"device"];
    [_wormhole passMessageObject:activeMoods identifier:currentKey];

    [self configureTable];
}

@end



