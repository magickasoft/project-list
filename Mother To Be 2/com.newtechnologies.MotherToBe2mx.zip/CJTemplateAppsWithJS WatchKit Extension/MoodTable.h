//
//  MoodTable.h
//  WhereAreYouNowFULL
//
//  Created by Dmitry on 17.09.15.
//  Copyright © 2015 myWork. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface MoodTable : NSObject
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceSeparator *mSeparator;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *mTitle;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceImage *mImage;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *mTime;

@end
