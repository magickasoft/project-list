//
//  MoodTable.m
//  WhereAreYouNowFULL
//
//  Created by Dmitry on 17.09.15.
//  Copyright © 2015 myWork. All rights reserved.
//

#import "MoodTable.h"

@implementation MoodTable

@end
