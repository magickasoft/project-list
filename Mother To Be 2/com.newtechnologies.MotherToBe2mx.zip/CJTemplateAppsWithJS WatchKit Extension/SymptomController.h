//
//  SymptomController.h
//  WhereAreYouNowFULL
//
//  Created by Dmitry on 18.09.15.
//  Copyright © 2015 myWork. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>
#import "SymptomTable.h"

#import "Model.h"

@interface SymptomController : WKInterfaceController

@property (strong, nonatomic) MMWormhole *wormhole;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceTable *symptomTable;

@end
