//
//  SymptomController.m
//  WhereAreYouNowFULL
//
//  Created by Dmitry on 18.09.15.
//  Copyright © 2015 myWork. All rights reserved.
//

#import "SymptomController.h"

@interface SymptomController () {
    NSArray* languages;
    NSString* language;

    NSDictionary* titles;

    NSString* currentKey;

    NSArray* symptomNames;
    NSDictionary* symptoms;
    NSMutableArray* activeSymptoms;
}

@end

@implementation SymptomController

- (void)awakeWithContext:(id)context {
    [super awakeWithContext:context];
    
    currentKey = [NSString stringWithFormat:@"MTB_symptom_%@", [self getDateFormatted]];
    
    languages = [[NSArray alloc] initWithObjects:@"en", @"ru", @"de", @"es", @"fr", @"it", @"ja", @"ko", @"zh", @"pt", @"pl", nil];
    language = [[NSString stringWithFormat:@"%@", [[NSLocale preferredLanguages] objectAtIndex:0]] substringToIndex:2];
    if (![languages containsObject:language]) {
        language = @"en";
    }
    
    titles = @{
         @"en": @"State of health",
         @"ru": @"Самочувствие",
         @"de": @"Befinden",
         @"fr": @"Santé",
         @"es": @"Estado de salud",
         @"zh": @"感觉",
         @"ja": @"体調",
         @"ko": @"건강",
         @"it": @"Stato di salute",
         @"pl": @"Stan zdrowia",
         @"pt": @"Estado de saúde"
    };
    [self setTitle:[titles objectForKey:language]];
    
    symptomNames = @[
        @"abdominal_pain",
        @"arthralgia",
        @"diarrhea",
        @"dizziness",
        @"gluttony",
        @"headache",
        @"inflation",
        @"myalgia",
        @"nausea",
        @"weakness"
        
    ];
    
    symptoms = @{
             @"abdominal_pain": @{
                 @"en": @"Stomach-ache",
                 @"ru": @"Боль в животе",
                 @"de": @"Bauchschmerz",
                 @"fr": @"Douleur abdominale",
                 @"es": @"Dolor en el viente",
                 @"zh": @"肚子痛",
                 @"ja": @"お腹が痛い",
                 @"ko": @"위통",
                 @"it": @"Mal di stomaco",
                 @"pl": @"Ból brzucha",
                 @"pt": @"Dor de estômago"
                 },
             @"arthralgia": @{
                 @"en": @"Joint pain",
                 @"ru": @"Боль в суставах",
                 @"de": @"Gelenkschmerzen",
                 @"fr": @"Douleur articulaire",
                 @"es": @"Dolor en los articulaciones",
                 @"zh": @"关节痛",
                 @"ja": @"関節痛",
                 @"ko": @"관절통",
                 @"it": @"Dolori articolari",
                 @"pl": @"Ból stawów",
                 @"pt": @"Dor nas articulações"
                 },
             @"diarrhea": @{
                 @"en": @"Diarrhea",
                 @"ru": @"Диарея",
                 @"de": @"Durchfall",
                 @"fr": @"Diarrhée",
                 @"es": @"Diarrea",
                 @"zh": @"拉肚子",
                 @"ja": @"下痢",
                 @"ko": @"설사",
                 @"it": @"Diarrea",
                 @"pl": @"Biegunka",
                 @"pt": @"Diarréia"
                 },
             @"dizziness": @{
                 @"en": @"Dizziness",
                 @"ru": @"Головокружение",
                 @"de": @"Schwindel",
                 @"fr": @"Étourdissement",
                 @"es": @"Vértigo",
                 @"zh": @"头晕",
                 @"ja": @"目眩",
                 @"ko": @"현기증",
                 @"it": @"Vertigini",
                 @"pl": @"Zawroty głowy",
                 @"pt": @"Tontura"
                 },
             @"gluttony": @{
                 @"en": @"Gluttony",
                 @"ru": @"Обжорство",
                 @"de": @"Gefräßigkeit",
                 @"fr": @"Gloutonnerie",
                 @"es": @"Glotonería",
                 @"zh": @"暴食",
                 @"ja": @"大食い",
                 @"ko": @"대식",
                 @"it": @"Golosità",
                 @"pl": @"Obżarstwo",
                 @"pt": @"Cobiça"
                 },
             @"headache": @{
                 @"en": @"Head-ache",
                 @"ru": @"Головная боль",
                 @"de": @"Kopfschmerz",
                 @"fr": @"Mal à la tête",
                 @"es": @"Dolor de cabeza",
                 @"zh": @"头疼",
                 @"ja": @"頭痛",
                 @"ko": @"두통",
                 @"it": @"Mal di testa",
                 @"pl": @"Ból głowy",
                 @"pt": @"Dor de cabeça"
                 },
             @"inflation": @{
                 @"en": @"Distention",
                 @"ru": @"Вздутие",
                 @"de": @"Bauchauftreibung",
                 @"fr": @"Distension",
                 @"es": @"Flato",
                 @"zh": @"鼓肠",
                 @"ja": @"腹部膨張感",
                 @"ko": @"복부 팽창",
                 @"it": @"Distensione",
                 @"pl": @"Gazy jelitowe",
                 @"pt": @"Relaxamento"
                 },
             @"myalgia": @{
                 @"en": @"Muscular aches",
                 @"ru": @"Боль в мышцах",
                 @"de": @"Muskelschmerz",
                 @"fr": @"Myalgie",
                 @"es": @"Dolor en músculas",
                 @"zh": @"肌肉痛",
                 @"ja": @"筋肉痛",
                 @"ko": @"근육통",
                 @"it": @"Dolori muscolari",
                 @"pl": @"Ból mięśni",
                 @"pt": @"Dores musculares"
                 },
             @"nausea": @{
                 @"en": @"Nausea",
                 @"ru": @"Тошнота",
                 @"de": @"Übelkeit",
                 @"fr": @"Écœurement",
                 @"es": @"Náusea",
                 @"zh": @"恶心",
                 @"ja": @"吐き気",
                 @"ko": @"구역질",
                 @"it": @"Nausea",
                 @"pl": @"Nudności",
                 @"pt": @"Náusea"
                 },
             @"weakness": @{
                 @"en": @"Weakness",
                 @"ru": @"Слабость",
                 @"de": @"Schwäche",
                 @"fr": @"Fatigue",
                 @"es": @"Debilidad",
                 @"zh": @"没气力",
                 @"ja": @"無力感",
                 @"ko": @"힘이 없음",
                 @"it": @"Debolezza",
                 @"pl": @"Osłabienie",
                 @"pt": @"Fraqueza"
                 }
    };
    _wormhole = [Model shared].wormhole;
    [self configureTable];

}

- (void)willActivate {
    // This method is called when watch view controller is about to be visible to user
    [super willActivate];
    
    activeSymptoms = [[_wormhole messageWithIdentifier: currentKey] mutableCopy];
    
    [self configureTable];
    
    [_wormhole listenForMessageWithIdentifier: currentKey listener:^(id messageObject){
        if ([[_wormhole messageWithIdentifier:@"device"] isEqualToString:@"phone"]) {
            activeSymptoms = [messageObject mutableCopy];
            [self configureTable];
        }
    }];
}

- (void)didDeactivate {
    // This method is called when watch view controller is no longer visible
    [super didDeactivate];
}

- (NSString*)getDateFormatted {
    NSDateFormatter* format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy_MM_dd"];
    return [format stringFromDate:[NSDate date]];
}

- (NSString*)getTimeFormatted {
    NSDateFormatter* format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"HH:mm"];
    return [format stringFromDate:[NSDate date]];
}

- (void)configureTable {
    if (!activeSymptoms) {
        activeSymptoms = [@[] mutableCopy];
    }
    [self.symptomTable setNumberOfRows:[symptomNames count] withRowType:@"symptomRow"];
    
    //NSLog(@"%@", activeMoods );
    
    for (NSInteger i = 0; i < self.symptomTable.numberOfRows; i++) {
        SymptomTable* theRow = [self.symptomTable rowControllerAtIndex:i];
        BOOL empty = YES;
        for (NSInteger j = 0; j < [activeSymptoms count]; j++) {
            if ([[symptomNames objectAtIndex:i] isEqualToString: [[activeSymptoms objectAtIndex:j] objectAtIndex:1]]) {
                [theRow.sSeparator setHidden:NO];
                [theRow.sTime setHidden:NO];
                [theRow.sTime setText:[[activeSymptoms objectAtIndex:j] objectAtIndex:0]];
                empty = NO;
            }
        }
        if (empty) {
            [theRow.sSeparator setHidden:YES];
            [theRow.sTime setHidden:YES];
        }
        
        [theRow.sTitle setText: [[symptoms objectForKey: [symptomNames objectAtIndex:i] ] objectForKey:language] ];
        [theRow.sImage setImageNamed: [symptomNames objectAtIndex:i] ];
    }
    NSLog(@"active symptoms %@", activeSymptoms);
}

- (void)table:(WKInterfaceTable *)table didSelectRowAtIndex:(NSInteger)rowIndex {
    NSString* symptom = [symptomNames objectAtIndex:rowIndex];
    NSString* time = [self getTimeFormatted];
    
    [activeSymptoms addObject:@[time, symptom]];
    
    [_wormhole passMessageObject:@"watch" identifier:@"device"];
    [_wormhole passMessageObject:activeSymptoms identifier:currentKey];
    
    [self configureTable];
}



@end



