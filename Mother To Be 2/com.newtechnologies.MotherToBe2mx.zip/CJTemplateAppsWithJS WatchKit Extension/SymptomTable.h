//
//  SymptomTable.h
//  WhereAreYouNowFULL
//
//  Created by Dmitry on 18.09.15.
//  Copyright © 2015 myWork. All rights reserved.
//

#import <WatchKit/WatchKit.h>
#import <Foundation/Foundation.h>

@interface SymptomTable : NSObject

@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceSeparator *sSeparator;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceImage *sImage;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *sTitle;
@property (unsafe_unretained, nonatomic) IBOutlet WKInterfaceLabel *sTime;

@end
