//
//  SymptomTable.m
//  WhereAreYouNowFULL
//
//  Created by Dmitry on 18.09.15.
//  Copyright © 2015 myWork. All rights reserved.
//

#import "SymptomTable.h"

@implementation SymptomTable

@end
