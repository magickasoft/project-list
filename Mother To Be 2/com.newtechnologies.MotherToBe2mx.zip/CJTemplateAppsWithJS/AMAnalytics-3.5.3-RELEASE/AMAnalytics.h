//
//  AMAnalyitcs.h
//  AMAnalytic
//
//  Created by User on 15.04.15.
//  Copyright (c) 2015 Mikhail Demidov. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface AMAnalytics : NSObject


+ (instancetype)shared;
- (void)start;//don't use it!!! use c-functions!
- (void)startWithoutAppStateTracking;

@end
