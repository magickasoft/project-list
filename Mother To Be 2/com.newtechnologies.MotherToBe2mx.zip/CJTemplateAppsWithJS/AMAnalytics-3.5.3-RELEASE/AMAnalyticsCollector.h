//
//  AMAnalyticsCollector.h
//  AMAnalytic
//
//  Created by User on 15.04.15.
//  Copyright (c) 2015 Mikhail Demidov. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface AMAnalyticsCollector : NSObject

+ (void)buttonClickWithName:(NSString *)buttonName;
+ (void)sceneStartWithName:(NSString *)sceneName andId:(int)sceneId;
+ (void)levelStartWithName:(NSString *)levelName andMode:(NSString *)gameMode;
+ (void)levelWinWithName:(NSString *)levelName andMode:(NSString *)gameMode;
+ (void)inappShopButtonClick;
+ (void)inappItemButtonClickWithName:(NSString *)buttonName andInappItemId:(NSString *)itemId;
+ (void)inappPurchaseCompletedWithInappItemId:(NSString *)itemId;
+ (void)inappPurchaseFailedWithInappItemId:(NSString *)itemId;
+ (void)inappPurchaseCancelledWithInappItemId:(NSString *)itemId;
+ (void)lootAppendWithName:(NSString *)lootName andVolume:(int)volume;
+ (void)lootConsumeWithName:(NSString *)lootName andVolume:(int)volume andTarget:(NSString *)targetName;
+ (void)levelLoseWithName:(NSString *)levelName andMode:(NSString *)gameMode;
+ (void)gameOverWithMode:(NSString *)gameMode;
+ (void)inappPurchaseRefundedWithInappItemId:(NSString *)itemId;
+ (void)inappPurchaseRestoredWithResult:(BOOL)result;

//кастомное событие
+ (void)custom: (NSDictionary *) data;

@end
