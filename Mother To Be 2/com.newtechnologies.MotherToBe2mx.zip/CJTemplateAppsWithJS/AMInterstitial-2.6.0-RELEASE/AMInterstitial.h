//
//  AMInterstitial.h
//  AMInterstitial
//
//  Created by Mikhail Demidov on 07/07/14.
//  Copyright (c) 2014 Mikhail Demidov. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const AMInterstitialAdDidLoadNotification;

@protocol AMAdDelegate <NSObject>
@optional

- (void)bannerDidLoad;
- (void)bannerWillPresent;//you should pause an app here
- (void)bannerDidDismiss;//you should resume an app here
- (void)bannerWillLeaveApplication;//when banner will be opened in out of application (bannerWillPresent and bannerDidDismiss won't be call after)

- (void)interstitialDidLoad;
- (void)interstitialWillAppear;//you should pause an app here
- (void)interstitialDidDisappear;//you should resume an app here

@end

@interface AMInterstitial : NSObject

+ (void)show;
+ (void)forceShow;
+ (void)showFromController:(id)controller;
+ (void)forceShowFromController:(id)controller;
+ (bool)setInterstitialListener;
+ (bool)setInterstitialListenerWithGameObject:(NSString *)gameObjectName;
+ (void)onInterstitialLoaded;
+ (void)onInterstitialLoadedWithGameObject:(NSString *)gameObjectName;
+ (void)onInterstitialFailed;
+ (void)removeInterstitialListener;
+ (void)addAdListener:(NSString *)gameObject bannerType:(NSString *)bannerType;
+ (void)removeAdListener:(NSString *)gameObject bannerType:(NSString *)bannerType;
+ (void)addAdDelegate:(id <AMAdDelegate>)delegate;
+ (void)removeAdDelegate;
+ (BOOL)isInterstitialLoaded;
+ (BOOL)isAdDisabled;
+ (void)disableAd:(void(^)(NSError *error))completionHandler;

@end
