//
//  AppDelegate.h
//  CJTemplateAppsWithJS
//
//  Created by Тихоненко Василий on 11/08/15.
//  Copyright (c) 2015 myWork. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AMAnalytics.h"

#import "ViewController.h"

#import "Model.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

