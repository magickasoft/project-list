//
//  Model.h
//  CJTemplateAppsWithJS
//
//  Created by Тихоненко Василий on 12/08/15.
//  Copyright (c) 2015 myWork. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "MMWormhole.h"

#define AppName @"MotherToBe2GOLD"

#define AppGroupsName @"group.com.newtechnologies.MotherToBe2mx"

#ifndef AppGroupsName
#define AppGroupsName @"group.com.travelnewtest.watch"
#endif

#define myNotificationNameDataChanged @"kDataChanged"
#define myNotificationNamePhoneStatusChanged @"kPhoneStatusChanged"

@interface Model : NSObject{
}

@property (strong, nonatomic, readonly) MMWormhole *wormhole;

+ (instancetype)shared;

#pragma mark - data

- (void) save;

#pragma mark - wormhole

// iPhone
- (void) setPhoneStatus: (BOOL) isOnline;
// iWatch
- (BOOL) iPhoneStatus;
- (void) listenPhoneStatus;
- (void) listenChangeData;
- (void) passMessageObject: (id) obj identifier: (NSString *) identifier;

@end
