//
//  Model.m
//  CJTemplateAppsWithJS
//
//  Created by Тихоненко Василий on 12/08/15.
//  Copyright (c) 2015 myWork. All rights reserved.
//

#import "Model.h"

#define rootViewController ((ViewController *)[UIApplication sharedApplication].keyWindow.rootViewController)

@implementation Model

////////////////////////////////////////////////////////////////////
#pragma mark - init
////////////////////////////////////////////////////////////////////

// к модели можно обращаться из любого вашего класса, через [Model shared], при условии подключения #import "Model.h"
+ (instancetype)shared{
    static Model *_sharedModel = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedModel = [[Model alloc] init];
    });
    
    return _sharedModel;
}

// !!! !!! !! SINGLETON PATTERN !! !!! !!!
// НЕ ВЫЗЫВАЙТЕ МЕТОД [[Model alloc] init]
// ИСПОЛЬЗУЙТЕ ВМЕСТО НЕГО [Model shared]
// !!! !!! !!! !!! !!! !!! !!! !!! !!! !!!
- (instancetype)init
{
    self = [super init];
    if (self) {
        _wormhole = [[MMWormhole alloc] initWithApplicationGroupIdentifier:AppGroupsName
                                                         optionalDirectory:AppName];
        [_wormhole passMessageObject:@{@"device": @"phone"} identifier:@"deviceChanged"];
        [_wormhole passMessageObject:@{@"state": @"off"} identifier:@"flashLightState"];
    }
    return self;
}

////////////////////////////////////////////////////////////////////
#pragma mark - data
////////////////////////////////////////////////////////////////////

// функция сохранения модели
- (void) save{
    
    
    // <#your code#>
    
    
    // отправка нотификации, что ваша модель изменилась.
    // эту нотификацию можно перехватить в любом контроллере приложения, подписавшись на нотификацию myNotificationNameDataChanged
    [[NSNotificationCenter defaultCenter] postNotificationName:myNotificationNameDataChanged object: nil]; // в объект, вместо nil
    // можно передать любые данные,
    // поддерживающие протокол NSCoding
    [_wormhole passMessageObject: nil identifier:@"changeObjects"]; // отправляет в ВХ сообщение, с пустым телом, что данные изменились
}


////////////////////////////////////////////////////////////////////
#pragma mark - Wormhole functions
////////////////////////////////////////////////////////////////////

// iPhone

// функция отправлят в ВХ (wormhole) сообщение, что приложение на телефоне ушло в бэкграунд или закрылось (NO) либо наоборот стало активным (YES)
- (void) setPhoneStatus: (BOOL) isOnline{
    [_wormhole passMessageObject:@{ @"isOnline" : @(isOnline) } identifier:@"parentApplication"];
}

// iWatch

// функция, проверяющая запись в ВХ, по идетификатору parentApplication,
// (изменения состояния приложения. Если оно выключено или в бэкграунде - NO, если активно - YES)
- (BOOL) iPhoneStatus{
    return [[[_wormhole messageWithIdentifier:@"parentApplication"] valueForKey:@"isOnline"] boolValue];
}

// функция, добавляющая слушателя изменений в ВХ, по идетификатору parentApplication,
// (изменения состояния приложения. Если оно выключено или в бэкграунде - NO, если активно - YES)
- (void) listenPhoneStatus{
    [self.wormhole listenForMessageWithIdentifier:@"parentApplication" listener:^(id messageObject) {
        BOOL isOnlineMode = [[messageObject valueForKey:@"isOnline"] boolValue];
        [[NSNotificationCenter defaultCenter] postNotificationName:myNotificationNamePhoneStatusChanged object:@(isOnlineMode)];
    }];
}

// функция, добавляющая слушателя изменений в ВХ, по идетификатору changeObjects
- (void) listenChangeData{
    [self.wormhole listenForMessageWithIdentifier:@"changeObjects" listener:^(id messageObject) {
        [[NSNotificationCenter defaultCenter] postNotificationName:myNotificationNameDataChanged object: nil];
    }];
}

// функция отправляет в ВХ объект по заданному идетификатору
- (void) passMessageObject: (id) obj identifier: (NSString *) identifier{
    [_wormhole passMessageObject: obj identifier: identifier];
}

@end
