//
//  MyJSInterface.h
//  CJTemplateAppsWithJS
//
//  Created by Тихоненко Василий on 11/08/15.
//  Copyright (c) 2015 myWork. All rights reserved.
//

#import <Foundation/Foundation.h>

#import <AudioToolbox/AudioToolbox.h>
#import <AVFoundation/AVFoundation.h>

#import "EasyJSDataFunction.h"

#import "AMInterstitial.h"
#import "ViewController.h"

@interface NotMyJSInterface : NSObject

#pragma mark - Properties

@property (strong, nonatomic) NSMutableArray* sounds;
@property (strong, nonatomic) NSMutableArray* notifications;
@property (strong, nonatomic) NSString* imageURL;

#pragma mark - Sound

- (void) vibrate:(NSString *)vTime;
- (NSString *) newSound: (NSString *) link;
- (void) playSound: (NSString *) sid withVolume: (NSString *) volume;
- (void) playMedia:(NSString *)sid;
- (void) changeVolume: (NSString *) sid : (NSString *) volume;
- (void) setPosition: (NSString *) sid : (NSString *) position;
- (void) setLoop: (NSString *) sid : (NSString *) state;
- (NSString *) getDuration: (NSString *) sid;
- (NSString *) getPosition: (NSString *) sid;
- (void) stopSound:  (NSString *) sid;
- (void) pauseSound:  (NSString *) sid;
- (void) playLoopedSound: (NSString *) sid withVolume: (NSString *) volume;

#pragma mark - Photo

- (void)showPhotoView;
- (void) takePhoto;

#pragma mark - Notifications

- (void) createNotification: (NSString *) fullText withId: (NSString *) sid withDate: (NSString *) stime;
- (void) cancelNotification:(NSString *)notificationName;

#pragma mark - Reload web view

- (void) reloadView;

#pragma mark - Show fullscreen banner

- (void)showAd;

#pragma mark - Local storage

- (void) localStorageChanged: (NSString *) key;

#pragma mark - Other functions

- (void) getNotificationSettings;
- (void) setLockDisabled;
- (void) setLockEnabled;
- (void) getDeviceId;
- (void) hideStatusBar;
- (void) showStatusBar;
- (void) stopListenLocation;
- (void) listenLocation: (NSString *) provider;

- (void) test;
- (void) log: (NSString *) input;

@end
