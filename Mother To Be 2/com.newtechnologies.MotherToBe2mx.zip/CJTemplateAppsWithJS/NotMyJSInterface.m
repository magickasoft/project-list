//
//  MyJSInterface.m
//  CJTemplateAppsWithJS
//
//  Created by Тихоненко Василий on 11/08/15.
//  Copyright (c) 2015 myWork. All rights reserved.
//

#import "NotMyJSInterface.h"

#define rootViewController ((ViewController *)[UIApplication sharedApplication].keyWindow.rootViewController)

@implementation NotMyJSInterface

- (instancetype)init
{
    self = [super init];
    if (self) {
        _sounds = [[NSMutableArray alloc] init];
        _notifications = [[NSMutableArray alloc] init];
    }
    return self;
}

////////////////////////////////////////////////////////////////////
#pragma mark - Sound
////////////////////////////////////////////////////////////////////

//Вибрация
- (void) vibrate:(NSString *)vTime {
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
}

//Создание объекта звука
- (NSString *) newSound: (NSString *) link {
    NSString *audioFile = [NSString stringWithFormat:@"%@/assets/%@", [[NSBundle mainBundle] resourcePath], link];
    NSURL *soundURL = [NSURL fileURLWithPath:audioFile];
    AVAudioPlayer* audioPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:soundURL error:nil];
    [self.sounds addObject:audioPlayer];
    [audioPlayer prepareToPlay];
    
    NSInteger soundsCount = [self.sounds count];
    soundsCount -= 1;
    
    NSLog(@"%ld", (long)soundsCount);
    
    return [NSString stringWithFormat:@"%ld", (long)soundsCount];
}

//Проигрывание звука
- (void) playSound: (NSString *) sid withVolume: (NSString *) volume {
    AVAudioPlayer* audioPlayer = self.sounds[[sid integerValue]];
    audioPlayer.volume = [volume floatValue];
    audioPlayer.play ? [audioPlayer stop] : YES;
    audioPlayer.currentTime = 0;
    [audioPlayer play];
}

- (void) playMedia:(NSString *)sid {
    NSInteger _id = [sid integerValue];
    AVAudioPlayer* audioPlayer = self.sounds[_id];
    audioPlayer.play ? [audioPlayer stop] : YES;
    [audioPlayer play];
}

- (void) changeVolume: (NSString *) sid : (NSString *) volume {
    AVAudioPlayer* audioPlayer = self.sounds[[sid integerValue]];
    [audioPlayer setVolume:[volume floatValue]];
}

- (void) setPosition: (NSString *) sid : (NSString *) position {
    AVAudioPlayer* audioPlayer = self.sounds[[sid integerValue]];
    audioPlayer.currentTime = [position integerValue];
}

- (void) setLoop: (NSString *) sid : (NSString *) state {
    AVAudioPlayer* audioPlayer = self.sounds[[sid integerValue]];
    if ([state isEqual:@"on"]) {
        audioPlayer.numberOfLoops = -1;
    } else {
        audioPlayer.numberOfLoops = 0;
    }
}

- (NSString *) getDuration: (NSString *) sid {
    AVAudioPlayer* audioPlayer = self.sounds[[sid integerValue]];
    return [NSString stringWithFormat:@"%lf", audioPlayer.duration];
}

- (NSString *) getPosition: (NSString *) sid {
    AVAudioPlayer* audioPlayer = self.sounds[[sid integerValue]];
    return [NSString stringWithFormat:@"%lf", audioPlayer.currentTime];
}

- (void) stopSound:  (NSString *) sid {
    AVAudioPlayer* audioPlayer = self.sounds[[sid integerValue]];
    
    [audioPlayer stop];
    audioPlayer.currentTime = 0;
    
}

- (void) pauseSound:  (NSString *) sid {
    AVAudioPlayer* audioPlayer = self.sounds[[sid integerValue]];
    
    [audioPlayer pause];
}

- (void) playLoopedSound: (NSString *) sid withVolume: (NSString *) volume {
    AVAudioPlayer* audioPlayer = self.sounds[[sid integerValue]];
    
    audioPlayer.volume = [volume floatValue];
    audioPlayer.play ? [audioPlayer stop] : YES;
    audioPlayer.currentTime = 0;
    
    audioPlayer.numberOfLoops = -1;
    [audioPlayer play];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Photo
////////////////////////////////////////////////////////////////////

//Берём фото из галереи
- (void)showPhotoView{
    [rootViewController showPhotoView];
}

//Берём фото с камеры
- (void) takePhoto{
    [rootViewController takePhoto];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Camera
////////////////////////////////////////////////////////////////////

- (void) flashLightOn {
    if ([rootViewController.deviceCamera isTorchModeSupported:AVCaptureTorchModeOn]) {
        [rootViewController.deviceCamera lockForConfiguration:nil];
        NSError* error;
        [rootViewController.deviceCamera setTorchModeOnWithLevel:rootViewController.deviceCameraLightLevel error:&error];
        [rootViewController.deviceCamera unlockForConfiguration];
    }
}

- (void) flashLightOff {
    if ([rootViewController.deviceCamera isTorchModeSupported:AVCaptureTorchModeOff]) {
        [rootViewController.deviceCamera lockForConfiguration:nil];
        [rootViewController.deviceCamera setTorchMode:AVCaptureTorchModeOff];
        [rootViewController.deviceCamera unlockForConfiguration];
    }
}

- (void) isFlashLight {
    if (rootViewController.deviceCameraWork) {
        [rootViewController executeJS:@"bufferEventVar.flashLightWork = \'true\';"];
    }
    else {
        [rootViewController executeJS:@"bufferEventVar.flashLightWork = \'false\';"];
    }
}

- (void) flashLightLevel:(NSString*)lightLevel {
    if (rootViewController.deviceCameraWork) {
        rootViewController.deviceCameraLightLevel = [lightLevel floatValue];
        
        if ([rootViewController.deviceCamera torchMode]) {
            [self flashLightOn];
        }
    }
}

////////////////////////////////////////////////////////////////////
#pragma mark - Screen
////////////////////////////////////////////////////////////////////

- (void)setScreenBrightness:(NSString*)brightnessLevel {
    [[UIScreen mainScreen] setBrightness:[brightnessLevel floatValue]];
}

- (void)getScreenBrightness {
    [rootViewController executeJS:[NSString stringWithFormat:@"bufferEventVar.brightnessLevel = \'%f\';", [[UIScreen mainScreen] brightness]]];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Batery
////////////////////////////////////////////////////////////////////

- (void)getBatteryLevel {
    NSInteger currentBatteryLevelJS;
    if ([UIDevice currentDevice].batteryMonitoringEnabled) {
        currentBatteryLevelJS = roundf(([UIDevice currentDevice].batteryLevel) * 100);
    }
    else {
        [UIDevice currentDevice].batteryMonitoringEnabled = YES;
        currentBatteryLevelJS = roundf(([UIDevice currentDevice].batteryLevel) * 100);
        [UIDevice currentDevice].batteryMonitoringEnabled = NO;
    }
    
    NSString *xkty = [NSString stringWithFormat:@"%ld", (long)currentBatteryLevelJS];
    
    [rootViewController executeJS:[NSString stringWithFormat:@"bufferEventVar.batteryLevel = \'%@\';", xkty]];
}

- (void)startBatteryLevelChangedListen {
    [UIDevice currentDevice].batteryMonitoringEnabled = YES;
}

- (void)stopBatteryLevelChangedListen {
    [UIDevice currentDevice].batteryMonitoringEnabled = NO;
}

////////////////////////////////////////////////////////////////////
#pragma mark - Notifications
////////////////////////////////////////////////////////////////////

//Создание нотификации
- (void) createNotification: (NSString *) fullText withId: (NSString *) sid withDate: (NSString *) stime {
    NSDate* date = [NSDate dateWithTimeIntervalSince1970:[stime integerValue]];
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = date;
    localNotification.soundName = @"message.mp3";
    localNotification.timeZone = [NSTimeZone defaultTimeZone];
    localNotification.alertBody = fullText;
    //[localNotification setRepeatInterval:NSCalendarUnitWeekday];
    localNotification.userInfo = [NSDictionary dictionaryWithObject:sid forKey:@"mynotif"];
    
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber: 0];
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    [self.notifications addObject:localNotification];
    NSLog(@"\n\n\ncreateNotification\n\n\n");
}

//Удаление нотификации
- (void) cancelNotification:(NSString *)notificationName {
    for (UILocalNotification *notif in [[UIApplication sharedApplication] scheduledLocalNotifications])
    {
        if([[notif.userInfo objectForKey:@"mynotif"] isEqualToString:notificationName]){
            [[UIApplication sharedApplication] cancelLocalNotification:notif];
            NSLog(@"Clear notification!");
        }
    }
}

////////////////////////////////////////////////////////////////////
#pragma mark - Reload web view
////////////////////////////////////////////////////////////////////

//Перезагрузка страницы
- (void) reloadView {
    [rootViewController.webView reload];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Show fullscreen banner
////////////////////////////////////////////////////////////////////

//Ads
- (void)showAd {
    [AMInterstitial show];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Local storage
////////////////////////////////////////////////////////////////////

//LocalStorage
- (void) localStorageChanged: (NSString *) key {
    [rootViewController localStorageChanged: key];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Location
////////////////////////////////////////////////////////////////////

- (void) listenLocation: (NSString *) provider {
    if ([provider isEqualToString:@"gps"]) {
        [rootViewController setLocationListener];
    }
    else {
        NSLog(@"listenLocation() error! Please, check the provider name.");
    }
}

- (void) stopListenLocation {
    [rootViewController unSetLocationListener];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Sharing
////////////////////////////////////////////////////////////////////

- (void)sharing:(NSString*)shareString withImg:(NSString*)image64 {
    [rootViewController sharingFunction:shareString withImg:image64];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Save data from watch
////////////////////////////////////////////////////////////////////

- (void)resaveDataFromWatch {
    [rootViewController saveDataFromWatch];
}

- (void)saveDataToWormHole:(NSString*)input {
    [rootViewController saveDataToWormHole:input];
}


////////////////////////////////////////////////////////////////////
#pragma mark - Other functions
////////////////////////////////////////////////////////////////////

- (void) test {
    NSLog(@"test called");
}

- (void) log: (NSString *) input {
    NSLog(@"%@", input);
}

- (void) getNotificationSettings {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:UIApplicationOpenSettingsURLString]];
}

- (void) setLockDisabled {
    [UIApplication sharedApplication].idleTimerDisabled = YES;
}

- (void) setLockEnabled {
    [UIApplication sharedApplication].idleTimerDisabled = NO;
}

- (void) getDeviceId {
    NSString* xkty2 = [[[UIDevice currentDevice] identifierForVendor] UUIDString];
    [rootViewController executeJS:[NSString stringWithFormat:@"bufferEventVar.deviceID = \'%@\';", xkty2]];
}

- (void) hideStatusBar {
    [UIApplication sharedApplication].statusBarHidden = YES;
}

- (void) showStatusBar {
    [UIApplication sharedApplication].statusBarHidden = NO;
}

- (void) setStatusBarColor:(NSString *) color {
    if ([color isEqualToString:@"white"]) {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    }
    else {
        [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    }
}

@end
