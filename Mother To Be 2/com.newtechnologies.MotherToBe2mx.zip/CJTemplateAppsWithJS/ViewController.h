//
//  ViewController.h
//  CJTemplateAppsWithJS
//
//  Created by Тихоненко Василий on 11/08/15.
//  Copyright (c) 2015 myWork. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>
#import <AVFoundation/AVFoundation.h>

#import "EasyJSWebView.h"

#import "NotMyJSInterface.h"

#import "Model.h"

@class EasyJSWebView;
@interface ViewController : UIViewController<UIImagePickerControllerDelegate, UINavigationControllerDelegate, UIWebViewDelegate, CLLocationManagerDelegate>

@property (strong, nonatomic) MMWormhole *wormhole;

#pragma mark - Properties

@property (weak, nonatomic) IBOutlet EasyJSWebView *webView;
@property (copy, nonatomic, readonly) NSArray *runningApplications;
@property (strong, nonatomic) NSString *imageEvent;
@property (strong, nonatomic) NSString *orientationDevice;
@property (assign, nonatomic) BOOL isHiddenStatusBar;
@property (assign, nonatomic) UIStatusBarStyle styleStatusBar;

#pragma mark - Core Location properties

@property CLLocationManager *locationManager;

@property CLLocationDegrees longitude;
@property CLLocationDegrees latitude;
@property CLLocationSpeed speed;
@property CLLocationDegrees altitude;
@property (assign, nonatomic) BOOL canUpdateLocation;

#pragma mark - Web view

- (BOOL) loadLocalFile:(NSString *)name;
- (void) loadHtml;
- (BOOL) cantVibrate;
- (NSString *) executeJS:(NSString *)jsCode;

#pragma mark - Photo

- (void) showPhotoView;
- (void) takePhoto;
- (NSString *) saveToMemory:(UIImage *)image;
- (UIImage *) resizeImage:(UIImage *)image;

- (void) imagePickerControllerDidCancel:(UIImagePickerController *)picker;
- (void) dismissPicker: (UIImagePickerController *)picker;

#pragma mark - LocalStorage

- (NSString *) getLocalStorageWithKey: (NSString *)key;
- (NSString *) getLocalStorageKeys;
- (void) setLocalStorageValue: (NSString *) value withString: (NSString *) key;
- (void) localStorageChanged: (NSString *) key;

#pragma mark - Location

- (void) setLocationListener;
- (void) unSetLocationListener;
- (void) updateLocationListener;

#pragma mark - Camera

@property (assign, nonatomic) AVCaptureDevice* deviceCamera;
@property (assign, nonatomic) BOOL deviceCameraWork;
@property (assign, nonatomic) CGFloat deviceCameraLightLevel;

#pragma mark - Save data from watch

- (void) saveDataFromWatch;
- (void)saveDataToWormHole:(NSString*)input;

#pragma mark - Sharing

- (void)sharingFunction:(NSString*)shareString withImg:(NSString*)image64;

#pragma mark - Other

- (void) appMinimized;
- (void) appMaximized;

@end

