//
//  ViewController.m
//  CJTemplateAppsWithJS
//
//  Created by Тихоненко Василий on 11/08/15.
//  Copyright (c) 2015 myWork. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    NotMyJSInterface* interfaceJS;
}

@end

@implementation ViewController

////////////////////////////////////////////////////////////////////
#pragma mark - Base methods
////////////////////////////////////////////////////////////////////

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _deviceCameraLightLevel = 1;
    _canUpdateLocation = NO;
    _isHiddenStatusBar = NO;
    _styleStatusBar = UIStatusBarStyleDefault; //Белый - UIStatusBarStyleLightContent, черный - UIStatusBarStyleDefault
    
    [UIApplication sharedApplication].statusBarHidden = _isHiddenStatusBar;
    [UIApplication sharedApplication].statusBarStyle = _styleStatusBar;
    self.view.backgroundColor = [UIColor whiteColor];
    
    interfaceJS = [[NotMyJSInterface alloc] init];
    [_webView addJavascriptInterfaces: interfaceJS WithName:@"MyJS"];
    
    [self loadHtml];
    
    _deviceCamera = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    _deviceCameraWork = NO;
    if ([_deviceCamera hasTorch]) _deviceCameraWork = YES;
    
    [[Model shared] setPhoneStatus:YES];
    
    _wormhole = [Model shared].wormhole;
    
    NSString* df = [self getDateFormatted];
    
    [_wormhole listenForMessageWithIdentifier: [NSString stringWithFormat:@"MTB_mood_%@", df] listener:^(id messageObject){
        NSString* device = [_wormhole messageWithIdentifier:@"device"];
        
        if ([device isEqualToString:@"watch"]) {
            [self saveDataFromWatch];
            [self executeJS:@"Calendar.fill();"];
        }
    }];
    
    [_wormhole listenForMessageWithIdentifier: [NSString stringWithFormat:@"MTB_symptom_%@", df] listener:^(id messageObject){
        NSString* device = [_wormhole messageWithIdentifier:@"device"];
        
        if ([device isEqualToString:@"watch"]) {
            [self saveDataFromWatch];
            [self executeJS:@"Calendar.fill();"];
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(batteryLevelChanged:)
                                                 name:UIDeviceBatteryLevelDidChangeNotification
                                               object:nil];
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardDidShowNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIKeyboardWillHideNotification
                                                  object:nil];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self
                                                    name:UIDeviceBatteryLevelDidChangeNotification
                                                  object:nil];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Save data from watch
////////////////////////////////////////////////////////////////////

- (NSString*)getDateFormatted {
    NSDateFormatter* format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy_MM_dd"];
    return [format stringFromDate:[NSDate date]];
}


- (void) saveDataFromWatch {
    NSString* df = [self getDateFormatted];
    
    NSArray* whMoods = [_wormhole messageWithIdentifier:[NSString stringWithFormat:@"MTB_mood_%@", df]];
    NSArray* whSymptoms = [_wormhole messageWithIdentifier:[NSString stringWithFormat:@"MTB_symptom_%@", df]];
    
    NSString* key;
    
    if (whMoods) {
        NSString* jsonMoods = [self arrayToJSON:whMoods];
        key = [NSString stringWithFormat:@"MTB_mood_%@", [df stringByReplacingOccurrencesOfString:@"_" withString:@"/"]];
        [self executeJS:[NSString stringWithFormat:@"localStorage[\"%@\"] = \"%@\"", key, [jsonMoods stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""]]];
    }
    
    if (whSymptoms) {
        NSString* jsonSymptoms = [self arrayToJSON:whSymptoms];
        key = [NSString stringWithFormat:@"MTB_symptom_%@", [df stringByReplacingOccurrencesOfString:@"_" withString:@"/"]];
        [self executeJS:[NSString stringWithFormat:@"localStorage[\"%@\"] = \"%@\"", key, [jsonSymptoms stringByReplacingOccurrencesOfString:@"\"" withString:@"\\\""]]];
    }
    
    
}

- (void)saveDataToWormHole:(NSString*)input {
    [_wormhole passMessageObject:input identifier:@"mDate"];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Keyboard notifications
////////////////////////////////////////////////////////////////////

- (void)keyboardWasShown:(NSNotification*)aNotification{
    if (!_isHiddenStatusBar) {
        [UIApplication sharedApplication].statusBarHidden = YES;
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification{
    if (!_isHiddenStatusBar) {
        [UIApplication sharedApplication].statusBarHidden = NO;
    }
}

////////////////////////////////////////////////////////////////////
#pragma mark - Battery
////////////////////////////////////////////////////////////////////

- (void)batteryLevelChanged:(NSNotification*)aNotification{
    NSInteger batteryLevel = roundf(([UIDevice currentDevice].batteryLevel) * 100);
    
    [self executeJS:[NSString stringWithFormat:@"bufferEventVar.batteryLevel = \'%ld\';", (long)batteryLevel]];
    [self executeJS:[NSString stringWithFormat:@"window.dispatchEvent(%@);", @"batteryLevelChangedEvent"]];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Web view
////////////////////////////////////////////////////////////////////

//Подгрузка конкретного html-файла.
- (BOOL) loadLocalFile:(NSString *)name {
    NSString* path = [[NSBundle mainBundle] pathForResource:name ofType:@"html" inDirectory:@"assets"];
    
    if (!path) return NO;
    
    NSString* content = [NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil];
    if (content != nil) {
        //self.myWebView.delegate = self;
        [_webView loadHTMLString:content baseURL: [NSURL fileURLWithPath:path]];
        //[self.myWebView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path isDirectory:NO]]];
        for (id subview in _webView.subviews)
            if ([[subview class] isSubclassOfClass:[UIScrollView class]])
                ((UIScrollView *)subview).bounces = NO;
        _webView.scalesPageToFit = YES;
        return YES;
    }
    return NO;
}

//Подгрузка локального html-файла в зависимости от выбраной локали.
- (void) loadHtml {
    NSString* locale = [NSString stringWithFormat:@"index_%@", [NSLocale preferredLanguages][0]];
    if ([locale isEqualToString:@"index_en"]) locale = @"index";
    if (![self loadLocalFile:locale]) [self loadLocalFile:@"index"];
}

//Проверка типа девайса. Возвращает YES, если девайс может вибрировать и NO, если нет.
- (BOOL)cantVibrate {
    NSString *device = [UIDevice currentDevice].model;
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad || [device isEqualToString:@"iPod"]) {
        return YES;
    }
    return NO;
}

//Вызов JavaScript-кода из Objective-C
- (NSString *) executeJS:(NSString *)jsCode {
    return [_webView stringByEvaluatingJavaScriptFromString:jsCode];
}

//Событие сворачивания приложения
- (void)appMinimized {
    NSLog(@"\n\n\nMINIMIZED!!!\n\n\n");
    [self executeJS:@"window.dispatchEvent(appCloseEvent);"];
}

//Событие разворачивания приложения
- (void)appMaximized {
    NSLog(@"\n\n\nMAXIMIZED!!!\n\n\n");
    [self executeJS:@"window.dispatchEvent(appMaximizeEvent);"];
}

////////////////////////////////////////////////////////////////////
#pragma mark - Photo
////////////////////////////////////////////////////////////////////

// фото из библиотеки
- (void)showPhotoView{
    //NSLog(@"show photo view");
    _imageEvent = @"pickedImageEvent";
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker.delegate = self;
    [self presentViewController:picker animated:NO completion:nil];
}

// фото с камеры
- (void) takePhoto{
    //NSLog(@"take photo");
    _imageEvent = @"cameraCapturedImageEvent";
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
    picker.sourceType = UIImagePickerControllerSourceTypeCamera;
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}

//Return image URL
- (NSString *)saveToMemory:(UIImage *)image {
    NSString *docDir = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    
    NSDateFormatter *dateFormater = [[NSDateFormatter alloc] init];
    [dateFormater setDateFormat:@"yyyy-MM-dd-HH-mm-ss"];
    
    NSString *dateText = [dateFormater stringFromDate:[NSDate date]];
    
    NSString *pngFilePath = [NSString stringWithFormat:@"%@/%@photo.png", docDir, dateText];
    NSData *data = [NSData dataWithData:UIImagePNGRepresentation(image)];
    [data writeToFile:pngFilePath atomically:YES];
    interfaceJS.imageURL = pngFilePath;
    
    [self executeJS:[NSString stringWithFormat:@"bufferEventVar.path = \'%@\';", pngFilePath]];
    [self executeJS:[NSString stringWithFormat:@"window.dispatchEvent(%@);", _imageEvent]];
    return pngFilePath;
}

- (UIImage *)resizeImage:(UIImage *)image{
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGFloat factor = MIN(image.size.width / (screenRect.size.width/2), image.size.height / (screenRect.size.height/2));
    
    UIImage *thImage = [UIImage imageWithCGImage:image.CGImage scale:factor orientation:image.imageOrientation];
    
    UIGraphicsBeginImageContext(thImage.size);
    [thImage drawInRect:CGRectMake(0,0,thImage.size.width,thImage.size.height)];
    thImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return thImage;
}

////////////////////////////////////////////////////////////////////
#pragma mark - UIImagePickerController delegate
////////////////////////////////////////////////////////////////////

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo{
    if (image) {
        [self saveToMemory:[self resizeImage:image]];
    }
    [self dismissPicker: picker];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissPicker: picker];
}

- (void)dismissPicker: (UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
    picker = nil;
    picker.delegate = nil;
}

////////////////////////////////////////////////////////////////////
#pragma mark - LocalStorage
////////////////////////////////////////////////////////////////////

//Вызов данных о localStorage
- (NSString *) getLocalStorageWithKey: (NSString *)key {
    //NSString *result = [self executeJS:[NSString stringWithFormat:@"getLocalStorageValue(%@)", key]];
    return [_webView stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"localStorage.getItem(\"%@\")", key]];
}

//Вызов списка ключей из localStorage
- (NSString *) getLocalStorageKeys {
    return [_webView stringByEvaluatingJavaScriptFromString: @"getLocalStorageKeys()"];
}

//Заменяем поле в localStorage по ключу key на значение value
- (void) setLocalStorageValue: (NSString *) value withString: (NSString *) key {
    NSLog(@"%@", [NSString stringWithFormat:@"localStorageSetItem(\"%@\", \"%@\")", key, value]);
    [self executeJS:[NSString stringWithFormat:@"localStorageSetItem(\"%@\", \"%@\")", key, value]];
}

//Функция, которая вызывается при изменении LocalStorage
- (void) localStorageChanged: (NSString *) key {
    
    if ([key containsString:@"MTB_mood"] || [key containsString:@"MTB_symptom"]) {
        
        [_wormhole passMessageObject:@"phone" identifier:@"device"];
        
        NSString* jsonstring = [self getLocalStorageWithKey:key];
        
        if ([jsonstring isEqualToString:@""]) {
            [_wormhole passMessageObject:@[] identifier:[key stringByReplacingOccurrencesOfString:@"/" withString:@"_"]];
        } else {
            NSArray* data = [self JSONtoArray:jsonstring];
            [_wormhole passMessageObject:data identifier:[key stringByReplacingOccurrencesOfString:@"/" withString:@"_"]];
        }
        
        
        
        
        
        //        NSLog(@"%@ | %@", key, data);
        
        
        
        //NSLog(@"get %@: %@", key, [_wormhole messageWithIdentifier:@"MTB_mood_2015_09_17"]);
    }
    //    if ([key isEqualToString:@"watchList"]) {
    //        NSArray* itemsArray = [self buildWatchArray:[self JSONtoArray:[self getLocalStorageWithKey:key]]];
    //
    //        NSLog(@"%@", itemsArray);
    //
    //        [_wormhole passMessageObject:itemsArray identifier:@"historyList"];
    //    }
}

////////////////////////////////////////////////////////////////////
#pragma mark - JSON and NSDictionary
////////////////////////////////////////////////////////////////////

- (NSString*) dictionaryToJSON:(NSDictionary*)dictionary {
    NSError* error;
    NSData* jsonData;
    NSString* jsonString;
    
    jsonData = [NSJSONSerialization dataWithJSONObject:dictionary
                                               options:0
                                                 error:&error];
    
    if (jsonData) {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSLog(@"%@", jsonString);
    }
    
    return jsonString;
}

- (NSDictionary*) JSONtoDictionary:(NSString*)jsonString {
    NSError* error;
    
    NSData* jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary* jsonDictionary = [NSJSONSerialization JSONObjectWithData:jsonData options:kNilOptions error:&error];
    
    return jsonDictionary;
}

- (NSArray*) JSONtoArray:(NSString*)jsonString {
    NSError* error;
    
    NSData* jsonData = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSArray* jsonArray = [NSJSONSerialization JSONObjectWithData:jsonData options:kNilOptions error:&error];
    
    return jsonArray;
}

- (NSString*) arrayToJSON:(NSArray*)array {
    NSError* error;
    NSData* jsonData;
    NSString* jsonString;
    
    jsonData = [NSJSONSerialization dataWithJSONObject:array
                                               options:0
                                                 error:&error];
    
    if (jsonData) {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        NSLog(@"%@", jsonString);
    }
    
    return jsonString;
    
}


- (NSArray*) buildWatchArray:(NSArray*)jsonArray {
    NSInteger arrayCount = [jsonArray count], i;
    
    NSMutableArray* watchArray = [[NSMutableArray alloc] init];
    
    for (i = 0; i < arrayCount; i++) {
        NSDictionary* tempDictionary = [self JSONtoDictionary:[self getLocalStorageWithKey:[jsonArray objectAtIndex:i]]];
        
        [watchArray addObject:tempDictionary];
    }
    
    return watchArray;
}

////////////////////////////////////////////////////////////////////
#pragma mark - Location
////////////////////////////////////////////////////////////////////

- (void) setLocationListener {
    _locationManager = [[CLLocationManager alloc] init];
    _locationManager.delegate = self;
    _locationManager.distanceFilter = kCLDistanceFilterNone;
    _locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    if ([_locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [_locationManager requestWhenInUseAuthorization];
    }
    _canUpdateLocation = true;
    [_locationManager startUpdatingLocation];
    [_locationManager startUpdatingHeading];
}

- (void) unSetLocationListener {
    [_locationManager stopUpdatingLocation];
    [_locationManager stopUpdatingHeading];
}

- (void) updateLocationListener {
    if (_canUpdateLocation) [_locationManager startUpdatingLocation];
}

////////////////////////////////////////////////////////////////////
#pragma mark - CLLocationManagerDelegate
////////////////////////////////////////////////////////////////////

- (void)locationManager:(CLLocationManager *)locationManager didUpdateHeading:(CLHeading *)newHeading {
    NSInteger magneticHeading = roundf(newHeading.magneticHeading);
    NSInteger trueHeading = roundf(newHeading.trueHeading);
    
    [self executeJS:@"window.dispatchEvent(magneticHeadingEvent);"];
    [self executeJS:[NSString stringWithFormat:@"bufferEventVar.magneticHeading = %ld;", (long)magneticHeading]];
    [self executeJS:[NSString stringWithFormat:@"bufferEventVar.trueHeading = %ld;", (long)trueHeading]];
}

- (void)locationManager:(CLLocationManager *)locationManager didUpdateLocations:(NSArray *)locations {
    static int counter = 0;
    CLLocation *userLocation = locations.lastObject;
    if (userLocation != nil) {
        [self executeJS:@"window.dispatchEvent(locationChangedEvent);"];
        //NSLog(@"Location changed");
        _latitude = userLocation.coordinate.latitude;
        _longitude = userLocation.coordinate.longitude;
        _speed = userLocation.speed;
        _altitude = userLocation.altitude;
        //NSLog(@"lat %f long %f", _latitude, _longitude);
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.latitude = %f;", _latitude]];
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.longitude = %f;", _longitude]];
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.altitude = %f;", _altitude]];
        [self executeJS:[NSString stringWithFormat:@"bufferEventVar.speed = %f;", _speed]];
        if (counter++ < 1) {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                [NSThread sleepForTimeInterval:0.1];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [self locationManager:locationManager didUpdateLocations:locations];
                });
            });
        }
        
    }
}


////////////////////////////////////////////////////////////////////
#pragma mark - Sharing
////////////////////////////////////////////////////////////////////


- (void)sharingFunction:(NSString*)shareString withImg:(NSString*)image64 {
    NSURL* shareImageUrl = [NSURL URLWithString:image64];
    NSData* shareImageData = [NSData dataWithContentsOfURL:shareImageUrl];
    UIImage* shareImage = [UIImage imageWithData:shareImageData];
    
    NSArray* shareItems = [NSArray arrayWithObjects:shareString, shareImage, nil];
    
    UIActivityViewController* activityViewController = [[UIActivityViewController alloc] initWithActivityItems:shareItems applicationActivities:nil];
    activityViewController.modalTransitionStyle = UIModalTransitionStyleCoverVertical;
    
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        [self presentViewController:activityViewController animated:YES completion:nil];
    }
    else {
        UIPopoverController* popup = [[UIPopoverController alloc] initWithContentViewController:activityViewController];
        [popup presentPopoverFromRect:CGRectMake(self.view.frame.size.width/2, self.view.frame.size.height/4, 0, 0)
                               inView:self.view
             permittedArrowDirections:0
                             animated:YES
         ];
    }
}


@end
