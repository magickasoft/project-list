/*
    Created: Felinger
    Version: 1.0
    Date: 24/05/2015
    Dependences: tap.mod.js, pagination.css

    <div id="pageWrap" class="perspective">
        <div id="index" class="page"></div>
        <div id="second" class="page"></div>
    </div>

    Page = new Pagination(
        'pageWrap',             // wrap of the pages
        'page',                 // class of each page
        'index',                // start page name(id)
        function(pageName){     // callback function before animate
        },
        function(pageName){     // callback function after animate
        }
    );
*/

(function(window, document) {

    'use strict';

    function Pagination(wrapId, pageClass, startPage, beforeOpen, afterOpen) {
        this.currPage = document.getElementById(startPage);
        this.nextPage = null;
        this.prevs = [];

        this.animEndEventName = 'webkitTransitionEnd';

        this.beforeOpen = beforeOpen || null;
        this.afterOpen = afterOpen || null;

        this.main = document.getElementById(wrapId);
        
        this.pages = this.main.getElementsByClassName(pageClass);
        for(var i = this.pages.length; --i >= 0;){
            var p = this.pages[i];
            p.dataset.originalClassList = p.className;
        }

        var go = document.getElementsByClassName('go');
        var that = this;
        for(var i = go.length; --i >= 0;){
            new Tap(go[i]).addEventListener('tap', function(e){
                e.preventDefault();
                e.stopPropagation();
                that.open(e.currentTarget.dataset.page, e.currentTarget.dataset.back);
            });
        }
        this.open(this.currPage, false, true);
    }

    Pagination.prototype.open = function(p, back, firstOpen){
		if(p == this.currPage.id || this.isAnimating) return false;
        this.isAnimating = true;
        this.main.classList.add('animating');

        this.nextPage = typeof p === 'object' ? p : document.getElementById(p);
        this.nextPage.classList.add('currentPage');
        if(this.beforeOpen) this.beforeOpen(this.nextPage.id);
        if(!back) this.prevs.push(this.nextPage.id);

        if(!firstOpen){
            if(back) this.main.classList.add('animatingBack');
        }else{
            this.onEndAnimation();
            return true;
        }

        var that = this;
        setTimeout(function(){
            if(!firstOpen){
                that.currPage.classList.add('outClass');
                that.nextPage.classList.add('inClass');
                
                that.bindedEndCurrent = that.endCurrent.bind(that);
                that.currPage.addEventListener(that.animEndEventName, that.bindedEndCurrent);
                
                that.bindedEndNext = that.endNext.bind(that);
                that.nextPage.addEventListener(that.animEndEventName, that.bindedEndNext);

            }else that.endCurrPage = true;
        }, 20);     // SUPER EFFECT SET TO 100 - TRY IT!
	}

    Pagination.prototype.back = function(){
        if(this.prevs.length > 1) this.prevs.splice(this.prevs.length-1, 1);
        this.open(this.prevs[this.prevs.length-1], true);
    }

    Pagination.prototype.endCurrent = function(){
        this.currPage.removeEventListener(this.animEndEventName, this.bindedEndCurrent);
        this.endCurrPage = true;
        if(this.endNextPage) this.onEndAnimation();
    }

    Pagination.prototype.endNext = function(){
        this.nextPage.removeEventListener(this.animEndEventName, this.bindedEndNext);
        this.endNextPage = true;
        if(this.endCurrPage) this.onEndAnimation();
    }

    Pagination.prototype.onEndAnimation = function(){
        this.endCurrPage = false;
		this.endNextPage = false;

        this.currPage.className = this.currPage.dataset.originalClassList;
		this.nextPage.className = this.nextPage.dataset.originalClassList+' currentPage';
        this.main.classList.remove('animating');
        this.main.classList.remove('animatingBack');

        this.currPage = this.nextPage;
        this.isAnimating = false;
        if(this.afterOpen) this.afterOpen(this.nextPage.id);
	}

    window.Pagination = Pagination;
}(window, document));