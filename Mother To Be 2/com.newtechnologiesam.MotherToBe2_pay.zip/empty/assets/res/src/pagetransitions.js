(function(window, document){

    'use strict';

    function PageTransitions(wrapId, pageClass, pageNum){
        this.isAnimating = false;
        this.endCurrPage = false;
        this.endNextPage = false;
        this.bindedEndCurrent = null;
        this.bindedEndNext = null;
        this.cPage = null;
        this.nPage = null;
        // animation end event name for webkit
        this.animEndEventName = 'webkitTransitionEnd';

        this.main = document.getElementById(wrapId);
        this.pages = this.main.getElementsByClassName(pageClass);

        for(var i = this.pages.length; --i >= 0;){
            var page = this.pages[i];
			page.dataset.originalClassList = page.className;
        }
    }

    PageTransitions.prototype.open = function(p, back){
		if(this.isAnimating) return false;
        this.isAnimating = true;
        document.body.classList.add('animate');

        this.cPage = document.getElementsByClassName('ptCurrentPage')[0];

        this.nPage = p;

        this.nPage.classList.add('ptCurrentPage');

        var outClass = '', inClass = '';

        if(this.cPage){
            // Back or not to back
            if(back){
                document.body.classList.add('pageBack');
                outClass = 'pt-page-moveToBottom';
                inClass = 'pt-page-moveFromTop';
            }else{
                outClass = 'pt-page-moveToTop';
                inClass = 'pt-page-moveFromBottom';
            }
        }else{
            // First Open
            this.onEndAnimation();   
        }
        var that = this;
        setTimeout(function(){
            if(that.cPage){
                that.cPage.classList.add(outClass);
                that.bindedEndCurrent = that.endCurrent.bind(that);
                that.bindedEndNext = that.endNext.bind(that);
                that.cPage.addEventListener(that.animEndEventName, that.bindedEndCurrent);
                that.nPage.addEventListener(that.animEndEventName, that.bindedEndNext);
            }else that.endCurrPage = true;

            if(inClass) that.nPage.classList.add(inClass);
        }, 20);     // SUPER EFFECT SET TO 100 - TRY IT!
	}

    PageTransitions.prototype.endCurrent = function(){
        this.cPage.removeEventListener(this.animEndEventName, this.bindedEndCurrent);
        this.endCurrPage = true;
        if(this.endNextPage) this.onEndAnimation();
    }

    PageTransitions.prototype.endNext = function(){
        this.nPage.removeEventListener(this.animEndEventName, this.bindedEndNext);
        this.endNextPage = true;
        if(this.endCurrPage) this.onEndAnimation();
    }

    PageTransitions.prototype.onEndAnimation = function(){
        this.endCurrPage = false;
		this.endNextPage = false;

        if(this.cPage) this.cPage.className = this.cPage.dataset.originalClassList;
		this.nPage.className = this.nPage.dataset.originalClassList+' ptCurrentPage';
        document.body.classList.remove('animate');
        document.body.classList.remove('pageBack');

        this.isAnimating = false;
        // TODO set callback
        // Own script
        // if(Page.current == 'index') document.body.scrollTop = Page.scrollOffset;
	}

    window.PageTransitions = PageTransitions;
}(window, document));