package com.newtechnologiesam.MotherToBe2_pay;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.am.js.AlarmHelper;
import com.am.js.NotificationHelper;
import com.google.gson.Gson;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

public class AppBootReceiver extends BroadcastReceiver {

	Context context=null;
		
    @Override
    public void onReceive(Context context, Intent intent) {
    	this.context=context;
        if (intent.getAction().equals("android.intent.action.BOOT_COMPLETED")) {
        	reastablishAlarmList(new AlarmHelper(context, MainActivity.class));
        	reastablishNotifList(new NotificationHelper(context));
        }

    }
    
    private void reastablishAlarmList(AlarmHelper alarmHelper){
    	
    	Gson gson=new Gson();
    	
    	ArrayList<Map<String,String>> alarmList=alarmHelper.getAlarmList();
    	
    	for(Map<String, String> map : alarmList){
    		
    		if(Boolean.parseBoolean(map.get("isRepeat"))==false){
    			long time=Long.parseLong(map.get("time"));
    			int alarmId=Integer.parseInt(map.get("alarmId"));
    			int type=Integer.parseInt(map.get("type"));
    			alarmHelper.registerUnitAlarm(type, time, alarmId);
    			
    			Toast.makeText(context, "alarmId "+alarmId, Toast.LENGTH_LONG).show();
				
    			//Log.i("boot reastab alarm", "alarmId "+alarmId);
    			
    		}
    		else if(Boolean.parseBoolean(map.get("isRepeat"))==true){
    			long time=Long.parseLong(map.get("time"));
    			long timeInterval=Integer.parseInt(map.get("timeInterval"));
    			int alarmId=Integer.parseInt(map.get("alarmId"));
    			int type=Integer.parseInt(map.get("type"));
    			
    			while(System.currentTimeMillis()>time)
    				time+=timeInterval;
    				
    			alarmHelper.registerRepeatAlarm(type, time, timeInterval, alarmId);	
    			Toast.makeText(context, "alarmId "+alarmId, Toast.LENGTH_LONG).show();
				
    			//Log.i("boot reastab alarm", "alarmId "+alarmId);
    			
    		}
    			
    	}
    }
    
	private void reastablishNotifList(NotificationHelper notificationHelper) {

		Gson gson = new Gson();

		ArrayList<Map<String, String>> alarmList = notificationHelper
				.getAlarmList();

		for (Map<String, String> map : alarmList) {

			if (Boolean.parseBoolean(map.get("isRepeat")) == false) {
				long time = Long.parseLong(map.get("time"));
				int alarmId = Integer.parseInt(map.get("alarmId"));
				String title = map.get("title");
				String text = map.get("text");
				int type=Integer.parseInt(map.get("type"));
				notificationHelper.registerUnitNotif(type, time, alarmId, title,text);
				
				Toast.makeText(context, "alarmId "+alarmId+"title "+title+"text "+text, Toast.LENGTH_LONG).show();
				//Log.i("boot reastab notif", "alarmId "+alarmId+"title "+title+"text "+text);

			} else if (Boolean.parseBoolean(map.get("isRepeat")) == true) {
				
			}

		}
	}
	
	
    
    
    
 
    
}
