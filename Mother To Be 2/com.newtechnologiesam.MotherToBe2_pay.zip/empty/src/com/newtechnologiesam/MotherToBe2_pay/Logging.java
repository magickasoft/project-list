package com.newtechnologiesam.MotherToBe2_pay;

import android.util.Log;

public class Logging {

	public static void err(String text, Throwable e) {
        String message = getInfo();
        Log.e(message, text, e);
    }

    public static void err(String text) {
        String message = getInfo();
        Log.e(message, text);
    }
    public static void err(Throwable e) {
        String message = getInfo();
        Log.e(message, "_", e);
    }

    public static void warn(String text) {
        String message = getInfo();
        Log.w(message, text);
    }

    public static void warn(String text, Throwable e) {
        String message = getInfo();
        Log.e(message, text, e);
    }

    public static void trace(String text) {
        String message = getInfo();
        Log.i(message, text);
    }

    public static void trace(String text, Throwable e) {
        String message = getInfo();
        Log.i(message, text, e);
    }
    public static void info() {
        String message = getInfo();
        Log.d(message, "_");
    }

    private static String getInfo() {
        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();
        if (stackTraceElements.length >= 4) {
            StackTraceElement element = stackTraceElements[4];
            String className = element.getClassName();
            String methodName = element.getMethodName();
	        String mainTAG = "BANNER ";
	        int lineNumber=element.getLineNumber();
	        return mainTAG + className + " : " + methodName+" "+lineNumber;
        }
        return "";
    }
}
