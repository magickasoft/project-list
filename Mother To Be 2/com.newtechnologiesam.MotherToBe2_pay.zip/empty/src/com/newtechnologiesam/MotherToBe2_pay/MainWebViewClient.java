package com.newtechnologiesam.MotherToBe2_pay;

import java.util.HashMap;
import java.util.Map;

import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.am.js.JavaExecutor;
import com.newtechnologiesam.MotherToBe2_pay.R;


public class MainWebViewClient extends WebViewClient {

    private MainWebView webView;
    private MainActivity activity;


    public MainWebViewClient (MainActivity activity, MainWebView webView) {
        this.activity = activity;
        this.webView = webView;
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    @Override
    public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
        Logging.info();
        webView.stopLoading();
        if (!activity.checkNetworkConnection()) {
            activity.showErrorScreen(true);

            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.HONEYCOMB) {
                if (activity.getActionBar() != null && activity.getResources().getString(R.string.SHOW_ACTION_BAR).equals(activity.SHOW_ACTION_BAR)) {
                    activity.setInactiveDrawables();
                }
            }
        } else {
            activity.showErrorScreen(false);
        }

    }

    /*@Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        Logging.info();
        try {
        	//-------------------------------------
            if (url.startsWith("./")) {
                try {
                    ((MainWebView) view).loadHtml("file:///android_asset/res" + url.substring(url.indexOf("/"), url.length() - 1));
                    return true;
                } catch (Exception e) {
                    Logging.err(e);
                }
            }
            //--------------------------------------
            Intent intent;
            String originOfUrl = url.substring(0, url.indexOf("://"));
            Logging.trace("originOfUrl = " + originOfUrl);
            switch (originOfUrl) {
                case "https":
                    Logging.trace("url start with https" + url);
                    if (url.startsWith("https://play.google.com/store/apps/details?id=")) {
                        Logging.trace("url lead to GooglePlay");
                        break;
                    }
                case "http":
                    Logging.trace("url start with http" + url);
                    Map<String, String> extraHeaders = new HashMap<>();
                    extraHeaders.put("referer", webView.getCurrentUrl());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO) {
                        view.loadUrl(url, extraHeaders);
                    }
                    else {
                        view.loadUrl(url);
                    }
                    return true;
                case "outer_http":
                    url = url.replace("outer_http", "http");
                    break;
                case "outer_https":
                    url = url.replace("outer_https", "https");
                    break;
            }
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            activity.startActivity(intent);

        } catch (ActivityNotFoundException e) {
            Logging.err(e);
            if (url.startsWith("market://")) {
                String appName = url.substring(url.indexOf("=") + 1);
                url = "https://play.google.com/store/apps/details?id=" + appName;
            }
        }
        return true;
    }

    @Override
    public void onLoadResource(WebView view, String url) {
        super.onLoadResource(view, url);
    }

    @Override
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        Logging.info();
    	super.onPageStarted(view, url, favicon);*/
        /*if (activity.getResources().getString(R.string.SHOW_PROGRESS_BAR).equals(activity.SHOW_PROGRESS_BAR))
            webView.progressBar.setVisibility(View.VISIBLE);*/
        
        
    //}
	
	@Override
    public boolean shouldOverrideUrlLoading(WebView view, String url) {
        Logging.info();
        try {
        	//-------------------------------------
            if (url.startsWith("./")) {
                try {
                    ((MainWebView) view).loadHtml("file:///android_asset/res" + url.substring(url.indexOf("/"), url.length() - 1));
                    return true;
                } catch (Exception e) {
                    Logging.err(e);
                }
            }
            //--------------------------------------
            Intent intent;

            //---------------------добавил это
            if (url.startsWith("file:///android_asset/res/outer_https")) {
                url = url.replaceFirst("file:///android_asset/res/(outer_https?://.*$)", "$1");
            }
            if (url.startsWith("file:///android_asset/res/outer_http")) {
                url = url.replaceFirst("file:///android_asset/res/(outer_http?://.*$)", "$1");
            }
            //----------------------------

            String originOfUrl = url.substring(0, url.indexOf("://"));
            Logging.trace("originOfUrl = " + originOfUrl);

            if (url.contains("file:///")) {
                try {
                    ((MainWebView)view).loadHtml(url);
                    return true;
                } catch (Exception e) {
                    Logging.err(e);
                }
            }

            //-------------- и это
            if (url.contains("://instagram.com/accounts/password/reset/")) {
                Logging.trace("Instagram reset");
                return true;
            }
            if (url.contains("://m.facebook.com/click.php?redir_url=market")) {
            	Logging.trace("FB reset");
            	return true;
            	}
            if (url.contains("://oauth.vk.com/blank.html#error=access_denied&error_reason=user_denied")) {
                Logging.trace("vk user denied");
                webView.loadHtml("file:///android_asset/res/index.html");
                return true;
            }
            if (url.startsWith("http") && url.indexOf("/blank.html") > 0 && url.indexOf("#access_token=") > 0) {
                String hash = Uri.parse(url).getFragment();
                Logging.trace("Access token data: " + hash);
                webView.loadHtml("file:///android_asset/res/index.html#" + hash);
                return true;
            }
            //--------------

            switch (originOfUrl) {
                case "https":
                    Logging.trace("url start with https" + url);
                    if (url.startsWith("https://play.google.com/store/apps/details?id=")) {
                        Logging.trace("url lead to GooglePlay");
                        break;
                    }
                case "http":
                    Logging.trace("url start with http" + url);
                    Map<String, String> extraHeaders = new HashMap<>();
                    extraHeaders.put("referer", webView.getCurrentUrl());
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.FROYO) {
                        view.loadUrl(url, extraHeaders);
                    }
                    else {
                        view.loadUrl(url);
                    }
                    return true;
                case "outer_http":
                    url = url.replace("outer_http", "http");
                    break;
                case "outer_https":
                    url = url.replace("outer_https", "https");
                    break;
            }
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            activity.startActivity(intent);

        } catch (ActivityNotFoundException e) {
            Logging.err(e);
            if (url.startsWith("market://")) {
                String appName = url.substring(url.indexOf("=") + 1);
                url = "https://play.google.com/store/apps/details?id=" + appName;
            }
        }
        return true;
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        Logging.info();
        Logging.trace("current url = " + url);
    	super.onPageFinished(view, url);
        //webView.progressBar.setVisibility(View.GONE);
        webView.setCurrentUrl(url);

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.HONEYCOMB) {
            if (activity.getActionBar() != null && activity.getResources().getString(R.string.SHOW_ACTION_BAR).equals(activity.SHOW_ACTION_BAR) && activity.checkNetworkConnection()) {
                activity.setDrawables();
            }
        }
        
        activity.processWebViewStart(view);
        Logging.trace("finish on page");
    }

    @Override
    public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
        Logging.info();
        super.doUpdateVisitedHistory(view, url, isReload);
    }
}
