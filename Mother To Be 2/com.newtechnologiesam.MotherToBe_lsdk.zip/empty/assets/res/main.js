var BANNER = true;

var progressCircle = null;
var fdtDate = null, fdtNotification = null, fdtWeight = null;
var wChart;

// Utils
// ---------------------------------------------------------------------------------------------------------------------------------
function zero(n){ return (n*1 < 10) ? '0'+(n*1) : ''+(n*1); }
function getNumEnding(iNumber, aEndings){
    var sEnding, i;
    iNumber = iNumber % 100;
    if(iNumber>=11 && iNumber<=19){
        sEnding=aEndings[2];
    }else{
        i = iNumber % 10;
        switch (i){
            case (1): sEnding = aEndings[0]; break;
            case (2):
            case (3):
            case (4): sEnding = aEndings[1]; break;
            default: sEnding = aEndings[2];
        }
    }
    return sEnding;
}
function diff(d0, d1){
    d0.setHours(0,0,0,0);
    d1.setHours(0,0,0,0);
    var dt = (d1.getTime() - d0.getTime()) / (1000*60*60*24),
        cDay = Math.floor(dt),
        cWeek = 0,
        res = '';
    
    if(cDay >= 7) cWeek = Math.floor(cDay/7);
    cDay = cDay-Math.floor(cWeek*7);

    tDay = getNumEnding(cDay, [_w.den[LN], _w.dnya[LN], _w.dney[LN]]); //['яблоко', 'яблока', 'яблок']
    tWeek = getNumEnding(cWeek, [_w.nedelya[LN], _w.nedeli[LN], _w.nedel[LN]]); //['яблоко', 'яблока', 'яблок']

    var eWeek = (cWeek == 0) ? '' : cWeek+' '+tWeek;
    var eDay = (cDay == 0) ? '' : cDay+' '+tDay;
    if(eWeek != '' && eDay != '') eWeek += ', ';
    if(eWeek == '' && eDay == '') eWeek = '0 '+_w.dney[LN];

    return {text: eWeek+eDay, fullWeeks: cWeek+1};
}
function sortByFirst(a, b){
    if(a[0] > b[0]) return 1;
    else if(a[0] < b[0]) return -1;
    else return 0;
}
function getWeekInfo(callback){
    var req = new XMLHttpRequest();
    req.onreadystatechange = function(){
        if(req.readyState == 4) callback(req.responseText);
    }
    req.open('GET', 'weeksinfo/'+LN+'.txt', true);
    req.send(null);
}
var AJAX = {
    search: function(url, data, beforeSend, success, error){
        beforeSend();
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.open('POST', url, true);
        xmlhttp.onreadystatechange = function(){
            if(xmlhttp.readyState == 4){
                if(xmlhttp.status == 200){
                    if(xmlhttp.responseText != '') success(xmlhttp.responseText);
                }else error();
            }
        };
        xmlhttp.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
        xmlhttp.send(data);
    }
}
// Page
// ---------------------------------------------------------------------------------------------------------------------------------
var Page = {
    pages: null,
    current: '',
    prev: new Array(),
    init: function(startPage){
        var go = document.querySelectorAll('.go');
        for(var i = go.length; --i >= 0;){
            new Tap(go[i]);
            go[i].addEventListener('tap', function(e){
                e.preventDefault();
                e.stopPropagation();
                var back = (e.currentTarget.dataset.back) ? true : false;
                Page.open(e.currentTarget.dataset.page, back);
            });
        }
        Page.pages = new PageTransitions('ptWrap', 'ptPage');
        if(startPage) Page.open(startPage);
    },
    show: function(p, b){
        this.pages.open(document.getElementById(p), b);
        if(!b) this.prev.push(p);
        this.current = p;
        document.getElementById('header').className = p+'Page';
        var title = (_w[p]) ? _w[p][LN] : _w.index[LN];

        switch(p){
            case 'photo':
                Data.photo.refreshList();
            break;
            case 'settings':
                var dtInfo = localStorage.getItem('MTB_m_date') ? localStorage['MTB_m_date'].split('|') : '';
                
                var dtType = (dtInfo != '') ? dtInfo[0] : 0;
                var dtDate = (dtInfo != '') ? new Date(dtInfo[1]) : new Date();

                if(!fdtDate) fdtDate = new Fdt('fdt', {mode: 'date', startDate: dtDate}); else fdtDate.setDate(dtDate);
                
                var dateType = document.getElementById('dateType');
                dateType.getElementsByClassName('active')[0].classList.remove('active');
                dateType.getElementsByTagName('div')[dtType].classList.add('active');

                if(localStorage.getItem('MTB_start_weight')){
                    var weights = JSON.parse(localStorage.getItem('MTB_weight'));
                    var stIndex = weights.map(function (element) {return element[0];}).indexOf(localStorage.getItem('MTB_start_weight'));
                    document.getElementById('iFirstWeight').value = weights[stIndex][1];
                }
            break;
            case 'index':
                var startColor = '#F66526';
                var endColor = '#F66526';

                var progressEl = document.getElementById('progress');
                
                if(!progressCircle){
                    progressCircle = new ProgressBar.Circle(progressEl, {
                        color: startColor,
                        
                        trailColor: '#D8D8D8',
                        trailWidth: 4,
                        duration: 1000,
                        easing: 'bounce',
                        strokeWidth: 4,

                        from: {color: startColor},
                        to: {color: endColor},

                        // Set default step function for all animate calls
                        step: function(state, circle) {
                            circle.path.setAttribute('stroke', state.color);
                        }
                    });
                }
                var pr = Data.cWeek/40;
                if(!Page.animTimeout){
                    setTimeout(function(){ progressCircle.animate(pr); }, 2150);
                    Page.animTimeout = 300;
                }else{
                    that = this;
                    setTimeout(function(){ progressCircle.animate(pr); }, that.animTimeout);
                }

                
                /*
                if(!localStorage.getItem('MTB_mayShare')){
                    setTimeout(function(){
                        if(Page.current == 'index' && document.getElementById('helpTip').style.display != 'block'){
                            HelpTip.show('share', _w.mayShare[LN], function(e){
                                e.preventDefault();
                                e.stopPropagation();
                                HelpTip.close();
                                localStorage.setItem('MTB_mayShare', 'true');
                            });
                        }
                    }, 8000);
                }
                */

                var now = new Date(),
                    nowF = now.getFullYear()+'/'+zero(now.getMonth()+1)+'/'+zero(now.getDate());

                document.getElementById('noteNotif').style.display = (localStorage.getItem('MTB_note_'+nowF)) ? 'block' : 'none';

                var weightNotif = document.getElementById('weightNotif');
                if(localStorage.getItem('MTB_weight') && localStorage.getItem('MTB_start_weight')){
                    var weights = JSON.parse(localStorage.getItem('MTB_weight'));
                    lastWeight = weights[weights.length-1];

                    var stIndex = weights.map(function (element) {return element[0];}).indexOf(localStorage.getItem('MTB_start_weight'));

                    var diff = (lastWeight[1]-weights[stIndex][1]);
                    weightNotif.innerText = (diff>0) ? '+'+(diff.toFixed(1)*1) : diff.toFixed(1)*1;
                    weightNotif.style.display =  'block';
                }else weightNotif.style.display = 'none';

            break;
            case 'calendar':
                Calendar.fill();
            break;
            case 'addNote':
                var dt = Calendar.cDate.getFullYear()+'/'+zero(Calendar.cDate.getMonth()+1)+'/'+zero(Calendar.cDate.getDate());
                var del = '';
                if(localStorage.getItem('MTB_note_'+dt)){
                    del = '<img src="img/delete.png" class="del" />';
                    var data = JSON.parse(localStorage['MTB_note_'+dt]);
                    document.getElementById('noteText').value = data.text
                    if(data.notification == true){
                        document.getElementById('radioNotification').classList.add('active');
                        document.getElementById('fdtNotification').style.display = 'block';
                        if(!fdtNotification) fdtNotification = new Fdt('fdtNotification', {mode: 'dateTime', startDate: new Date(data.timeStamp)}); else fdtNotification.setDate(new Date(data.timeStamp));
                    }else{
                        document.getElementById('radioNotification').classList.remove('active');
                        document.getElementById('fdtNotification').style.display = 'none';
                    }
                }else{
                    document.getElementById('noteText').value = '';
                    document.getElementById('radioNotification').classList.remove('active');
                    document.getElementById('fdtNotification').style.display = 'none';
                }
                document.getElementById('noteDate').innerHTML = fDates[LN].daysShort[Calendar.cDate.getDay()]+', '+Calendar.cDate.getDate()+' '+fDates[LN].months[Calendar.cDate.getMonth()]+' '+Calendar.cDate.getFullYear()+del;
            break;
            case 'notes':
                Data.note.refreshList();
            break;
            case 'viewNote':
                title = _w.addNote[LN];
                Data.note.refreshNote();
            break;
            case 'weight':
                Data.weight.refreshList();
            break;
            case 'addWeight':
                if(!fdtWeight){
                    fdtWeight = new Fdt('fdtWeight', {mode: 'date'}, function(){
                        var dt = this.getDate().text;
                        if(localStorage.getItem('MTB_weight')){
                            var data = JSON.parse(localStorage['MTB_weight']);
                            var find = false;
                            for(var i = data.length; --i >= 0;){
                                if(data[i][0] == dt){
                                    document.getElementById('iAddWeight').value = data[i][1]*1;
                                    find = true;
                                    break;
                                }
                            }
                            if(!find) document.getElementById('iAddWeight').value = '';
                        }else document.getElementById('iAddWeight').value = '';
                    });
                }else fdtWeight.setDate(new Date());
            break;
        }

        if(Page.adTime){
            var now = new Date();
            if(now.getTime() > Page.adTime.getTime()+(60*1000)){
                JSAPI.showAd();
                Page.adTime = new Date();
            }
        }else Page.adTime = new Date();

        document.getElementById('title').innerHTML = '<p>'+title+'</p>';
    },
    back: function(){
        Page.prev.splice(Page.prev.length-1, 1);
        if(Page.prev.length != 0) Page.open(Page.prev[Page.prev.length-1], true); else Page.open('index', true);
    },
    open: function(p, b){
        if(p == this.current || Page.pages.isAnimating) return false;
        Page.show(p, b);
    }
}
// Dialog
// ---------------------------------------------------------------------------------------------------------------------------------
var Dialog = {
    funcOk: null,
    close: function(){
        document.getElementById('dialog').style.display = 'none';
    },
    show: function(text, okBtn, funcOk){
        this.funcOk = funcOk;
        var dW = document.getElementById('dialog');
        dW.getElementsByTagName('P')[0].innerHTML = text;
        dW.style.display = 'block';
        var wr = dW.getElementsByTagName('div')[0];
        wr.style.marginTop = '-'+(wr.offsetHeight/2)+'px';
        document.getElementById('dialogOk').innerText = okBtn;
    },
    init: function(){
        new Tap('dialogOk').addEventListener('tap', function(e){ e.preventDefault(); e.stopPropagation(); Dialog.funcOk(); Dialog.close(); });
        new Tap('dialogCancel').addEventListener('tap', function(e){ e.preventDefault(); e.stopPropagation(); Dialog.close(); });
         
        var dParent = document.getElementById('dialog');
        dParent.addEventListener('touchmove', function(e){ e.preventDefault(); e.stopPropagation(); });
        dParent.addEventListener('touchend', function(e){ if(e.target.classList.contains('dParent')){ e.preventDefault(); e.stopPropagation(); Dialog.close(); } });
    }
}
// SelectMood
// ---------------------------------------------------------------------------------------------------------------------------------
var SelectMood = {
    funcOk: null,
    close: function(){
        document.getElementById('moodSelect').style.display = 'none';
    },
    show: function(funcOk){
        this.funcOk = funcOk;
        var dW = document.getElementById('moodSelect');
        dW.style.display = 'block';
        var wr = dW.getElementsByTagName('div')[0];
        wr.style.marginLeft = '-'+(wr.offsetWidth/2)+'px';
        wr.style.marginTop = '-'+(wr.offsetHeight/2)+'px';
    },
    init: function(){ 
        var dParent = document.getElementById('moodSelect');
        dParent.addEventListener('touchmove', function(e){ e.preventDefault(); });
        //dParent.addEventListener('touchend', function(e){ if(e.target.classList.contains('dParent')){ e.preventDefault(); e.stopPropagation(); SelectMood.close(); } });

        new Tap(dParent, 'itm').addEventListener('tap', function(e){
            e.preventDefault();
            e.stopPropagation();
            if(e.target.classList.contains('dParent')){
                SelectMood.close();
                return;
            }
            if(e.detail.cTarget == e.currentTarget) return;
            var selected = dParent.getElementsByClassName('active')[0];
            if(selected) selected.classList.remove('active');
            e.detail.cTarget.classList.add('active');
        });

        new Tap('moodSelectOk').addEventListener('tap', function(e){
            e.preventDefault();
            e.stopPropagation();
            var selected = dParent.getElementsByClassName('active')[0];
            if(selected){
                SelectMood.funcOk(selected.dataset.val);
                SelectMood.close();
            }
        });
        new Tap('moodSelectCancel').addEventListener('tap', function(e){ e.preventDefault(); e.stopPropagation(); SelectMood.close(); });
    }
}
// SelectSymptom
// ---------------------------------------------------------------------------------------------------------------------------------
var SelectSymptom = {
    funcOk: null,
    close: function(){
        document.getElementById('symptomSelect').style.display = 'none';
    },
    show: function(funcOk){
        this.funcOk = funcOk;
        var dW = document.getElementById('symptomSelect');
        dW.style.display = 'block';
        var wr = dW.getElementsByTagName('div')[0];
        wr.style.marginLeft = '-'+(wr.offsetWidth/2)+'px';
        wr.style.marginTop = '-'+(wr.offsetHeight/2)+'px';
    },
    init: function(){
        var dParent = document.getElementById('symptomSelect');
        dParent.addEventListener('touchmove', function(e){ e.preventDefault(); e.stopPropagation(); });
        //dParent.addEventListener('touchend', function(e){ if(e.target.classList.contains('dParent')){ e.preventDefault(); e.stopPropagation(); SelectSymptom.close(); } });
        new Tap(dParent, 'itm').addEventListener('tap', function(e){
            e.preventDefault();
            e.stopPropagation();
            if(e.target.classList.contains('dParent')){
                SelectSymptom.close();
                return;
            }
            if(e.detail.cTarget == e.currentTarget) return;
            var selected = dParent.getElementsByClassName('active')[0];
            if(selected) selected.classList.remove('active');
            e.detail.cTarget.classList.add('active');
        });

        new Tap('symptomSelectOk').addEventListener('tap', function(e){
            e.preventDefault();
            e.stopPropagation();
            var selected = dParent.getElementsByClassName('active')[0];
            if(selected){
                SelectSymptom.funcOk(selected.dataset.val);
                SelectSymptom.close();
            }
        });
        new Tap('symptomSelectCancel').addEventListener('tap', function(e){ e.preventDefault(); e.stopPropagation(); SelectSymptom.close(); });
    }
}
// Photo popup
// ---------------------------------------------------------------------------------------------------------------------------------
var PhotoPopup = {
    close: function(){
        document.getElementById('photoPopup').style.display = 'none';
    },
    show: function(url){
        var dW = document.getElementById('photoPopup');
            dW.style.backgroundImage = url; //"url('"+url+"')";
            dW.style.display = 'block';
    },
    init: function(){
        new Tap('photoPopup').addEventListener('tap', function(e){
            e.preventDefault();
            e.stopPropagation();

            if(e.target.id == 'delPhoto'){
                var val = e.target.dataset.val;
                console.log(val);
                Dialog.show(_w.del[LN], _w.del[LN], function(){ 
                    Data.photo.del(val);
                    Data.photo.refreshList();
                    PhotoPopup.close();
                });
            }else PhotoPopup.close();
        });
    }
}
// Photo add popup
// ---------------------------------------------------------------------------------------------------------------------------------
var PhotoSelect = {
    close: function(){
        document.getElementById('photoSelect').style.display = 'none';
    },
    show: function(url){
        var dW = document.getElementById('photoSelect');
        dW.style.display = 'block';
        var wr = dW.getElementsByTagName('div')[0];
            wr.style.marginTop = '-'+(wr.offsetHeight/2)+'px';
            console.log(wr.offsetHeight);
        
    },
    init: function(){
        new Tap('photoSelect').addEventListener('tap', function(e){ e.preventDefault(); e.stopPropagation(); PhotoSelect.close(); });
    }
}
// ---------------------------------------------------------------------------------------------------------------------------------
var HelpTip = {
    callback: null,
    init: function(){
        new Tap('helpTip');
    },
    oParams: function(obj){
        var curleft = 0,
            curtop = 0;
        var width = obj.offsetWidth;
        var height = obj.offsetHeight;
        if(obj.offsetParent){
            do{
                curleft += obj.offsetLeft;
                curtop += obj.offsetTop;
            }while(obj = obj.offsetParent);
        }
        return [curleft, curtop, width, height];
    },
    show: function(el, txt, callback){
        el = typeof el === 'object' ? el : document.getElementById(el);
        var params = this.oParams(el);
        var helpTipHighlight = document.getElementById('helpTipHighlight');
            helpTipHighlight.style.left = (params[0]-3)+'px';
            helpTipHighlight.style.top = (params[1]-3)+'px';
            helpTipHighlight.style.width = params[2]+'px';
            helpTipHighlight.style.height = params[3]+'px';
        var text = document.getElementById('helpTipText');
            //text.style.left = ((params[0]+params[2])/2)+'px';
            text.innerHTML = txt;
            text.style.top = (params[1]+params[3]+25)+'px';
        var dWidth = document.body.offsetWidth;

        if(params[2] > dWidth/3*2){
            helpTipHighlight.className = 'center';
        }else if(params[0] < dWidth/2){
            helpTipHighlight.className = 'left';
        }else helpTipHighlight.className = 'right';    

        var helpTip = document.getElementById('helpTip');

        if(callback){
            helpTip.removeEventListener('tap', HelpTip.callback);
            HelpTip.callback = callback;
            helpTip.addEventListener('tap', HelpTip.callback);
        }

        helpTip.style.display = 'block';
    },
    close: function(){
        document.getElementById('helpTip').style.display = 'none';
    }
}
// ---------------------------------------------------------------------------------------------------------------------------------
var Calendar = {
    cDate: null,
    calendar : null,
    title : null,

    init: function(){
        this.calendar = document.getElementById('cal');
        this.title = document.getElementById('calTitle');
        this.cDate = new Date();

        new Tap(this.calendar);
        this.calendar.addEventListener('tap', Calendar.sel);
        this.calendar.addEventListener('swipe', Calendar.swipe);

        new Tap('calPrev').addEventListener('tap', Calendar.nav);
        new Tap('calNext').addEventListener('tap', Calendar.nav);

        new Tap(this.title);
        this.title.addEventListener('tap', function(e){
            e.preventDefault();
            e.stopPropagation();
            Calendar.cDate = new Date();
            Calendar.fill();
        });

        //this.fill();
    },
    fill: function(){
        var dayofmonth = (32 - new Date(Calendar.cDate.getFullYear(), Calendar.cDate.getMonth(), 32).getDate());
        var day_count = 1;
        var week = [[],[],[],[],[],[]];
        // First week
        var num = 0;
        for(var i = 0; i < 7; i++){
            var dayofweek = new Date(Calendar.cDate.getFullYear(), Calendar.cDate.getMonth(), day_count).getDay();
            dayofweek = dayofweek - 1;
            if(dayofweek == -1) dayofweek = 6;
            if(dayofweek == i){
                week[num][i] = day_count;
                day_count++;
            }else week[num][i] = '';
        }
        // Next weeks
        while(true){
            num++;
            for(var j = 0; j < 7; j++){
                week[num][j] = day_count;
                day_count ++;
                if(day_count > dayofmonth) break;
            }
            if(day_count > dayofmonth) break;
        }
        var cY = this.cDate.getFullYear(),
            cM = this.cDate.getMonth(),
            cD = this.cDate.getDate(),
            day = this.cDate.getDay();
        var now = new Date();
        var nY = now.getFullYear(),
            nM = now.getMonth(),
            nD = now.getDate();

        var wLen = week.length;
        //var cnt = '<tr><th>'+fDates[LN].daysShort[1]+'</th><th>'+fDates[LN].daysShort[2]+'</th><th>'+fDates[LN].daysShort[3]+'</th><th>'+fDates[LN].daysShort[4]+'</th><th>'+fDates[LN].daysShort[5]+'</th><th>'+fDates[LN].daysShort[6]+'</th><th>'+fDates[LN].daysShort[0]+'</th></tr>';
        var cnt = '';
        for(var k = 0; k < wLen; k++){
            cnt += '<tr>';
            for(var l = 0; l < 7; l++){
                var dt = new Date(cY+'/'+(cM+1)+'/'+week[k][l]);
                var classes = [];
                if(l == 5 || l == 6) classes.push('weekend');
                
                if(nD+' '+nM+' '+nY == week[k][l]+' '+cM+' '+cY) classes.push('today');
                
                if(cD+' '+cM+' '+cY == week[k][l]+' '+cM+' '+cY) classes.push('active');

                if(dt < Data.mDate || dt > Data.bDate) classes.push('disabled');

                if(Data.mDate.getFullYear()+' '+Data.mDate.getMonth()+' '+Data.mDate.getDate() == cY+' '+cM+' '+week[k][l]) classes.push('startEnd');
                if(Data.bDate.getFullYear()+' '+Data.bDate.getMonth()+' '+Data.bDate.getDate() == cY+' '+cM+' '+week[k][l]) classes.push('startEnd');

                //if(localStorage.getItem('MTB_note_'+cY+'/'+zero(cM+1)+'/'+zero(week[k][l])) || localStorage.getItem('MTB_symptom_'+cY+'/'+zero(cM+1)+'/'+zero(week[k][l])) || localStorage.getItem('MTB_mood_'+cY+'/'+zero(cM+1)+'/'+zero(week[k][l]))) classes.push('has');

                if(localStorage.getItem('MTB_note_'+cY+'/'+zero(cM+1)+'/'+zero(week[k][l]))) classes.push('hasNote');

                if(localStorage.getItem('MTB_mood_'+cY+'/'+zero(cM+1)+'/'+zero(week[k][l]))) classes.push('hasMood');
                if(localStorage.getItem('MTB_symptom_'+cY+'/'+zero(cM+1)+'/'+zero(week[k][l]))) classes.push('hasSymptom');
                
                if(week[k][l] != '' && week[k][l] !== undefined){
                    cnt += '<td class="itm '+classes.join(' ')+'"><div>'+week[k][l]+'</div></td>';
                }else{
                    //if(k > 1) break;
                    cnt += '<td>&nbsp;</td>';
                    //cnt += '<td '+classes.join(' ')+'>'+k+'</td>';
                }
            }
            cnt += '</tr>';
        }
        this.calendar.innerHTML = cnt;
        this.title.innerText = fDates[LN].months[this.cDate.getMonth()] + ' ' + this.cDate.getFullYear();

        this.refreshData(cY+'/'+zero(cM+1)+'/'+zero(cD));
    },
    sel: function(e){
        e.preventDefault();
        e.stopPropagation();
        if(e.currentTarget == e.target) return false;
        var obj = e.target;
        while(obj != Calendar.calendar){
            if(obj.classList.contains('itm')){
                var dt = obj.innerText.trim();
                if(dt == ''/* || obj.classList.contains('disabled') */){ break; return false; }
                Calendar.cDate.setDate(dt*1);
                var compDate = Calendar.cDate.getFullYear()+'/'+zero(Calendar.cDate.getMonth()+1)+'/'+zero(Calendar.cDate.getDate());

                if(Calendar.calendar.getElementsByClassName('active')[0]) Calendar.calendar.getElementsByClassName('active')[0].classList.remove('active');
                obj.classList.add('active');
                Calendar.refreshData(compDate);
                break;
            }
            obj = obj.parentNode;
        }
    },
    nav: function(e){
        e.preventDefault();
        e.stopPropagation();
        var next = (this.id == 'calNext') ? true : false;
            
        if(next){
            var dayofmonth = (32 - new Date(Calendar.cDate.getFullYear(), Calendar.cDate.getMonth(), 32).getDate());
            Calendar.cDate.setMonth(Calendar.cDate.getMonth()+1);
        }else{
            Calendar.cDate.setMonth(Calendar.cDate.getMonth()-1);
        }
        Calendar.cDate.setDate(1);
        Calendar.fill();
    },
    swipe: function(e){
        if(e.detail.direction == 'left'){
            e.preventDefault();
            e.stopPropagation();
            var dayofmonth = (32 - new Date(Calendar.cDate.getFullYear(), Calendar.cDate.getMonth(), 32).getDate());
            Calendar.cDate.setMonth(Calendar.cDate.getMonth()+1);
            Calendar.cDate.setDate(1);
            Calendar.fill();
        }else if(e.detail.direction == 'right'){
            e.preventDefault();
            e.stopPropagation();
            Calendar.cDate.setMonth(Calendar.cDate.getMonth()-1);
            Calendar.cDate.setDate(1);
            Calendar.fill();
        }
    },
    refreshData: function(df){
        var calMood = document.getElementById('calMood');
        var calSymptom = document.getElementById('calSymptom');
        var calNote = document.getElementById('calNote');

        if(localStorage.getItem('MTB_note_'+df)){
            var data = JSON.parse(localStorage['MTB_note_'+df]);
            calNote.innerHTML = data.text;
            if(data.notification){
                document.getElementById('noteLabel').classList.add('bell');
            }else{
                document.getElementById('noteLabel').classList.remove('bell');
            }
        }else{
            document.getElementById('noteLabel').classList.remove('bell');
            calNote.innerHTML = '';
        }

        var cnt = '';
        if(localStorage.getItem('MTB_mood_'+df)){
            var data = JSON.parse(localStorage['MTB_mood_'+df]);

            var dLen = data.length;

            for(var i = 0; i < dLen; i++){
                cnt += '<div class="itm" data-val="'+i+'|'+data[i][1]+'"><img src="img/moods/'+data[i][1]+'.png" /><br />'+data[i][0]+'</div>';
            }

            document.getElementById('delMoods').style.display = 'table-cell';
        }else document.getElementById('delMoods').style.display = 'none';
            
        calMood.innerHTML = cnt+'<div class="itm add" data-val="add"><img src="img/addmood.png" /></div>';

        cnt = '';
        if(localStorage.getItem('MTB_symptom_'+df)){
            var data = JSON.parse(localStorage['MTB_symptom_'+df]);

            var dLen = data.length;

            for(var i = 0; i < dLen; i++){
                cnt += '<div class="itm" data-val="'+i+'|'+data[i][1]+'"><img src="img/symptoms/'+data[i][1]+'.png" /><br />'+data[i][0]+'</div>';
            }

            document.getElementById('delSymptoms').style.display = 'table-cell';
        }else document.getElementById('delSymptoms').style.display = 'none';

        calSymptom.innerHTML = cnt+'<div class="itm add" data-val="add"><img src="img/addsymptom.png" /></div>';
    }
}
// ---------------------------------------------------------------------------------------------------------------------------------
var Data = {
    mDate: null,
    bDate: null,
    cWeek: null,

    get: function(){
        if(!localStorage.getItem('MTB_m_date')) return false;

        var MTB_m_date = localStorage.getItem('MTB_m_date');
        var df = MTB_m_date.split('|');
        
        var dt = new Date(df[1]);
        var now = new Date();
            now.setHours(0);
            now.setMinutes(0);

        if(df[0] == 0){
            var dm = dt;
            var db = new Date(dm);
                db.setDate(dm.getDate()+280);
        }else{
            var db = dt;
            var dm = new Date(db);
                dm.setDate(db.getDate()-280);
        }
        
        // Data params
        Data.mDate = dm;
        Data.bDate = db;

        Data.mDate.setHours(0);
        Data.mDate.setMinutes(0);
        Data.bDate.setHours(0);
        Data.bDate.setMinutes(0);

        var pass = diff(Data.mDate, new Date());
        Data.cWeek = (pass.fullWeeks >= 40) ? 40 : pass.fullWeeks;

        Data.weekStart = new Date(Data.mDate);
            Data.weekStart.setDate(Data.weekStart.getDate() + (Data.cWeek-1)*7);
        Data.weekEnd = new Date(Data.weekStart);
            Data.weekEnd.setDate(Data.weekStart.getDate() + 6);

        var alreadyBirth = (now >= Data.bDate) ? true : false;

        var prImg = (alreadyBirth) ? 10 : Math.ceil(Data.cWeek*9/40);

        document.getElementById('progress').style.backgroundImage = 'url(img/weeks/'+prImg+'.png)';
        document.getElementById('pass').innerHTML = (now <= Data.mDate) ? '' : '<span>'+_w.pass[LN]+': </span>'+pass.text;
        document.getElementById('left').innerHTML = alreadyBirth ? '<span>'+_w.age[LN]+': </span>'+diff(Data.bDate, now).text : '<span>'+_w.left[LN]+': </span>'+diff(now, Data.bDate).text;
        document.getElementById('birthDate').innerHTML = '<span>'+_w.birthDate[LN]+': </span>'+zero(Data.bDate.getDate())+' '+fDates[LN].monthsShort[Data.bDate.getMonth()]+' '+Data.bDate.getFullYear();

        if(!alreadyBirth){
            getWeekInfo(function(res){
                var weekContent = res.split('\r\n');
                document.getElementById('info').innerHTML = '<h2 class="tac"><img src="img/weeks/'+prImg+'.png" /><br />'+Data.cWeek+' '+_w.nedelya[LN]+'</h2><h3 class="tac">'+zero(Data.weekStart.getDate())+' '+fDates[LN].monthsShort[Data.weekStart.getMonth()]+' '+Data.weekStart.getFullYear()+' - '+zero(Data.weekEnd.getDate())+' '+fDates[LN].monthsShort[Data.weekEnd.getMonth()]+' '+Data.weekEnd.getFullYear()+'</h3><div class="text pad">'+weekContent[Data.cWeek-1]+'</div>';
                localStorage.setItem('kWatchFirstOneLineLabel', Data.cWeek+' '+_w.nedelya[LN]);     // WATCH
            });
        }else{
            document.getElementById('info').innerHTML = '<h2 class="tac"><img src="img/weeks/'+prImg+'.png" /></h2><h2 class="tac">'+_w.age[LN]+':</h2><h3 class="tac">'+diff(Data.bDate, now).text+'</h3>';
            localStorage.removeItem('kWatchFirstOneLineLabel');     // WATCH
        }

        localStorage.setItem('kWatchSecondOneLineLabel', zero(Data.bDate.getDate())+' '+fDates[LN].monthsShort[Data.bDate.getMonth()]+' '+Data.bDate.getFullYear());     // WATCH
        
        var watchThree = alreadyBirth ? _w.age[LN]+'\n'+diff(Data.bDate, now).text : _w.left[LN]+'\n'+diff(now, Data.bDate).text;

        localStorage.setItem('kWatchWideLabel', watchThree);     // WATCH

        localStorage.setItem('kWatchImageView', 'img/weeks/'+prImg+'.png');
        

        return true;
    },

    save: function(){
        var error = false;

        var dateActive = fdtDate.getDate();

        var now = new Date();
        
        var dateType = document.getElementById('dateType');
        var dateTypeActive = dateType.getElementsByClassName('active')[0].dataset.val;

        if(dateTypeActive == 0){
            var dm = dateActive.dateTime;
            var db = new Date(dm);
                db.setDate(dm.getDate()+280);
        }else{
            var db = dateActive.dateTime;
            var dm = new Date(db);
                dm.setDate(db.getDate()-280);
        }

        var firstWeight = document.getElementById('iFirstWeight');
        if(firstWeight.value.trim() == '' || isNaN(firstWeight.value) || firstWeight.value <= 40 || firstWeight.value >= 600){
            error = true;
            firstWeight.style.backgroundColor = 'rgba(229,68,163,.2)';
            setTimeout(function(){
                firstWeight.style.backgroundColor = '';
                firstWeight.focus();
            }, 700);
        }

        if(!error){
            document.getElementById('save').getElementsByTagName('img')[0].src = 'img/ajaxloader.gif';
            localStorage.setItem('MTB_m_date', dateTypeActive+'|'+dateActive.text);
            
            var wDt = dm.getFullYear()+'/'+zero(dm.getMonth()+1)+'/'+zero(dm.getDate());
            localStorage.setItem('MTB_start_weight', wDt);
            var weights = (localStorage.getItem('MTB_weight')) ? JSON.parse(localStorage['MTB_weight']) : [];
                
            var stIndex = weights.map(function (element) {return element[0];}).indexOf(localStorage.getItem('MTB_start_weight'));
                
            if(stIndex == -1){
                weights.push([wDt, firstWeight.value*1]);
            }else{
                weights[stIndex] = [wDt, firstWeight.value*1];
            }
            weights.sort(sortByFirst);
            localStorage['MTB_weight'] = JSON.stringify(weights);

            Data.setNotifications(function(){
                document.getElementById('save').getElementsByTagName('img')[0].src = 'img/save.png';
                Page.open('index');
            });

            Data.get();
            return true;
        }else return false;
    },
    setNotifications: function(callback){
        getWeekInfo(function(res){
            var weekContent = res.split('\r\n');
            var now = new Date();

            var dateTypeActive = localStorage['MTB_m_date'].split('|');

            if(dateTypeActive[0] == 0){
                var dm = new Date(dateTypeActive[1]);
                var db = new Date(dm);
                    db.setDate(dm.getDate()+280);
            }else{
                var db = new Date(dateTypeActive[1]);
                var dm = new Date(db);
                    dm.setDate(db.getDate()-280);
            }

            var everyWeek = new Date(dm.getTime());
                everyWeek.setHours(12);
                everyWeek.setMinutes(00);
            for(var i = 1; i <= 40; i++){
                var nIndex = 1000000000+i;
                JSAPI.cancelNotif(nIndex);

                if(everyWeek > now){
                    var text = weekContent[i-1].substring(0, 30)+'...';
                    JSAPI.createUnitNotif(0, everyWeek.getTime(), nIndex, _w.isbegin[LN]+' '+i+' '+_w.nedelya[LN],  _w.isbegin[LN]+' '+i+' '+_w.nedelya[LN]+'. '+text,  _w.isbegin[LN]+' '+i+' '+_w.nedelya[LN]+'. '+text, 2000, 'notification.mp3');
                }

                everyWeek.setDate(everyWeek.getDate()+7);
                if(i == 40){
                    if(callback) setTimeout(function(){ callback(); }, 500);
                }
            }

            if(Data.bDate > now){
                JSAPI.createUnitNotif(0, Data.bDate.getTime(), 1000000041, _w.comingSoon[LN]+'!', _w.comingSoon[LN]+'!', _w.comingSoon[LN]+'!', 2000, 'notification.mp3');
            }
        });
    },
    note: {
        add: function(){
            var dt = Calendar.cDate.getFullYear()+'/'+zero(Calendar.cDate.getMonth()+1)+'/'+zero(Calendar.cDate.getDate());

            var dNotif = (fdtNotification) ? fdtNotification.getDate().dateTime : new Date();

            var text = document.getElementById('noteText');
            var notification = document.getElementById('radioNotification').classList.contains('active');

            if(text.value.trim() == ''){
                text.style.backgroundColor = 'rgba(255,0,0,.06)';
                setTimeout(function(){
                    text.style.backgroundColor = '';
                    text.focus();
                }, 600);
                //localStorage.removeItem('MTB_note_'+dt);
                //Data.note.notification(dt);
                return false;
            }else{
                var saveData = {notification: notification, timeStamp: dNotif.getTime(), text: text.value};
                localStorage['MTB_note_'+dt] = JSON.stringify(saveData);
                Data.note.notification(dt, saveData);
                return true;
            }
        },
        notification: function(dt, data){
            data = data || false;
            var notifA = (localStorage.getItem('MTB_notif')) ? JSON.parse(localStorage['MTB_notif']) : [];
            var nIndex = notifA.indexOf(dt);

            if(data && data.notification && (new Date() < new Date(data.timeStamp))){
                var text = data.text.substring(0, 20)+'...';

                if(nIndex === -1){
                    notifA.push(dt);
                    nIndex = notifA.length-1;
                }

                JSAPI.createUnitNotif(0, data.timeStamp, nIndex, _w.index[LN], text, text, 2000, 'notification.mp3');
            }else{
                if(nIndex !== -1){
                    JSAPI.cancelNotif(nIndex);
                    notifA[nIndex] = '';
                }
            }

            localStorage.setItem('MTB_notif', JSON.stringify(notifA));
        },
        refreshList: function(){
            var len = localStorage.length;
            var dates = [];
            for(i = 0; i < len; i++){
                if(localStorage.key(i).substring(0, 9) == 'MTB_note_') dates.push(localStorage.key(i).substring(9));
            }
            dates.sort();

            var now = new Date(),
                nowF = now.getFullYear()+'/'+zero(now.getMonth()+1)+'/'+zero(now.getDate());

            var list = '<table>';
            for(var i = dates.length; --i >= 0;){
                dt = dates[i].split('/');
                df = dt[2]+' '+fDates[LN].monthsShort[dt[1]*1-1]+' '+dt[0];
                var note = JSON.parse(localStorage['MTB_note_'+dates[i]]);

                var nImg = (note.notification) ? '<img class="bell" src="img/bell.png" />' : '';
                var text = (note.text.length > 40) ? note.text.substring(0, 40)+'...' : note.text;

                var states = '';
                if(localStorage.getItem('MTB_symptom_'+dates[i])){
                    var symptoms = JSON.parse(localStorage['MTB_symptom_'+dates[i]]);
                    for(var j = symptoms.length; --j >= 0;){
                        states = '<img src="img/symptoms/'+symptoms[j][1]+'.png" />'+states;
                    }
                }
                if(localStorage.getItem('MTB_mood_'+dates[i])){
                    var moods = JSON.parse(localStorage['MTB_mood_'+dates[i]]);
                    for(var j = moods.length; --j >= 0;){
                        states = '<img src="img/moods/'+moods[j][1]+'.png" />'+states;
                    }
                }

                var today = (nowF == dates[i]) ? ' today' : '';

                list += '<tr class="itm" data-val="'+dates[i]+'"><td><p class="label'+today+'">'+df+nImg+'</p><div class="text">'+text+'</div><div class="state">'+states+'</div></td><td class="del"></td></tr>';
            }
            document.getElementById('notes').innerHTML = (dates.length > 0) ? list+'</table>' : '<h2 class="tac nodata">'+_w.noData[LN]+'</h2><div class="add button">'+_w.add[LN]+'</div>';
        },
        del: function(dt){
            localStorage.removeItem('MTB_note_'+dt);
            Data.note.notification(dt);
            if(Page.current == 'notes') this.refreshList();
        },
        refreshNote: function(){
            var dt = Calendar.cDate.getFullYear()+'/'+zero(Calendar.cDate.getMonth()+1)+'/'+zero(Calendar.cDate.getDate());

            var note = JSON.parse(localStorage.getItem('MTB_note_'+dt));

            var bell = '';
            if(note.notification){
                var nD = new Date(note.timeStamp);
                bell = '<p class="bell"><img src="img/bell.png" />'+fDates[LN].daysShort[Calendar.cDate.getDay()]+', '+nD.getDate()+' '+fDates[LN].monthsShort[nD.getMonth()]+' '+nD.getFullYear()+' '+zero(nD.getHours())+':'+zero(nD.getMinutes())+'</p>';
            }
            var states = '';
            if(localStorage.getItem('MTB_symptom_'+dt)){
                var symptoms = JSON.parse(localStorage['MTB_symptom_'+dt]);
                for(var j = symptoms.length; --j >= 0;){
                    states = '<img class="itm" data-val="symptom|'+j+'|'+symptoms[j][1]+'|'+symptoms[j][0]+'" src="img/symptoms/'+symptoms[j][1]+'.png" />'+states;
                }
            }
            if(localStorage.getItem('MTB_mood_'+dt)){
                var moods = JSON.parse(localStorage['MTB_mood_'+dt]);
                for(var j = moods.length; --j >= 0;){
                    states = '<img class="itm" data-val="mood|'+j+'|'+moods[j][1]+'|'+moods[j][0]+'" src="img/moods/'+moods[j][1]+'.png" />'+states;
                }
            }
            document.getElementById('viewNote').innerHTML = '<h3 class="tac">'+fDates[LN].daysShort[Calendar.cDate.getDay()]+', '+Calendar.cDate.getDate()+' '+fDates[LN].monthsShort[Calendar.cDate.getMonth()]+' '+Calendar.cDate.getFullYear()+'</h3>'+bell+'<div class="states">'+states+'</div><p class="label">'+_w.addNote[LN]+':</p><div class="text">'+note.text+'</div>';
        }
    },
    state: {
        add: function(type, md){
            var dt = Calendar.cDate.getFullYear()+'/'+zero(Calendar.cDate.getMonth()+1)+'/'+zero(Calendar.cDate.getDate());

            var now = new Date();
            var nt = now.getFullYear()+'/'+zero(now.getMonth()+1)+'/'+zero(now.getDate());

            var time = (dt == nt) ? zero(now.getHours())+':'+zero(now.getMinutes()) : '--:--';

            var data = (localStorage.getItem('MTB_'+type+'_'+dt)) ? JSON.parse(localStorage['MTB_'+type+'_'+dt]) : [];

            data.push([time, md]);

            data.sort(sortByFirst);

            localStorage['MTB_'+type+'_'+dt] = JSON.stringify(data);

            Calendar.fill();

            return true;
        },
        delAll: function(type){
            var dt = Calendar.cDate.getFullYear()+'/'+zero(Calendar.cDate.getMonth()+1)+'/'+zero(Calendar.cDate.getDate());
            localStorage.removeItem('MTB_'+type+'_'+dt);
            Calendar.fill();

            return true;
        },
        del: function(type, index){
            var dt = Calendar.cDate.getFullYear()+'/'+zero(Calendar.cDate.getMonth()+1)+'/'+zero(Calendar.cDate.getDate());
            var data = JSON.parse(localStorage.getItem('MTB_'+type+'_'+dt));

            data.splice(index, 1);

            if(data.length == 0){
                localStorage.removeItem('MTB_'+type+'_'+dt);
            }else{
                localStorage.setItem('MTB_'+type+'_'+dt, JSON.stringify(data));
            }
            return true;
        }
    },
    weight: {
        add: function(){
            var data = (localStorage.getItem('MTB_weight')) ? JSON.parse(localStorage['MTB_weight']) : [];
            var dt = fdtWeight.getDate().text;
            var val = document.getElementById('iAddWeight');

            var vl = val.value.replace(',', '.');

            if(vl != undefined && vl != '' && !isNaN(vl) && vl >= 40 && vl <= 600){

                var stIndex = data.map(function (element) {return element[0];}).indexOf(dt);
                    
                if(stIndex == -1){
                    data.push([dt, vl*1]);
                }else{
                    data[stIndex] = [dt, vl*1];
                }
                data.sort(sortByFirst);
                localStorage['MTB_weight'] = JSON.stringify(data);
                return true;
            }else{
                val.style.backgroundColor = 'rgba(229,68,163,.2)';
                setTimeout(function(){
                    val.style.backgroundColor = '';
                    val.focus();
                }, 700);
                return false;
            }
        },
        del: function(id){
            var data = (localStorage.getItem('MTB_weight')) ? JSON.parse(localStorage['MTB_weight']) : [];

            if(data.length == 0) return;

            data.splice(id, 1);
            
            localStorage.setItem('MTB_weight', JSON.stringify(data));

            Data.weight.refreshList();
            return true;
        },
        refreshList: function(){
            var dt = Calendar.cDate.getFullYear()+'/'+zero(Calendar.cDate.getMonth()+1)+'/'+zero(Calendar.cDate.getDate());
            var data = (localStorage.getItem('MTB_weight')) ? JSON.parse(localStorage['MTB_weight']) : [];
            var startWeight = localStorage.getItem('MTB_start_weight');
            var weightTypeActive = document.getElementById('weightType').getElementsByClassName('active')[0].dataset.val;
            var cnt = '';

            document.getElementById('weightWrap').style.display = (weightTypeActive == 0) ? 'block' : 'none';

            var dtspl, df, add, wDiff, dates;
            var chartLabels = [],
                chartData = [];
            
            var mnthSpl = data[0][0].split('/');
            var summ = 0,
                count = 0;
            
            for(var i = 0, len = data.length; i < len; i++){
                dtspl = data[i][0].split('/');
                df = dtspl[2]+' '+fDates[LN].monthsShort[dtspl[1]*1-1]+' '+dtspl[0];

                add = true;
                if(weightTypeActive == 0){
                    if(dtspl[0]+'/'+dtspl[1] != dt.split('/')[0]+'/'+dt.split('/')[1]){
                        add = false;
                    }else{
                        // add chart data by days
                        chartLabels.push(dtspl[2]+'/'+dtspl[1]);
                        chartData.push(data[i][1]);
                    }
                }else{
                    // add chart data by months avg weight
                    
                    if(mnthSpl[0]+'/'+mnthSpl[1] === dtspl[0]+'/'+dtspl[1]){
                        summ += data[i][1];
                        count++;
                    }else{
                        chartLabels.push(fDates[LN].monthsShort[mnthSpl[1]*1-1]);
                        chartData.push(summ/count);

                        mnthSpl = data[i][0].split('/');
                        summ = data[i][1];
                        count = 1;
                    }
                    if(i == len-1){
                        chartLabels.push(fDates[LN].monthsShort[mnthSpl[1]*1-1]);
                        chartData.push(summ/count);
                    }
                }

                if(add){
                    wDiff = (data[i-1]) ? (data[i][1]-data[i-1][1]) : ' ';
                    if(wDiff > 0){
                        wDiff = ' (+'+(wDiff.toFixed(2)*1)+') ';
                    }else{
                        if(wDiff !== ' ') wDiff = ' ('+(wDiff.toFixed(2)*1)+') ';
                    }

                    var del = (startWeight != data[i][0]) ? '<td class="del"></td>' : ''; 
                    var colspan = (del != '') ? '' : 'colspan="2"';

                    cnt = '<tr class="itm" data-val="'+i+'"><td '+colspan+'>'+data[i][1]+_w.kg[LN]+wDiff+'<span class="light">'+df+'</span></td>'+del+'</tr>'+cnt;
                }
            }
            document.getElementById('weightTitle').innerText = fDates[LN].months[Calendar.cDate.getMonth()] + ' ' + Calendar.cDate.getFullYear();
            document.getElementById('weightList').innerHTML = (cnt == '') ? '<div class="tac nodata">'+_w.noData[LN]+'</div><div class="add button">'+_w.add[LN]+'</div>' : '<table>'+cnt+'</table>';

            // // Graph

            if(chartData.length > 0){
                document.getElementById('chartWrap').style.display = 'block';
                wData = {
                    datasets: [
                        {
                            label: "--",
                            fillColor: "rgba(220,220,220,0)",
                            strokeColor: "#F66120",
                            pointColor: "#F66120",
                            pointStrokeColor: "#fff",
                            pointHighlightFill: "#fff",
                            pointHighlightStroke: "#F66120",
                            data: chartData
                        }
                    ]
                };
                //wData.labels = (labels.length > 1) ? labels : wData.labels = [labels[0] ,''];
                wData.labels = chartLabels;

                var ctxW = document.getElementById("weightChart").getContext("2d");

                if(wChart) wChart.destroy();
                setTimeout(function(){
                    wChart = new Chart(ctxW).Line(wData, { responsive: true, maintainAspectRatio: true, scaleGridLineColor: "rgba(229,204,255,.1)", scaleLineColor: "rgba(229,204,255,.3)", scaleFontColor: "#333" });
                }, 50);
            }else{
                document.getElementById('chartWrap').style.display = 'none';
                if(wChart) wChart.destroy();
            }
        },
        nav: function(e){
            e.preventDefault();
            e.stopPropagation();
            var next = (this.id == 'weightNext') ? true : false;
            //var testDate = new Date(Calendar.cDate);
                
            if(next){
                var dayofmonth = (32 - new Date(Calendar.cDate.getFullYear(), Calendar.cDate.getMonth(), 32).getDate());
                //testDate.setDate(dayofmonth);
                //if(testDate > Data.bDate) return;
                Calendar.cDate.setMonth(Calendar.cDate.getMonth()+1);
            }else{
                //testDate.setDate(1);
                //if(testDate < Data.mDate) return;
                Calendar.cDate.setMonth(Calendar.cDate.getMonth()-1);
            }
            Calendar.cDate.setDate(1);
            Data.weight.refreshList();
        }
    },
    photo: {
        refreshList: function(){
            var photos = (localStorage.getItem('MTB_photos')) ? JSON.parse(localStorage.getItem('MTB_photos')) : [];
            var html = '';

            for(var i = 0, pLen = photos.length; i < pLen; i++){
                var dt = new Date(photos[i][0]);
                var df = zero(dt.getDate())+'/'+zero(dt.getMonth()+1)+'/'+dt.getFullYear();
                html += '<div class="itm" data-val="'+i+'" style="background-image: url(\''+photos[i][1]+'\');"><div>'+df+'</div></div>';
            }

            document.getElementById('photoList').innerHTML = (html != '') ? html : '<h2 class="tac nodata">'+_w.noPhoto[LN]+'</h2><div class="add button">'+_w.add[LN]+'</div>';
        },
        add: function(url){
            var photos = (localStorage.getItem('MTB_photos')) ? JSON.parse(localStorage.getItem('MTB_photos')) : [];
            photos.push([new Date().getTime(), url]);
            localStorage.setItem('MTB_photos', JSON.stringify(photos));
            Data.photo.refreshList();
            return true;
        },
        del: function(id){
            var photos = (localStorage.getItem('MTB_photos')) ? JSON.parse(localStorage.getItem('MTB_photos')) : [];
            
            if(photos.length == 0) return false;

            photos.splice(id, 1);

            localStorage.setItem('MTB_photos', JSON.stringify(photos));
            Data.photo.refreshList();
            return true;
        }
    }
}
// ---------------------------------------------------------------------------------------------------------------------------------

document.addEventListener('DOMContentLoaded', function(){
    Calendar.init();
    Dialog.init();
    SelectMood.init();
    SelectSymptom.init();
    PhotoPopup.init();
    PhotoSelect.init();
// Everyday notifications
// ---------------------------------------------------------------------------------------------------------------------------------
var now = new Date();
var aftertomorrow = new Date();
    aftertomorrow.setDate(now.getDate()+2);
JSAPI.createUnitNotif(0, aftertomorrow.getTime(), 2000000000, _w.index[LN], _w.seeThePeriod[LN], _w.seeThePeriod[LN], 2000, 'notification.mp3');
// ---------------------------------------------------------------------------------------------------------------------------------
    if(platform == 'ios') document.getElementById('share').style.display = 'block';
// Tutorial
// ---------------------------------------------------------------------------------------------------------------------------------
    var tutorialSwiper = new Swiper('#tutorialSwiper', {
        pagination: '.swiper-pagination',
        paginationClickable: true,
        paginationBulletRender: function (index, className) {
            return '<span class="' + className + '">' + (index + 1) + '</span>';
        }
    });

    setTimeout(function(){ document.getElementById('tutorial').style.display = (localStorage.getItem('MTB_notutorial')) ? 'none' : 'block'; }, 300);

    new Tap('start').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        document.getElementById('tutorial').style.display = 'none';
        localStorage.setItem('MTB_notutorial', 'true');
    });
// ---------------------------------------------------------------------------------------------------------------------------------
    var data = Data.get();
    Page.init('index');
    if(!data){
        HelpTip.show('settingsB', _w.enterData[LN], function(e){
            Page.open('settings', true);
            e.preventDefault();
            e.stopPropagation();
            HelpTip.close();
        });
    }
// ---------------------------------------------------------------------------------------------------------------------------------
    // Save
    new Tap('save').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        switch(Page.current){
            case 'settings':
                Data.save();
            break;
            case 'addWeight':
                if(Data.weight.add()) Page.back();
            break;
            case 'addNote':
                if(Data.note.add()){
                    Page.back();
                }
            break;
        }
    });

    new Tap('back').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        Page.back();
    });

    new Tap('dateType').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        if(e.currentTarget === e.target) return;
        this.getElementsByClassName('active')[0].classList.remove('active');
        e.target.classList.add('active');
    });

    new Tap('weightType').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        if(e.currentTarget === e.target) return;
        if(!e.target.classList.contains('active')){
            this.getElementsByClassName('active')[0].classList.remove('active');
            e.target.classList.add('active');
            Data.weight.refreshList();
        }
    });

    new Tap('weightPrev').addEventListener('tap', Data.weight.nav);
    new Tap('weightNext').addEventListener('tap', Data.weight.nav);
    new Tap('weightTitle').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        Calendar.cDate = new Date();
        Data.weight.refreshList();
    });

    new Tap('openTutorial').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        tutorialSwiper.slideTo(0, 0);
        document.getElementById('tutorial').style.display = 'block';
    });

    new Tap('add').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        switch(Page.current){
            case 'notes':
                Calendar.cDate = new Date();
                Page.open('addNote');
            break;
            case 'weight':
                Page.open('addWeight');
            break;
            case 'photo':
                PhotoSelect.show();
            break;
        }
    });

    document.getElementById('progress').style.height = progress.offsetWidth+'px';

    var notifCalEl = document.getElementById('fdtNotification')
    new Tap('radioNotification').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        if(e.currentTarget.classList.contains('active')){
            this.classList.remove('active');
            notifCalEl.style.display = 'none';
        }else{
            this.classList.add('active');
            notifCalEl.style.display = 'block';
            if(!fdtNotification) fdtNotification = new Fdt('fdtNotification', {mode: 'dateTime', startDate: new Date()}); else fdtNotification.setDate(Calendar.cDate);
        }
    });

    new Tap('noteDate').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        if(!e.target.classList.contains('del')) return;
        Dialog.show(_w.delNote[LN], _w.del[LN], function(){
            var dt = Calendar.cDate.getFullYear()+'/'+zero(Calendar.cDate.getMonth()+1)+'/'+zero(Calendar.cDate.getDate());
            Data.note.del(dt);
            if(Page.prev[Page.prev.length-2] == 'viewNote') Page.prev.splice(Page.prev.length-1, 1);
            Page.back();
        });
    });

    new Tap('calNote').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        if(this.innerHTML.trim() == '') return;
        Page.open('viewNote');
    });

    new Tap('notes', 'itm').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();

        if(e.target == e.currentTarget) return;
        if(!e.detail.cTarget.classList.contains('itm')){
            if(e.target.classList.contains('add')){
                Calendar.cDate = new Date();
                Page.open('addNote');
            }
            return;
        }
        
        var dt = e.detail.cTarget.dataset.val;
        if(e.target.classList.contains('del')){
            Dialog.show(_w.delNote[LN], _w.del[LN], function(){
                Data.note.del(dt);
            });
        }else{
            Calendar.cDate = new Date(dt);
            Page.open('viewNote');
        }
    });

    new Tap('weightList', 'itm').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        
        var id = e.detail.cTarget.dataset.val;
        if(e.target.classList.contains('del')){
            Dialog.show(_w.del[LN]+'?', _w.del[LN], function(){
                Data.weight.del(id);
            });
        }

        if(e.target.classList.contains('add')){
            Page.open('addWeight');
        }
    });

    new Tap('calMood', 'itm').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();

        if(e.target == e.currentTarget) return;

        var val = e.detail.cTarget.dataset.val;

        if(val == 'add'){
            SelectMood.show(function(selected){
                Data.state.add('mood', selected);
            });
        }else{
            val = val.split('|');

            Dialog.show(_w.moodnames[val[1]][LN]+'<br />'+e.detail.cTarget.innerHTML, _w.del[LN], function(){ 
                Data.state.del('mood', val[0]);
                Calendar.fill();
            });
        }
    });

    new Tap('calSymptom', 'itm').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();

        if(e.target == e.currentTarget) return;

        var val = e.detail.cTarget.dataset.val;

        if(val == 'add'){
            SelectSymptom.show(function(selected){
                Data.state.add('symptom', selected);
            });
        }else{
            val = val.split('|');

            Dialog.show(_w.symptomnames[val[1]][LN]+'<br />'+e.detail.cTarget.innerHTML, _w.del[LN], function(){ 
                Data.state.del('symptom', val[0]);
                Calendar.fill();
            });
        }
    });

    new Tap('delMoods', 'itm').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        
        Dialog.show(_w.delMoods[LN], _w.yes[LN], function(){ Data.state.delAll('mood'); });
    });

    new Tap('delSymptoms', 'itm').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        
        Dialog.show(_w.delSymptoms[LN], _w.yes[LN], function(){ Data.state.delAll('symptom'); });
    });

    new Tap('viewNote', 'itm').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();

        if(e.target == e.currentTarget) return;

        var val = e.detail.cTarget.dataset.val;

        val = val.split('|'); // symptom|'+j+'|'+symptoms[j][1]+'|'+symptoms[j][0]
        
        if(val[0] == 'symptom'){
            var text = _w.symptomnames[val[2]][LN]+'<br /><img src="img/symptoms/'+val[2]+'.png" /><br />'+val[3];
        }else{
            var text = _w.moodnames[val[2]][LN]+'<br /><img src="img/moods/'+val[2]+'.png" /><br />'+val[3];
        }

        Dialog.show(text, _w.del[LN], function(){ 
            Data.state.del(val[0], val[1]);
            Data.note.refreshNote();
        });
    });

    new Tap('lnList', 'itm').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();

        if(e.target == e.currentTarget) return;

        var val = e.detail.cTarget.dataset.val;

        if(val == LN) return;
        Dialog.show(_w.langAlert[LN], _w.ok[LN], function(){
            document.getElementById('lnList').getElementsByClassName('active')[0].classList.remove('active');
            e.detail.cTarget.classList.add('active');

            localStorage['MTB_ln'] = val;
            LN = val;
            Data.setNotifications();
        });
    });

    new Tap('takePhoto').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();

        PhotoSelect.close();

        JSAPI.takePhoto();
    });

    new Tap('choosePhoto').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();

        PhotoSelect.close();

        JSAPI.pickPhoto();
    });

    window.addEventListener('cameraCapturedImageEvent', function(){
        Data.photo.add(getBufferEventVar().path);
        console.log('cameraCapturedImageEvent', getBufferEventVar().path);
    }, false);

    window.addEventListener('pickedImageEvent', function(){
        Data.photo.add(getBufferEventVar().path);
        console.log('pickedImageEvent', getBufferEventVar().path);
    }, false);

    new Tap('photoList', 'itm').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();

        if(e.target == e.currentTarget) return;
        if(!e.detail.cTarget.classList.contains('itm')){
            if(e.target.classList.contains('add')){
                PhotoSelect.show();
            }
            return;
        }

        var val = e.detail.cTarget.dataset.val;
        document.getElementById('delPhoto').dataset.val = val;
        PhotoPopup.show(e.detail.cTarget.style.backgroundImage);
        //console.log('open fullscreen ', e.detail.cTarget.style.backgroundImage);
    });

    new Tap('share').addEventListener('tap', function(e){
        e.preventDefault();
        e.stopPropagation();
        var target = e.target;
        target.src = 'img/ajaxloader.gif';
        //function convertImgToBase64(url, callback){
        var canvas = document.createElement('CANVAS');
        var ctx = canvas.getContext('2d');
        var img = new Image;
        img.crossOrigin = 'Anonymous';
        img.onload = function(){
            canvas.height = img.height;
            canvas.width = img.width;
            ctx.drawImage(img,0,0);
            var dataURL = canvas.toDataURL('image/png');

            var text = '';
            if(new Date() >= Data.bDate){
                text = _w.iMother[LN].replace('XX', document.getElementById('left').innerText.split(':')[1].trim());
            }else{
                if(new Date() <= Data.mDate){
                    text = document.getElementById('birthDate').innerText+'\n'+document.getElementById('left').innerText+'\n'+document.getElementById('info').getElementsByClassName('text')[0].innerText;
                }else{
                    text = _w.iPregnant[LN].replace('XX', Data.cWeek)+'\n'+document.getElementById('birthDate').innerText+'\n'+document.getElementById('left').innerText+'\n'+document.getElementById('info').getElementsByClassName('text')[0].innerText;
                }
            }

            AJAX.search(
                'http://176.9.34.55/mobile_game/returnapps/applinks.php',
                'app=Mother To Be 2&lang='+LN+'&platform='+platform,
                function(){
                    // before
                },
                function(res){
                    // success
                    var links = (res != 'null') ? '\n'+res : '';
                    JSAPI.sharing(text+links, dataURL);
                    canvas = null;
                    target.src = 'img/share.png';
                },
                function(){
                    // error
                    JSAPI.sharing(text, dataURL);
                    canvas = null;
                    target.src = 'img/share.png';
                }
            );
            
        };
        var prImg = Math.ceil(Data.cWeek*9/40);
        img.src = (new Date() >= Data.bDate) ? 'img/weeks/10.png' : 'img/weeks/'+prImg+'.png';
        //}
    });
// ---------------------------------------------------------------------------------------------------------------------------------
    HelpTip.init();
// ---------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------------------------------------------------------------------
    setTimeout(function(){
        // Android
        var title = document.title;
        if(title.indexOf('PRO') != -1 || title.indexOf('pro') != -1 || title.indexOf('INAPP') != -1 || title.indexOf('inapp') != -1){
            BANNER = false;
        }else BANNER = true;
        
        var bannerH = (!BANNER) ? 0 : (document.body.offsetHeight >= document.body.offsetWidth) ? (document.body.offsetWidth*50/320).toFixed() : (document.body.offsetHeight*50/320).toFixed();
        document.getElementById('ptWrap').style.paddingBottom = bannerH+'px';
        document.getElementById('swiperPagination').style.paddingBottom = (bannerH == 0) ? '15px' : bannerH+'px';
    }, 300);
// ---------------------------------------------------------------------------------------------------------------------------------
    var splash = document.getElementById('splash');
    splash.classList.add('loading');
    setTimeout(function(){ splash.style.display = 'none'; }, 2000); // 2000
    JSAPI.keepScreenOn();
// ---------------------------------------------------------------------------------------------------------------------------------
});