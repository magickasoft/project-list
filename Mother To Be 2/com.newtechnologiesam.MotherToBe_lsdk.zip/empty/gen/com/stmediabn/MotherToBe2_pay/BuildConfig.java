/** Automatically generated file. DO NOT MODIFY */
package com.stmediabn.MotherToBe2_pay;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}