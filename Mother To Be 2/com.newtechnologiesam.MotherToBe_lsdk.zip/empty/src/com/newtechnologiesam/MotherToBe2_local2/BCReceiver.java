package com.newtechnologiesam.MotherToBe2_local2;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.PowerManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

import com.am.js.NotificationHelper;
import com.newtechnologiesam.MotherToBe2_local2.R;


//класс перехватывающий броадкасты
public class BCReceiver extends BroadcastReceiver {
	public static final String ALARM_NOTIFICATION_ACTION="alarm_notification"; 

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent.getAction().equals(ALARM_NOTIFICATION_ACTION)) {
   	
        	//запускаем уведомление
        	fireNotification(context,intent.getIntExtra("alarmId", -1),
        			intent.getStringExtra("title"),intent.getStringExtra("text"),
        			intent.getStringExtra("tickerText"),intent.getIntExtra("vibrationTime", 0),
        			intent.getStringExtra("soundPath"));
        }
    }
    
   
	public void fireNotification(Context context,int alarmId,String title,String text, 
			String tickerText,int vibrationTime, String soundPath){
		
		
		
		Log.i("fire notif", "tickerText "+tickerText
				+ "vibrationTime "+vibrationTime+" soundPath "+ soundPath);
		
    	NotificationCompat.Builder mBuilder =
		        new NotificationCompat.Builder(context)
		        .setSmallIcon(R.drawable.app_icon)
		        .setContentTitle(title)
		        .setContentText(text);
    	
    	
    	if(vibrationTime>0){
    		long[] vibratePattern={(long)vibrationTime,(long)vibrationTime};
            mBuilder.setVibrate(vibratePattern);
    	}
    	
    	if(tickerText!="")
    		mBuilder.setTicker(tickerText);
    	try{
    		if(soundPath!=""){
    			//Uri soundUri=Uri.parse("file:///android_asset/res/"+soundPath);
        		Uri theUri = Uri.parse("content://"+context.getPackageName()+".WebAsset/res/"+soundPath);
        		Log.i("sound uri", theUri.toString());
            	mBuilder.setSound(theUri);
    		}
    		
    	}
    	catch(NullPointerException execption){}
    	
    	
		mBuilder.setAutoCancel(true);
			
		Intent resultIntent = new Intent(context, MainActivity.class);
		resultIntent.addCategory(Intent.CATEGORY_LAUNCHER);
		resultIntent.setAction(Intent.ACTION_MAIN);

		PendingIntent resultPendingIntent=PendingIntent.getActivity(context, alarmId, resultIntent, 0);
		mBuilder.setContentIntent(resultPendingIntent);
		NotificationManager mNotificationManager =(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
		
		mNotificationManager.notify(1, mBuilder.build());
		
		//обрабатываем уведомление
		new NotificationHelper(context).processAlarmCome(alarmId);
    }
}