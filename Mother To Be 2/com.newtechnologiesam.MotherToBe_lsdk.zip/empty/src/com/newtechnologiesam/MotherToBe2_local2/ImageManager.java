package com.newtechnologiesam.MotherToBe2_local2;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.util.Log;

//класс для обработки изображений
public class ImageManager {
	
	//перезаписать картинку если она перевернута
	public static void rotateNSave(String filePath){
		//String filePath=contentUri.getPath();
		Logging.trace("file path to rotate "+filePath);
		File f = new File(filePath);
	    Uri contentUri = Uri.fromFile(f);
	    

	    //rotate image
	    int rotate = 0;
        try {
            
            File imageFile = new File(filePath);
            ExifInterface exif = new ExifInterface(
                    imageFile.getAbsolutePath());
            int orientation = exif.getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL);

            switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_270:
                rotate = 270;
                break;
            case ExifInterface.ORIENTATION_ROTATE_180:
                rotate = 180;
                break;
            case ExifInterface.ORIENTATION_ROTATE_90:
                rotate = 90;
                break;
            }
            Logging.trace("rotation "+rotate);
            
        } catch (Exception e) {
            e.printStackTrace();
        }
	    
        if(rotate!=0){
        	BitmapFactory.Options op = new BitmapFactory.Options();
        	op.inPreferredConfig = Bitmap.Config.RGB_565; 
            op.inSampleSize = 4;
            
        	Bitmap bMap = BitmapFactory.decodeFile(filePath,op);
            
            
    		Matrix matrix = new Matrix();
    		matrix.postRotate(rotate);
    		bMap=Bitmap.createBitmap(bMap, 0, 0, bMap.getWidth(),
    				bMap.getHeight(), matrix, true);
    		
    		Logging.trace("finish rotate");

            FileOutputStream out = null;
            try {
                out = new FileOutputStream(filePath);
                bMap.compress(Bitmap.CompressFormat.JPEG, 100, out);
                Logging.trace("success save rotate image");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (out != null) {
                        out.close();
                        Logging.trace("success close file stream");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
         
	}
	
	
	public static double hashBitmap(Bitmap bmp) {
		long hash = 31; // or a higher prime at your choice
		for (int x = 0; x < bmp.getWidth(); x++) {
			for (int y = 0; y < bmp.getHeight(); y++) {
				hash *= (bmp.getPixel(x, y) + 31);
			}
		}
		
		return hash;
	}
	
}
